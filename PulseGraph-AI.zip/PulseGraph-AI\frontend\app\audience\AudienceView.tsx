'use client';

/**
 * Audience page: segments, inferred demographics and side-by-side comparison.
 *
 * Demographic rows always carry a confidence band and the evidence basis that
 * produced them, so nothing here can be mistaken for verified personal data.
 */

import { useEffect, useMemo, useState } from 'react';
import { ArrowLeftRight, ShieldCheck } from 'lucide-react';

import {
  Badge,
  Bar,
  EmptyState,
  ErrorState,
  Panel,
  PanelSkeleton,
  cx,
} from '@/components/ui/primitives';
import { AudienceMap } from '@/features/audience/AudienceMap';
import { filterKey, useFilters } from '@/features/filters/FilterContext';
import { useApi } from '@/hooks/useApi';
import { api } from '@/lib/api';
import { COLORS, SENTIMENT_COLORS, polarityColor } from '@/lib/colors';
import { compactNumber, platformLabel, polarity, titleCase } from '@/lib/format';
import type { AudienceResponse, DemographicRow, SegmentComparison } from '@/types/api';

function DemographicPanel({
  title,
  subtitle,
  rows,
  color = COLORS.influence,
}: {
  title: string;
  subtitle?: string;
  rows: DemographicRow[];
  color?: string;
}) {
  if (!rows.length) {
    return (
      <Panel title={title} subtitle={subtitle}>
        <EmptyState title="No inferences available" description="No public signal supported an inference for this attribute." />
      </Panel>
    );
  }
  return (
    <Panel title={title} subtitle={subtitle}>
      <div className="space-y-2">
        {rows.slice(0, 8).map((row) => (
          <div key={row.value}>
            <div className="flex items-baseline justify-between gap-2">
              <span className="min-w-0 truncate text-2xs text-ink-muted">
                {row.value === 'unknown' ? 'Not inferable' : row.value}
              </span>
              <span className="flex shrink-0 items-center gap-1.5">
                <span className="font-mono text-2xs tabular-nums text-ink">
                  {row.percentage}%
                </span>
                <Badge
                  tone={
                    row.confidence_band === 'High'
                      ? 'positive'
                      : row.confidence_band === 'Medium'
                        ? 'warning'
                        : 'neutral'
                  }
                >
                  {row.confidence_band}
                </Badge>
              </span>
            </div>
            <Bar value={row.percentage} max={100} color={color} className="mt-1" />
          </div>
        ))}
      </div>
    </Panel>
  );
}

function ComparisonView({ comparison }: { comparison: SegmentComparison }) {
  const rows: { label: string; left: string; right: string }[] = [
    { label: 'Accounts', left: String(comparison.metrics.size.left), right: String(comparison.metrics.size.right) },
    { label: 'Posts', left: String(comparison.metrics.posts.left), right: String(comparison.metrics.posts.right) },
    {
      label: 'Average polarity',
      left: polarity(Number(comparison.metrics.avg_polarity.left)),
      right: polarity(Number(comparison.metrics.avg_polarity.right)),
    },
    {
      label: 'Average engagement',
      left: compactNumber(Number(comparison.metrics.avg_engagement.left)),
      right: compactNumber(Number(comparison.metrics.avg_engagement.right)),
    },
    {
      label: 'Dominant sentiment',
      left: titleCase(String(comparison.metrics.dominant_sentiment.left)),
      right: titleCase(String(comparison.metrics.dominant_sentiment.right)),
    },
  ];

  return (
    <div>
      <div className="mb-3 flex items-center justify-between gap-3 rounded border border-edge-subtle bg-canvas-sunken px-3 py-2">
        <span className="flex min-w-0 items-center gap-1.5">
          <span className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: comparison.left.color }} aria-hidden />
          <span className="truncate text-2xs font-medium text-ink">{comparison.left.name}</span>
        </span>
        <span className="shrink-0 text-2xs text-ink-faint">
          polarity gap{' '}
          <span
            className="font-mono tabular-nums"
            style={{ color: polarityColor(-Math.abs(comparison.polarity_gap)) }}
          >
            {Math.abs(comparison.polarity_gap).toFixed(2)}
          </span>
        </span>
        <span className="flex min-w-0 items-center justify-end gap-1.5">
          <span className="truncate text-2xs font-medium text-ink">{comparison.right.name}</span>
          <span className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: comparison.right.color }} aria-hidden />
        </span>
      </div>

      <table className="w-full border-collapse text-2xs">
        <tbody>
          {rows.map((row) => (
            <tr key={row.label} className="border-b border-edge-subtle/60 last:border-0">
              <td className="w-1/4 py-1.5 text-right font-mono tabular-nums text-ink">{row.left}</td>
              <td className="px-3 py-1.5 text-center text-ink-faint">{row.label}</td>
              <td className="w-1/4 py-1.5 font-mono tabular-nums text-ink">{row.right}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        {(['left', 'right'] as const).map((side) => (
          <div key={side}>
            <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-faint">
              {comparison[side].name} — sentiment
            </p>
            <div className="mt-1.5 space-y-1">
              {comparison.sentiment_distribution[side].map((row) => (
                <div key={row.sentiment} className="flex items-center gap-2">
                  <span className="w-14 shrink-0 text-2xs capitalize text-ink-muted">
                    {row.sentiment}
                  </span>
                  <div className="flex-1">
                    <Bar value={row.percentage} max={100} color={SENTIMENT_COLORS[row.sentiment]} />
                  </div>
                  <span className="w-9 shrink-0 text-right font-mono text-[10px] tabular-nums text-ink-faint">
                    {row.percentage}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-3 grid gap-3 sm:grid-cols-3">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-faint">
            Shared topics
          </p>
          <div className="mt-1 flex flex-wrap gap-1">
            {comparison.topics.shared.length === 0 && (
              <span className="text-2xs text-ink-faint">None</span>
            )}
            {comparison.topics.shared.map((t) => (
              <Badge key={t} tone="neutral">{t}</Badge>
            ))}
          </div>
        </div>
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-faint">
            Only {comparison.left.name}
          </p>
          <div className="mt-1 flex flex-wrap gap-1">
            {comparison.topics.left_only.map((t) => (
              <Badge key={t} tone="trend">{t}</Badge>
            ))}
          </div>
        </div>
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-faint">
            Only {comparison.right.name}
          </p>
          <div className="mt-1 flex flex-wrap gap-1">
            {comparison.topics.right_only.map((t) => (
              <Badge key={t} tone="influence">{t}</Badge>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        {(['left', 'right'] as const).map((side) => (
          <div key={side}>
            <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-faint">
              {comparison[side].name} — platforms
            </p>
            <div className="mt-1 flex flex-wrap gap-1">
              {comparison.platforms[side].map((p) => (
                <Badge key={p.platform} tone="neutral">
                  {platformLabel(p.platform)} {p.posts}
                </Badge>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function AudienceView() {
  const { filters } = useFilters();
  const key = filterKey(filters);

  const audience = useApi<AudienceResponse>(`audience:${key}`, () => api.audience(filters));

  const populated = useMemo(
    () => audience.data?.segments.filter((s) => s.posts > 0) ?? [],
    [audience.data],
  );

  const [left, setLeft] = useState('');
  const [right, setRight] = useState('');

  useEffect(() => {
    if (populated.length >= 2 && (!left || !right)) {
      setLeft(populated[0].id);
      setRight(populated[1].id);
    }
  }, [populated, left, right]);

  const comparison = useApi<SegmentComparison>(
    left && right && left !== right ? `compare:${left}:${right}:${key}` : null,
    () => api.compareSegments(left, right, filters),
  );

  if (audience.error) {
    return (
      <Panel>
        <ErrorState error={audience.error} onRetry={audience.reload} />
      </Panel>
    );
  }

  const demographics = audience.data?.demographics;

  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-lg font-semibold tracking-tight text-ink">Audience</h1>
        <p className="mt-0.5 text-2xs text-ink-muted">
          Behavioural segments and aggregate demographic inference for the current selection
          {audience.data ? ` · ${audience.data.total_authors} accounts` : ''}
        </p>
      </div>

      <AudienceMap segments={audience.data?.segments ?? null} loading={audience.loading} />

      <Panel
        title={
          <span className="flex items-center gap-1.5">
            <ArrowLeftRight className="h-3.5 w-3.5 text-influence" aria-hidden />
            Compare segments
          </span>
        }
        subtitle="Where two audiences diverge on sentiment, topics and platform use"
        actions={
          <div className="flex items-center gap-1.5">
            <select
              value={left}
              onChange={(e) => setLeft(e.target.value)}
              aria-label="First segment"
              className="rounded border border-edge bg-canvas-sunken px-1.5 py-1 text-2xs text-ink"
            >
              {populated.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
            <span className="text-2xs text-ink-faint">vs</span>
            <select
              value={right}
              onChange={(e) => setRight(e.target.value)}
              aria-label="Second segment"
              className="rounded border border-edge bg-canvas-sunken px-1.5 py-1 text-2xs text-ink"
            >
              {populated.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>
        }
      >
        {populated.length < 2 && (
          <EmptyState
            title="Need two active segments to compare"
            description="Widen the filters so at least two segments have posts in the window."
          />
        )}
        {comparison.loading && <PanelSkeleton rows={6} height="h-5" />}
        {comparison.error && <ErrorState error={comparison.error} onRetry={comparison.reload} />}
        {comparison.data && <ComparisonView comparison={comparison.data} />}
      </Panel>

      {audience.loading && (
        <Panel>
          <PanelSkeleton rows={6} height="h-6" />
        </Panel>
      )}

      {demographics && (
        <>
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            <DemographicPanel
              title="Age brackets"
              subtitle="Inferred from public bio text and profile metadata"
              rows={demographics.age_brackets}
              color={COLORS.trend}
            />
            <DemographicPanel
              title="Geographic distribution"
              subtitle="From self-declared public location fields and posting language"
              rows={demographics.regions}
            />
            <DemographicPanel
              title="Language"
              subtitle="Detected from the language of public posts"
              rows={demographics.languages}
              color={COLORS.positive}
            />
            <DemographicPanel
              title="Professional interest"
              subtitle="Inferred from public bio text and observed topic interaction"
              rows={demographics.interests}
              color={COLORS.warning}
            />
            <DemographicPanel
              title="Engagement behaviour"
              subtitle="Observed posting behaviour, not an inferred attribute"
              rows={demographics.behaviours}
              color={COLORS.influence}
            />

            <Panel
              title={
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="h-3.5 w-3.5 text-positive" aria-hidden />
                  Evidence basis
                </span>
              }
              subtitle="Which public signals produced these inferences"
            >
              <div className="space-y-1.5">
                {demographics.evidence_basis.map((row) => (
                  <div key={row.basis} className="flex items-baseline justify-between gap-2">
                    <span className="min-w-0 text-2xs text-ink-muted">{row.basis}</span>
                    <span className="shrink-0 font-mono text-2xs tabular-nums text-ink-faint">
                      {compactNumber(row.signals)}
                    </span>
                  </div>
                ))}
              </div>
              <p className={cx('mt-3 border-t border-edge-subtle pt-2 text-[10px] leading-relaxed text-ink-faint')}>
                {demographics.profiles_considered} profiles considered. Every attribute is an
                estimate with a confidence band. No sensitive personal attributes are inferred.
              </p>
            </Panel>
          </div>

          <Panel>
            <p className="text-2xs leading-relaxed text-ink-muted">
              <span className="font-medium text-ink">{audience.data?.privacy_notice}</span>
            </p>
          </Panel>
        </>
      )}
    </div>
  );
}
