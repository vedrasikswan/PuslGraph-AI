'use client';

/**
 * Small data-fetching hook with request de-duplication and an in-memory cache.
 *
 * Deliberately not a data library: the dashboard makes a handful of calls per
 * filter change, and a cache keyed on the request signature is enough to avoid
 * refetching when several panels need the same payload.
 */

import { useCallback, useEffect, useRef, useState } from 'react';

import { ApiError } from '@/lib/api';

const cache = new Map<string, unknown>();
const inflight = new Map<string, Promise<unknown>>();

export function clearApiCache(): void {
  cache.clear();
  inflight.clear();
}

export interface ApiState<T> {
  data: T | null;
  error: ApiError | null;
  loading: boolean;
  /** True while refetching with a previous result still on screen. */
  refreshing: boolean;
  reload: () => void;
}

export function useApi<T>(
  key: string | null,
  fetcher: () => Promise<T>,
  options: { keepPreviousData?: boolean } = {},
): ApiState<T> {
  const { keepPreviousData = true } = options;
  const [data, setData] = useState<T | null>(() => (key ? (cache.get(key) as T) ?? null : null));
  const [error, setError] = useState<ApiError | null>(null);
  const [loading, setLoading] = useState<boolean>(() => (key ? !cache.has(key) : false));
  const [refreshing, setRefreshing] = useState(false);
  const [nonce, setNonce] = useState(0);

  const fetcherRef = useRef(fetcher);
  fetcherRef.current = fetcher;

  useEffect(() => {
    if (!key) {
      setLoading(false);
      return;
    }
    let cancelled = false;

    const cached = cache.get(key) as T | undefined;
    if (cached !== undefined && nonce === 0) {
      setData(cached);
      setLoading(false);
      setError(null);
      return;
    }

    if (!keepPreviousData || data === null) setLoading(true);
    else setRefreshing(true);

    const existing = inflight.get(key);
    const promise = existing ?? fetcherRef.current();
    if (!existing) inflight.set(key, promise);

    promise
      .then((result) => {
        cache.set(key, result);
        if (!cancelled) {
          setData(result as T);
          setError(null);
        }
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        setError(
          err instanceof ApiError
            ? err
            : new ApiError(0, 'Unexpected error while loading this view.'),
        );
        if (!keepPreviousData) setData(null);
      })
      .finally(() => {
        inflight.delete(key);
        if (!cancelled) {
          setLoading(false);
          setRefreshing(false);
        }
      });

    return () => {
      cancelled = true;
    };
    // `data` is intentionally excluded: including it would refetch on every set.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, nonce, keepPreviousData]);

  const reload = useCallback(() => {
    if (key) cache.delete(key);
    setNonce((n) => n + 1);
  }, [key]);

  return { data, error, loading, refreshing, reload };
}
