"""Read-side analytics service.

Everything the API serves is computed here from the *filtered* row set, so a
filter change genuinely re-derives sentiment, trends, audience, network and
intelligence rather than hiding rows in one chart.

Results are memoised per filter signature and invalidated whenever a pipeline
run completes, which keeps repeated dashboard requests cheap without ever
serving stale numbers.
"""

from __future__ import annotations

import logging
import math
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from typing import Any, Callable

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.analytics import network as net
from app.analytics import trends as trend_mod
from app.analytics.demographics import confidence_band
from app.analytics.filters import AnalysisFilters, apply_filters, floor_to, resolve_range
from app.analytics.journey import build_journey
from app.analytics.topics import corpus_document_frequencies, distinctive_keywords
from app.models import (
    AnalysisRun,
    Author,
    AudienceSegment,
    AuthorSegment,
    DemographicProfile,
    IntelligenceEvent,
    Interaction,
    NetworkMetric,
    Post,
    PostTopic,
    SentimentResult,
    Topic,
)

logger = logging.getLogger(__name__)

_CACHE: dict[str, Any] = {}
_GENERATION = 0


def invalidate_cache() -> None:
    global _GENERATION
    _GENERATION += 1
    _CACHE.clear()


def _memo(key: str, producer: Callable[[], Any]) -> Any:
    full_key = f"{_GENERATION}:{key}"
    if full_key not in _CACHE:
        if len(_CACHE) > 96:
            _CACHE.clear()
        _CACHE[full_key] = producer()
    return _CACHE[full_key]


SENTIMENT_ORDER = ["positive", "neutral", "negative"]


class AnalyticsService:
    def __init__(self, db: Session) -> None:
        self.db = db

    # ------------------------------------------------------------------ #
    # Filtered base row set
    # ------------------------------------------------------------------ #
    def filtered_posts(self, filters: AnalysisFilters) -> list[Any]:
        def produce() -> list[Any]:
            stmt = (
                select(
                    Post.id, Post.platform, Post.author_id, Post.created_at,
                    Post.engagement_count, Post.likes, Post.comments_count, Post.shares,
                    Post.views, Post.language, Post.text, Post.reply_to_id,
                    SentimentResult.sentiment, SentimentResult.polarity,
                    SentimentResult.emotion, SentimentResult.sarcasm_detected,
                    SentimentResult.stance, SentimentResult.sentiment_confidence,
                    PostTopic.topic_id,
                )
                .join(SentimentResult, SentimentResult.post_id == Post.id, isouter=True)
                .join(PostTopic,
                      (PostTopic.post_id == Post.id) & (PostTopic.is_primary.is_(True)),
                      isouter=True)
            )
            stmt = apply_filters(stmt, filters, joined=True)
            return list(self.db.execute(stmt.order_by(Post.created_at)).all())

        return _memo(f"posts:{filters.signature()}", produce)

    # ------------------------------------------------------------------ #
    # Overview / KPIs
    # ------------------------------------------------------------------ #
    def overview(self, filters: AnalysisFilters) -> dict:
        def produce() -> dict:
            rows = self.filtered_posts(filters)
            start, end = resolve_range(self.db, filters)
            total = len(rows)

            if total == 0:
                return {
                    "empty": True,
                    "kpis": self._empty_kpis(),
                    "sentiment_distribution": [],
                    "emotion_distribution": [],
                    "platform_distribution": [],
                    "pulse": None,
                    "range": {"start": start.isoformat() if start else None,
                              "end": end.isoformat() if end else None},
                }

            sentiments = Counter(r.sentiment for r in rows if r.sentiment)
            emotions = Counter(r.emotion for r in rows if r.emotion)
            platforms = Counter(r.platform for r in rows)
            authors = {r.author_id for r in rows}
            engagement = sum(r.engagement_count for r in rows)
            polarity_values = [r.polarity for r in rows if r.polarity is not None]
            avg_polarity = sum(polarity_values) / len(polarity_values) if polarity_values else 0.0

            trend_results = self.trend_results(filters)
            trending = [t for t in trend_results
                        if t.classification in {"growing", "accelerating", "viral"}]

            influencers = self.network_metrics(filters)
            influential = sum(1 for m in influencers.values() if m.influence_score >= 20)

            # Comparison against the immediately preceding window of equal length.
            previous = self._previous_window_summary(filters, start, end)

            kpis = [
                {"key": "total_posts", "label": "Total posts", "value": total,
                 "change": previous.get("posts_change"), "format": "number"},
                {"key": "active_authors", "label": "Active authors", "value": len(authors),
                 "change": previous.get("authors_change"), "format": "number"},
                {"key": "engagement", "label": "Engagement", "value": engagement,
                 "change": previous.get("engagement_change"), "format": "number"},
                {"key": "positive_share", "label": "Positive",
                 "value": round(sentiments.get("positive", 0) * 100 / total, 1),
                 "change": previous.get("positive_change"), "format": "percent"},
                {"key": "negative_share", "label": "Negative",
                 "value": round(sentiments.get("negative", 0) * 100 / total, 1),
                 "change": previous.get("negative_change"), "format": "percent"},
                {"key": "trending_topics", "label": "Trending topics", "value": len(trending),
                 "change": None, "format": "number"},
                {"key": "influential_nodes", "label": "Influential nodes", "value": influential,
                 "change": None, "format": "number"},
            ]

            return {
                "empty": False,
                "kpis": kpis,
                "avg_polarity": round(avg_polarity, 4),
                "sarcasm_rate": round(
                    sum(1 for r in rows if r.sarcasm_detected) / total, 4),
                "sentiment_distribution": [
                    {"sentiment": s, "count": sentiments.get(s, 0),
                     "percentage": round(sentiments.get(s, 0) * 100 / total, 1)}
                    for s in SENTIMENT_ORDER
                ],
                "emotion_distribution": [
                    {"emotion": e, "count": c, "percentage": round(c * 100 / total, 1)}
                    for e, c in emotions.most_common(10)
                ],
                "platform_distribution": [
                    {"platform": p, "count": c, "percentage": round(c * 100 / total, 1)}
                    for p, c in platforms.most_common()
                ],
                "range": {"start": start.isoformat() if start else None,
                          "end": end.isoformat() if end else None},
                "pulse": self.audience_pulse(filters),
            }

        return _memo(f"overview:{filters.signature()}", produce)

    @staticmethod
    def _empty_kpis() -> list[dict]:
        keys = [
            ("total_posts", "Total posts", "number"), ("active_authors", "Active authors", "number"),
            ("engagement", "Engagement", "number"), ("positive_share", "Positive", "percent"),
            ("negative_share", "Negative", "percent"),
            ("trending_topics", "Trending topics", "number"),
            ("influential_nodes", "Influential nodes", "number"),
        ]
        return [{"key": k, "label": lbl, "value": 0, "change": None, "format": fmt}
                for k, lbl, fmt in keys]

    def _previous_window_summary(
        self, filters: AnalysisFilters, start: datetime | None, end: datetime | None
    ) -> dict:
        if not start or not end or end <= start:
            return {}
        span = end - start
        prev_filters = AnalysisFilters(
            start=start - span, end=start, platforms=filters.platforms,
            topics=filters.topics, segments=filters.segments,
            sentiments=filters.sentiments, emotions=filters.emotions,
            search=filters.search, granularity=filters.granularity,
        )
        rows = self.filtered_posts(prev_filters)
        if not rows:
            return {}
        current = self.filtered_posts(filters)
        total_prev, total_now = len(rows), len(current)

        def pct(now: float, before: float) -> float | None:
            if before <= 0:
                return None
            return round((now - before) / before * 100, 1)

        prev_sent = Counter(r.sentiment for r in rows if r.sentiment)
        now_sent = Counter(r.sentiment for r in current if r.sentiment)

        return {
            "posts_change": pct(total_now, total_prev),
            "authors_change": pct(
                len({r.author_id for r in current}), len({r.author_id for r in rows})),
            "engagement_change": pct(
                sum(r.engagement_count for r in current),
                sum(r.engagement_count for r in rows)),
            "positive_change": round(
                now_sent.get("positive", 0) * 100 / max(total_now, 1)
                - prev_sent.get("positive", 0) * 100 / max(total_prev, 1), 1),
            "negative_change": round(
                now_sent.get("negative", 0) * 100 / max(total_now, 1)
                - prev_sent.get("negative", 0) * 100 / max(total_prev, 1), 1),
        }

    # ------------------------------------------------------------------ #
    # Sentiment timeline
    # ------------------------------------------------------------------ #
    def sentiment_timeline(self, filters: AnalysisFilters) -> dict:
        def produce() -> dict:
            rows = self.filtered_posts(filters)
            if not rows:
                return {"granularity": filters.granularity, "points": [], "total": 0}

            size = filters.bucket
            buckets: dict[datetime, dict] = defaultdict(
                lambda: {"positive": 0, "negative": 0, "neutral": 0, "total": 0,
                         "polarity_sum": 0.0, "engagement": 0, "sarcasm": 0,
                         "authors": set()}
            )
            for r in rows:
                key = floor_to(r.created_at, size)
                b = buckets[key]
                b["total"] += 1
                b["engagement"] += r.engagement_count
                b["authors"].add(r.author_id)
                if r.sentiment in b:
                    b[r.sentiment] += 1
                if r.polarity is not None:
                    b["polarity_sum"] += r.polarity
                if r.sarcasm_detected:
                    b["sarcasm"] += 1

            points = []
            for key in sorted(buckets):
                b = buckets[key]
                points.append({
                    "ts": key.isoformat(),
                    "positive": b["positive"],
                    "negative": b["negative"],
                    "neutral": b["neutral"],
                    "total": b["total"],
                    "engagement": b["engagement"],
                    "unique_authors": len(b["authors"]),
                    "sarcasm": b["sarcasm"],
                    "avg_polarity": round(b["polarity_sum"] / b["total"], 4) if b["total"] else 0.0,
                    "negative_share": round(b["negative"] / b["total"], 4) if b["total"] else 0.0,
                })
            return {"granularity": filters.granularity, "points": points, "total": len(rows)}

        return _memo(f"timeline:{filters.signature()}", produce)

    # ------------------------------------------------------------------ #
    # Trends
    # ------------------------------------------------------------------ #
    def trend_results(self, filters: AnalysisFilters) -> list[trend_mod.TrendResult]:
        def produce() -> list[trend_mod.TrendResult]:
            rows = self.filtered_posts(filters)
            rows = [r for r in rows if r.topic_id]
            if not rows:
                return []

            metrics = self.network_metrics(filters)
            influence_values = sorted((m.influence_score for m in metrics.values()), reverse=True)
            cut = (influence_values[max(0, len(influence_values) // 20 - 1)]
                   if influence_values else 0.0)
            influencer_ids = {a for a, m in metrics.items()
                              if cut > 0 and m.influence_score >= cut}

            by_topic: dict[str, list[trend_mod.TopicObservation]] = defaultdict(list)
            for r in rows:
                by_topic[r.topic_id].append(trend_mod.TopicObservation(
                    timestamp=r.created_at, author_id=r.author_id, platform=r.platform,
                    engagement=r.engagement_count, polarity=r.polarity or 0.0,
                    influence_score=(metrics[r.author_id].influence_score
                                     if r.author_id in metrics else 0.0),
                ))

            end = max(r.created_at for r in rows)
            start, filter_end = resolve_range(self.db, filters)
            span = timedelta(hours=24)
            if start and filter_end and (filter_end - start) < span:
                span = max(filter_end - start, timedelta(hours=2))
            window_start = end - span

            results = [
                trend_mod.analyse_topic(topic_id, observations, window_start, end, influencer_ids)
                for topic_id, observations in by_topic.items()
            ]
            results.sort(key=lambda r: r.trend_score, reverse=True)
            return results

        return _memo(f"trends:{filters.signature()}", produce)

    def trends(self, filters: AnalysisFilters) -> list[dict]:
        labels = dict(self.db.execute(select(Topic.id, Topic.label)).all())
        descriptions = dict(self.db.execute(select(Topic.id, Topic.description)).all())
        return [
            {
                "topic_id": r.topic_id,
                "label": labels.get(r.topic_id, r.topic_id),
                "description": descriptions.get(r.topic_id, ""),
                "trend_score": r.trend_score,
                "classification": r.classification,
                "velocity": trend_mod.velocity_summary(r),
                "sentiment": {
                    "avg_polarity": r.current_polarity,
                    "previous_polarity": r.prev_polarity,
                    "shift": r.sentiment_shift,
                },
                "platforms": r.platforms,
                "platform_count": r.platform_count,
                "influencer_participation": r.influencer_participation,
                "persistence": r.persistence,
                "momentum": {
                    "label": r.momentum,
                    "confidence": r.momentum_confidence,
                    "confidence_band": confidence_band(r.momentum_confidence),
                    "forecast_next_bucket": r.forecast_next,
                },
                "components": r.components,
                "series": r.series,
            }
            for r in self.trend_results(filters)
        ]

    def topic_detail(self, topic_id: str, filters: AnalysisFilters) -> dict | None:
        topic = self.db.get(Topic, topic_id)
        if topic is None:
            return None

        scoped = AnalysisFilters(
            start=filters.start, end=filters.end, platforms=filters.platforms,
            topics=[topic_id], segments=filters.segments, sentiments=filters.sentiments,
            emotions=filters.emotions, search=filters.search, granularity=filters.granularity,
        )
        rows = self.filtered_posts(scoped)
        trend = next((t for t in self.trend_results(filters) if t.topic_id == topic_id), None)
        if trend is None:
            trend_list = self.trend_results(scoped)
            trend = trend_list[0] if trend_list else None

        all_texts = [t for (t,) in self.db.execute(select(Post.text)).all()]
        corpus_df, corpus_size = corpus_document_frequencies(all_texts)
        keywords = distinctive_keywords([r.text for r in rows], corpus_df, corpus_size)

        segment_of = dict(self.db.execute(
            select(AuthorSegment.author_id, AuthorSegment.segment_id)).all())
        segment_names = dict(self.db.execute(
            select(AudienceSegment.id, AudienceSegment.name)).all())
        segment_counts = Counter(
            segment_of[r.author_id] for r in rows if r.author_id in segment_of)
        total_segmented = sum(segment_counts.values()) or 1

        profiles = {p.author_id: p for p in self.db.execute(
            select(DemographicProfile)).scalars()}
        ages = Counter()
        regions = Counter()
        for author_id in {r.author_id for r in rows}:
            profile = profiles.get(author_id)
            if profile:
                ages[profile.age_bracket] += 1
                regions[profile.region] += 1

        metrics = self.network_metrics(filters)
        anon = dict(self.db.execute(select(Author.id, Author.anon_id)).all())
        contributors = Counter()
        engagement_by_author = Counter()
        for r in rows:
            contributors[r.author_id] += 1
            engagement_by_author[r.author_id] += r.engagement_count

        top_accounts = sorted(
            contributors.keys(),
            key=lambda a: (metrics[a].influence_score if a in metrics else 0.0,
                           engagement_by_author[a]),
            reverse=True,
        )[:10]

        sentiments = Counter(r.sentiment for r in rows if r.sentiment)
        total = len(rows) or 1

        return {
            "topic": {
                "id": topic.id, "label": topic.label, "description": topic.description,
                "keywords": topic.keywords, "hashtags": topic.hashtags,
                "first_seen_at": topic.first_seen_at.isoformat() if topic.first_seen_at else None,
                "last_seen_at": topic.last_seen_at.isoformat() if topic.last_seen_at else None,
            },
            "post_count": len(rows),
            "trend": (
                {
                    "trend_score": trend.trend_score,
                    "classification": trend.classification,
                    "velocity": trend_mod.velocity_summary(trend),
                    "momentum": {
                        "label": trend.momentum, "confidence": trend.momentum_confidence,
                        "confidence_band": confidence_band(trend.momentum_confidence),
                        "forecast_next_bucket": trend.forecast_next,
                    },
                    "components": trend.components,
                    "series": trend.series,
                }
                if trend else None
            ),
            "sentiment": {
                "distribution": [
                    {"sentiment": s, "count": sentiments.get(s, 0),
                     "percentage": round(sentiments.get(s, 0) * 100 / total, 1)}
                    for s in SENTIMENT_ORDER
                ],
                "avg_polarity": round(
                    sum(r.polarity or 0 for r in rows) / total, 4),
                "sarcasm_rate": round(
                    sum(1 for r in rows if r.sarcasm_detected) / total, 4),
            },
            "keywords": keywords,
            "audience": {
                "segments": [
                    {"segment_id": sid, "name": segment_names.get(sid, sid), "posts": count,
                     "percentage": round(count * 100 / total_segmented, 1)}
                    for sid, count in segment_counts.most_common()
                ],
                "age_brackets": [
                    {"bracket": b, "authors": c,
                     "percentage": round(c * 100 / max(sum(ages.values()), 1), 1)}
                    for b, c in ages.most_common()
                ],
                "regions": [
                    {"region": r, "authors": c,
                     "percentage": round(c * 100 / max(sum(regions.values()), 1), 1)}
                    for r, c in regions.most_common(8)
                ],
            },
            "platforms": self.platform_breakdown_for(rows),
            "journey": build_journey(self.db, topic_id),
            "top_accounts": [
                {
                    "anon_id": anon.get(a, "A?"),
                    "posts": contributors[a],
                    "engagement": engagement_by_author[a],
                    "influence_score": round(metrics[a].influence_score, 2) if a in metrics else 0.0,
                    "community_id": metrics[a].community_id if a in metrics else None,
                    "is_bridge": metrics[a].is_bridge if a in metrics else False,
                    "segment": segment_names.get(segment_of.get(a, ""), "Unassigned"),
                }
                for a in top_accounts
            ],
            "intelligence": self.intelligence(filters, topic_id=topic_id),
        }

    @staticmethod
    def platform_breakdown_for(rows: list[Any]) -> list[dict]:
        by_platform: dict[str, dict] = defaultdict(
            lambda: {"posts": 0, "engagement": 0, "polarity_sum": 0.0,
                     "negative": 0, "positive": 0, "authors": set()}
        )
        for r in rows:
            entry = by_platform[r.platform]
            entry["posts"] += 1
            entry["engagement"] += r.engagement_count
            entry["polarity_sum"] += r.polarity or 0.0
            entry["authors"].add(r.author_id)
            if r.sentiment == "negative":
                entry["negative"] += 1
            elif r.sentiment == "positive":
                entry["positive"] += 1

        out = []
        for platform, entry in by_platform.items():
            posts = entry["posts"]
            out.append({
                "platform": platform,
                "posts": posts,
                "unique_authors": len(entry["authors"]),
                "engagement": entry["engagement"],
                "avg_polarity": round(entry["polarity_sum"] / posts, 4) if posts else 0.0,
                "negative_share": round(entry["negative"] / posts, 4) if posts else 0.0,
                "positive_share": round(entry["positive"] / posts, 4) if posts else 0.0,
            })
        out.sort(key=lambda p: p["posts"], reverse=True)

        if len(out) >= 2:
            polarities = [p["avg_polarity"] for p in out if p["posts"] >= 5]
            if len(polarities) >= 2:
                divergence = max(polarities) - min(polarities)
                for entry in out:
                    entry["divergence_from_mean"] = round(
                        entry["avg_polarity"] - sum(polarities) / len(polarities), 4)
                out[0]["_divergence"] = round(divergence, 4)
        return out

    # ------------------------------------------------------------------ #
    # Audience
    # ------------------------------------------------------------------ #
    def audience(self, filters: AnalysisFilters) -> dict:
        def produce() -> dict:
            rows = self.filtered_posts(filters)
            segment_of = dict(self.db.execute(
                select(AuthorSegment.author_id, AuthorSegment.segment_id)).all())
            rationale_of = {
                a: r for a, r in self.db.execute(
                    select(AuthorSegment.author_id, AuthorSegment.rationale)).all()
            }
            stored = {s.id: s for s in self.db.execute(select(AudienceSegment)).scalars()}
            profiles = {p.author_id: p for p in self.db.execute(
                select(DemographicProfile)).scalars()}
            metrics = self.network_metrics(filters)
            anon = dict(self.db.execute(select(Author.id, Author.anon_id)).all())

            grouped: dict[str, list] = defaultdict(list)
            for r in rows:
                segment_id = segment_of.get(r.author_id)
                if segment_id:
                    grouped[segment_id].append(r)

            size = filters.bucket
            segments_out = []
            for segment_id, base in stored.items():
                entries = grouped.get(segment_id, [])
                authors = {r.author_id for r in entries}
                total = len(entries)

                sentiments = Counter(r.sentiment for r in entries if r.sentiment)
                topics = Counter(r.topic_id for r in entries if r.topic_id)
                platforms = Counter(r.platform for r in entries)
                languages = Counter(r.language for r in entries)
                ages = Counter()
                regions = Counter()
                interests = Counter()
                for author_id in authors:
                    profile = profiles.get(author_id)
                    if profile:
                        ages[profile.age_bracket] += 1
                        regions[profile.region] += 1
                        interests[profile.professional_interest] += 1

                engagement = sum(r.engagement_count for r in entries)
                avg_polarity = (sum(r.polarity or 0 for r in entries) / total) if total else 0.0

                trend_points: dict[datetime, list[float]] = defaultdict(list)
                for r in entries:
                    if r.polarity is not None:
                        trend_points[floor_to(r.created_at, size)].append(r.polarity)

                members = sorted(
                    authors,
                    key=lambda a: metrics[a].influence_score if a in metrics else 0.0,
                    reverse=True,
                )[:5]

                sample_rationale: list[str] = []
                for author_id in members:
                    sample_rationale = rationale_of.get(author_id) or []
                    if sample_rationale:
                        break

                segments_out.append({
                    "id": segment_id,
                    "name": base.name,
                    "description": base.description,
                    "color": base.color,
                    "size": len(authors),
                    "total_members": base.size,
                    "posts": total,
                    "engagement": engagement,
                    "avg_engagement": round(engagement / total, 1) if total else 0.0,
                    "engagement_level": ("high" if total and engagement / total > 260
                                         else "medium" if total and engagement / total > 60
                                         else "low"),
                    "avg_polarity": round(avg_polarity, 4),
                    "dominant_sentiment": (
                        "negative" if avg_polarity <= -0.12
                        else "positive" if avg_polarity >= 0.12 else "neutral"),
                    "sentiment_distribution": [
                        {"sentiment": s, "count": sentiments.get(s, 0),
                         "percentage": round(sentiments.get(s, 0) * 100 / total, 1) if total else 0}
                        for s in SENTIMENT_ORDER
                    ],
                    "dominant_topics": [{"topic_id": t, "posts": c} for t, c in topics.most_common(4)],
                    "platforms": [{"platform": p, "posts": c} for p, c in platforms.most_common()],
                    "languages": [{"language": lg, "posts": c} for lg, c in languages.most_common(4)],
                    "age_distribution": [
                        {"bracket": b, "authors": c,
                         "percentage": round(c * 100 / max(len(authors), 1), 1)}
                        for b, c in ages.most_common()
                    ],
                    "regions": [
                        {"region": rg, "authors": c,
                         "percentage": round(c * 100 / max(len(authors), 1), 1)}
                        for rg, c in regions.most_common(6)
                    ],
                    "interests": [{"interest": i, "authors": c} for i, c in interests.most_common(5)],
                    "sentiment_trend": [
                        {"ts": k.isoformat(), "avg_polarity": round(sum(v) / len(v), 4),
                         "posts": len(v)}
                        for k, v in sorted(trend_points.items())
                    ],
                    "influential_members": [
                        {"anon_id": anon.get(a, "A?"),
                         "influence_score": round(metrics[a].influence_score, 2) if a in metrics else 0.0,
                         "is_bridge": metrics[a].is_bridge if a in metrics else False}
                        for a in members
                    ],
                    "assignment_rationale": sample_rationale,
                })

            segments_out.sort(key=lambda s: s["posts"], reverse=True)

            author_ids = {r.author_id for r in rows}
            scoped_profiles = [profiles[a] for a in author_ids if a in profiles]
            return {
                "segments": segments_out,
                "demographics": self._demographic_rollup(scoped_profiles),
                "total_authors": len(author_ids),
                "privacy_notice": (
                    "All demographic values are aggregate inferences from public signals, "
                    "shown with confidence bands. They are not verified personal attributes."
                ),
            }

        return _memo(f"audience:{filters.signature()}", produce)

    @staticmethod
    def _demographic_rollup(profiles: list[DemographicProfile]) -> dict:
        def rollup(attribute: str, confidence_attr: str) -> list[dict]:
            counts: Counter[str] = Counter()
            conf: dict[str, float] = defaultdict(float)
            for p in profiles:
                value = getattr(p, attribute) or "unknown"
                counts[value] += 1
                conf[value] += getattr(p, confidence_attr, 0.5) or 0.0
            total = sum(counts.values()) or 1
            rows = []
            for value, count in counts.most_common():
                mean = conf[value] / count
                rows.append({
                    "value": value, "count": count,
                    "percentage": round(count * 100 / total, 1),
                    "confidence": round(mean, 3),
                    "confidence_band": confidence_band(mean),
                })
            return rows

        evidence_basis = Counter()
        for p in profiles:
            for item in p.evidence or []:
                if item.get("basis"):
                    evidence_basis[item["basis"]] += 1

        return {
            "age_brackets": rollup("age_bracket", "age_confidence"),
            "regions": rollup("region", "region_confidence"),
            "languages": rollup("language", "region_confidence"),
            "interests": rollup("professional_interest", "interest_confidence"),
            "behaviours": rollup("engagement_behaviour", "interest_confidence"),
            "evidence_basis": [{"basis": b, "signals": c} for b, c in evidence_basis.most_common()],
            "profiles_considered": len(profiles),
        }

    def compare_segments(self, filters: AnalysisFilters, left: str, right: str) -> dict:
        audience = self.audience(filters)
        index = {s["id"]: s for s in audience["segments"]}
        a, b = index.get(left), index.get(right)
        if not a or not b:
            return {"error": "unknown_segment"}

        def diff(key: str) -> dict:
            return {"left": a.get(key), "right": b.get(key)}

        left_topics = {t["topic_id"] for t in a["dominant_topics"]}
        right_topics = {t["topic_id"] for t in b["dominant_topics"]}

        return {
            "left": {"id": a["id"], "name": a["name"], "color": a["color"]},
            "right": {"id": b["id"], "name": b["name"], "color": b["color"]},
            "metrics": {
                "size": diff("size"),
                "posts": diff("posts"),
                "avg_polarity": diff("avg_polarity"),
                "avg_engagement": diff("avg_engagement"),
                "dominant_sentiment": diff("dominant_sentiment"),
            },
            "sentiment_distribution": {
                "left": a["sentiment_distribution"], "right": b["sentiment_distribution"]},
            "topics": {
                "shared": sorted(left_topics & right_topics),
                "left_only": sorted(left_topics - right_topics),
                "right_only": sorted(right_topics - left_topics),
            },
            "platforms": {"left": a["platforms"], "right": b["platforms"]},
            "regions": {"left": a["regions"], "right": b["regions"]},
            "polarity_gap": round((a["avg_polarity"] or 0) - (b["avg_polarity"] or 0), 4),
        }

    # ------------------------------------------------------------------ #
    # Network
    # ------------------------------------------------------------------ #
    def network_metrics(self, filters: AnalysisFilters) -> dict[str, net.NodeMetrics]:
        def produce() -> dict[str, net.NodeMetrics]:
            post_ids = {r.id for r in self.filtered_posts(filters)}
            if not post_ids:
                return {}
            rows = self.db.execute(select(Interaction)).scalars().all()
            edges = [
                net.Edge(source=r.source_author_id, target=r.target_author_id,
                         kind=r.interaction_type, weight=r.weight, topic_id=r.topic_id)
                for r in rows if r.post_id in post_ids
            ]
            if not edges:
                return {}
            followers = dict(self.db.execute(select(Author.id, Author.followers_count)).all())
            return net.compute_metrics(edges, followers)

        return _memo(f"network:{filters.signature()}", produce)

    def network(self, filters: AnalysisFilters, max_nodes: int = 140) -> dict:
        def produce() -> dict:
            metrics = self.network_metrics(filters)
            if not metrics:
                return {"nodes": [], "edges": [], "communities": [], "truncated": False,
                        "total_nodes": 0, "total_edges": 0, "empty": True}

            post_ids = {r.id for r in self.filtered_posts(filters)}
            rows = self.db.execute(select(Interaction)).scalars().all()
            edges = [
                net.Edge(source=r.source_author_id, target=r.target_author_id,
                         kind=r.interaction_type, weight=r.weight, topic_id=r.topic_id)
                for r in rows if r.post_id in post_ids
            ]
            aggregated = net.aggregate_for_display(metrics, edges, max_nodes=max_nodes)

            anon = dict(self.db.execute(select(Author.id, Author.anon_id)).all())
            platform_of = dict(self.db.execute(select(Author.id, Author.platform)).all())
            verified_of = dict(self.db.execute(select(Author.id, Author.verified)).all())
            segment_of = dict(self.db.execute(
                select(AuthorSegment.author_id, AuthorSegment.segment_id)).all())
            segment_meta = {
                s.id: {"name": s.name, "color": s.color}
                for s in self.db.execute(select(AudienceSegment)).scalars()
            }

            posts_by_author = Counter(r.author_id for r in self.filtered_posts(filters))
            polarity_by_author: dict[str, list[float]] = defaultdict(list)
            for r in self.filtered_posts(filters):
                if r.polarity is not None:
                    polarity_by_author[r.author_id].append(r.polarity)

            nodes = []
            for m in aggregated["nodes"]:
                segment_id = segment_of.get(m.author_id, "")
                meta = segment_meta.get(segment_id, {"name": "Unassigned", "color": "#64748b"})
                polarities = polarity_by_author.get(m.author_id, [])
                nodes.append({
                    "id": m.author_id,
                    "anon_id": anon.get(m.author_id, "A?"),
                    "platform": platform_of.get(m.author_id, "unknown"),
                    "verified": bool(verified_of.get(m.author_id, False)),
                    "influence_score": m.influence_score,
                    "pagerank": m.pagerank,
                    "betweenness": m.betweenness,
                    "degree_centrality": m.degree_centrality,
                    "degree": m.degree,
                    "in_degree": m.in_degree,
                    "out_degree": m.out_degree,
                    "community_id": m.community_id,
                    "is_bridge": m.is_bridge,
                    "cross_community_edges": m.cross_community_edges,
                    "reach": m.reach,
                    "posts": posts_by_author.get(m.author_id, 0),
                    "avg_polarity": round(sum(polarities) / len(polarities), 4) if polarities else 0.0,
                    "segment_id": segment_id,
                    "segment_name": meta["name"],
                    "segment_color": meta["color"],
                    "rationale": m.rationale,
                })

            communities: dict[int, dict] = defaultdict(
                lambda: {"accounts": 0, "influence": 0.0, "bridges": 0, "segments": Counter()})
            for m in metrics.values():
                entry = communities[m.community_id]
                entry["accounts"] += 1
                entry["influence"] += m.influence_score
                entry["bridges"] += 1 if m.is_bridge else 0
                sid = segment_of.get(m.author_id)
                if sid:
                    entry["segments"][sid] += 1

            community_rows = []
            for cid, entry in sorted(communities.items(), key=lambda kv: -kv[1]["accounts"]):
                dominant = entry["segments"].most_common(1)
                community_rows.append({
                    "community_id": cid,
                    "accounts": entry["accounts"],
                    "total_influence": round(entry["influence"], 2),
                    "bridge_nodes": entry["bridges"],
                    "dominant_segment": (
                        segment_meta.get(dominant[0][0], {}).get("name") if dominant else None),
                })

            return {
                "nodes": nodes,
                "edges": aggregated["edges"],
                "communities": community_rows,
                "truncated": aggregated["truncated"],
                "total_nodes": aggregated["total_nodes"],
                "total_edges": aggregated["total_edges"],
                "displayed_nodes": len(nodes),
                "empty": False,
            }

        return _memo(f"graph:{filters.signature()}:{max_nodes}", produce)

    def influencers(self, filters: AnalysisFilters, limit: int = 10) -> list[dict]:
        metrics = self.network_metrics(filters)
        if not metrics:
            return []
        anon = dict(self.db.execute(select(Author.id, Author.anon_id)).all())
        platform_of = dict(self.db.execute(select(Author.id, Author.platform)).all())
        segment_of = dict(self.db.execute(
            select(AuthorSegment.author_id, AuthorSegment.segment_id)).all())
        segment_names = dict(self.db.execute(
            select(AudienceSegment.id, AudienceSegment.name)).all())

        rows = self.filtered_posts(filters)
        posts_by_author = Counter(r.author_id for r in rows)
        engagement_by_author = Counter()
        topics_by_author: dict[str, Counter] = defaultdict(Counter)
        polarity_by_author: dict[str, list[float]] = defaultdict(list)
        for r in rows:
            engagement_by_author[r.author_id] += r.engagement_count
            if r.topic_id:
                topics_by_author[r.author_id][r.topic_id] += 1
            if r.polarity is not None:
                polarity_by_author[r.author_id].append(r.polarity)

        ranked = sorted(metrics.values(), key=lambda m: m.influence_score, reverse=True)[:limit]
        out = []
        for rank, m in enumerate(ranked, start=1):
            polarities = polarity_by_author.get(m.author_id, [])
            avg = sum(polarities) / len(polarities) if polarities else 0.0
            out.append({
                "rank": rank,
                "anon_id": anon.get(m.author_id, "A?"),
                "author_id": m.author_id,
                "platform": platform_of.get(m.author_id, "unknown"),
                "influence_score": m.influence_score,
                "pagerank": m.pagerank,
                "betweenness": m.betweenness,
                "degree_centrality": m.degree_centrality,
                "community_id": m.community_id,
                "is_bridge": m.is_bridge,
                "reach": m.reach,
                "posts": posts_by_author.get(m.author_id, 0),
                "engagement": engagement_by_author.get(m.author_id, 0),
                "topics": [t for t, _c in topics_by_author.get(m.author_id, Counter()).most_common(3)],
                "avg_polarity": round(avg, 4),
                "sentiment": ("negative" if avg <= -0.12 else
                              "positive" if avg >= 0.12 else "neutral"),
                "segment": segment_names.get(segment_of.get(m.author_id, ""), "Unassigned"),
                "rationale": m.rationale,
            })
        return out

    def influence_flow(self, filters: AnalysisFilters, topic_id: str) -> dict:
        metrics = self.network_metrics(filters)
        post_ids = {r.id for r in self.filtered_posts(filters)}
        rows = self.db.execute(select(Interaction)).scalars().all()
        edges = [
            net.Edge(source=r.source_author_id, target=r.target_author_id,
                     kind=r.interaction_type, weight=r.weight, topic_id=r.topic_id)
            for r in rows if r.post_id in post_ids
        ]
        anon = dict(self.db.execute(select(Author.id, Author.anon_id)).all())
        layers = net.propagation_path(edges, metrics, topic_id)
        journey = build_journey(self.db, topic_id)

        for layer in layers:
            layer["sample_nodes"] = [anon.get(n, "A?") for n in layer["sample_nodes"]]

        return {
            "topic_id": topic_id,
            "layers": layers,
            "lead_lag": journey.get("lead_lag", []),
            "disclaimer": (
                "Observed propagation path derived from interaction ordering. "
                "This shows how activity spread, not proven causation."
            ),
        }

    # ------------------------------------------------------------------ #
    # Intelligence + Pulse
    # ------------------------------------------------------------------ #
    def _detected_events(self, filters: AnalysisFilters) -> list[IntelligenceEvent]:
        """Detections for the current selection.

        With no filters active this reads the events the pipeline persisted. As
        soon as a filter narrows the dataset the detectors are re-run against
        that subset, because a feed describing the whole corpus next to KPIs
        describing a slice of it would be actively misleading.
        """
        def produce() -> list[IntelligenceEvent]:
            if filters.is_empty():
                return list(
                    self.db.execute(
                        select(IntelligenceEvent).order_by(IntelligenceEvent.detected_at.desc())
                    ).scalars()
                )

            from app.ai.registry import get_ai_provider
            from app.analytics.intelligence import InsightEngine

            engine = InsightEngine(self.db, get_ai_provider(), filters)
            return engine.run(self.trend_results(filters), self.network_metrics(filters))

        return _memo(f"events:{filters.signature()}", produce)

    def intelligence(
        self, filters: AnalysisFilters, topic_id: str | None = None, limit: int = 40
    ) -> list[dict]:
        events = self._detected_events(filters)

        topic_labels = dict(self.db.execute(select(Topic.id, Topic.label)).all())

        out = []
        for event in events:
            if topic_id and event.topic_id != topic_id:
                continue

            out.append({
                "id": event.id,
                "category": event.category,
                "title": event.title,
                "summary": event.summary,
                "severity": event.severity,
                "confidence": event.confidence,
                "confidence_band": confidence_band(event.confidence),
                "detected_at": event.detected_at.isoformat(),
                "window": {
                    "start": event.window_start.isoformat() if event.window_start else None,
                    "end": event.window_end.isoformat() if event.window_end else None,
                },
                "topic_id": event.topic_id,
                "topic_label": topic_labels.get(event.topic_id or "", None),
                "drivers": event.drivers,
                "affected_segments": event.affected_segments,
                "affected_platforms": event.affected_platforms,
                "related_nodes": event.related_nodes,
                "evidence": event.evidence,
                "recommended_action": event.recommended_action,
                "interpretation_source": event.interpretation_source,
            })
        out.sort(key=lambda e: (e["detected_at"], self._pulse_rank(e)), reverse=True)
        return out[:limit]

    # Category weights for the headline choice. A sentiment reversal is the most
    # actionable thing an analyst can be told; a declining topic the least.
    _PULSE_CATEGORY_WEIGHT = {
        "sentiment_spike": 1.0, "trend_acceleration": 0.92, "cross_platform_spread": 0.8,
        "segment_shift": 0.78, "influencer_amplification": 0.7, "emerging_topic": 0.66,
        "sentiment_divergence": 0.55, "sarcasm_load": 0.45, "bridge_discovery": 0.4,
        "declining_trend": 0.15,
    }
    _PULSE_SEVERITY_WEIGHT = {
        "critical": 1.0, "high": 0.85, "medium": 0.6, "low": 0.4, "info": 0.25,
    }
    # Evidence metrics that indicate how much of the conversation an event covers.
    _MATERIALITY_METRICS = (
        "posts_analysed", "mentions", "total_mentions", "segment_posts",
        "sarcastic_posts", "high_influence_participants",
    )

    def _pulse_rank(self, event: dict) -> float:
        """Rank events for the headline slot.

        Confidence alone is not enough: a very confident finding about 40 posts
        should not outrank a slightly less confident one about 500. Materiality
        (how much of the conversation the event actually covers) is folded in on
        a log scale so volume matters without dominating.
        """
        volume = 0.0
        for item in event.get("evidence", []):
            if item.get("metric") in self._MATERIALITY_METRICS:
                try:
                    volume = max(volume, float(item.get("value") or 0))
                except (TypeError, ValueError):
                    continue
        materiality = math.log10(1 + volume) / math.log10(1 + 600) if volume > 0 else 0.15

        category = self._PULSE_CATEGORY_WEIGHT.get(event["category"], 0.5)
        severity = self._PULSE_SEVERITY_WEIGHT.get(event["severity"], 0.5)
        return round(
            0.34 * category + 0.24 * severity + 0.24 * materiality
            + 0.18 * float(event.get("confidence") or 0.0),
            5,
        )

    def audience_pulse(self, filters: AnalysisFilters) -> dict | None:
        """The single headline statement: what changed, where, who, how it spread."""
        def produce() -> dict | None:
            events = self.intelligence(filters)
            if not events:
                return None

            events_sorted = sorted(events, key=self._pulse_rank, reverse=True)
            primary = events_sorted[0]
            topic_id = primary.get("topic_id")

            supporting = [e for e in events_sorted[1:] if e.get("topic_id") == topic_id][:3]

            spread = next(
                (e for e in events if e["category"] == "cross_platform_spread"
                 and e.get("topic_id") == topic_id), None)
            amplification = next(
                (e for e in events if e["category"] == "influencer_amplification"
                 and e.get("topic_id") == topic_id), None)
            segment_event = next(
                (e for e in events if e["category"] == "segment_shift"), None)

            lead_evidence = None
            if spread:
                lead_evidence = next(
                    (ev for ev in spread["evidence"] if ev["metric"] == "lead_time_minutes"), None)

            sentences = [primary["summary"]]
            if segment_event and segment_event.get("affected_segments"):
                sentences.append(
                    f"The change is most pronounced in "
                    f"{segment_event['affected_segments'][0]}."
                )
            if amplification and amplification.get("related_nodes"):
                sentences.append(
                    f"{len(amplification['related_nodes'])} high-influence accounts "
                    f"participated during the growth phase."
                )
            if lead_evidence:
                sentences.append(
                    f"{lead_evidence['period'].split('->')[0].strip().title()} activity "
                    f"preceded the increase elsewhere by about "
                    f"{lead_evidence['value']:.0f} minutes."
                )

            combined_evidence: list[dict] = list(primary["evidence"])
            for event in supporting:
                combined_evidence.extend(event["evidence"][:2])

            confidences = [primary["confidence"]] + [e["confidence"] for e in supporting]
            pooled = sum(confidences) / len(confidences)

            return {
                "headline": primary["title"],
                "statement": " ".join(sentences),
                "severity": primary["severity"],
                "confidence": round(pooled, 3),
                "confidence_band": confidence_band(pooled),
                "detected_at": primary["detected_at"],
                "topic_id": topic_id,
                "topic_label": primary.get("topic_label"),
                "affected_platforms": primary.get("affected_platforms", []),
                "affected_segments": (
                    primary.get("affected_segments")
                    or (segment_event.get("affected_segments") if segment_event else [])
                ),
                "evidence": combined_evidence[:10],
                "recommended_action": primary.get("recommended_action", ""),
                "supporting_events": [
                    {"id": e["id"], "title": e["title"], "category": e["category"]}
                    for e in supporting
                ],
                "interpretation_source": primary.get("interpretation_source", "local"),
            }

        return _memo(f"pulse:{filters.signature()}", produce)

    def recommendations(self, filters: AnalysisFilters) -> list[dict]:
        """Recommendations derived from the analytics, not generic advice."""
        out: list[dict] = []
        events = self.intelligence(filters)
        trends = self.trend_results(filters)
        audience = self.audience(filters)

        for event in events:
            if event.get("recommended_action"):
                out.append({
                    "id": f"rec:{event['id']}",
                    "text": event["recommended_action"],
                    "basis": event["title"],
                    "severity": event["severity"],
                    "confidence": event["confidence"],
                    "confidence_band": event["confidence_band"],
                    "topic_id": event.get("topic_id"),
                })

        # Segment-level asymmetry is worth stating explicitly.
        populated = [s for s in audience["segments"] if s["posts"] >= 10]
        if len(populated) >= 2:
            most_negative = min(populated, key=lambda s: s["avg_polarity"])
            average = sum(s["avg_polarity"] for s in populated) / len(populated)
            if most_negative["avg_polarity"] < average - 0.12:
                topic = (most_negative["dominant_topics"][0]["topic_id"]
                         if most_negative["dominant_topics"] else "the leading topic")
                out.append({
                    "id": "rec:segment-asymmetry",
                    "text": (
                        f"{most_negative['name']} sit at {most_negative['avg_polarity']:+.2f} "
                        f"average polarity against a {average:+.2f} cross-segment average, "
                        f"concentrated on {topic}. Treat their concerns separately."
                    ),
                    "basis": "Cross-segment polarity comparison",
                    "severity": "medium",
                    "confidence": 0.74,
                    "confidence_band": "Medium",
                    "topic_id": (most_negative["dominant_topics"][0]["topic_id"]
                                 if most_negative["dominant_topics"] else None),
                })

        for trend in trends[:3]:
            if trend.momentum == "likely to continue growing" and trend.momentum_confidence >= 0.6:
                out.append({
                    "id": f"rec:momentum:{trend.topic_id}",
                    "text": (
                        f"At the current velocity ({trend.engagement_velocity:,.0f} "
                        f"interactions/hour, {trend.growth_rate:+.0f}% volume), this topic is "
                        f"forecast to keep growing. Establish a position within the next "
                        f"2-4 hours rather than after the next peak."
                    ),
                    "basis": f"Momentum forecast for {trend.topic_id}",
                    "severity": "high" if trend.trend_score >= 61 else "medium",
                    "confidence": trend.momentum_confidence,
                    "confidence_band": confidence_band(trend.momentum_confidence),
                    "topic_id": trend.topic_id,
                })

        seen: set[str] = set()
        deduped = []
        for rec in out:
            if rec["text"] in seen:
                continue
            seen.add(rec["text"])
            deduped.append(rec)
        return deduped[:8]

    # ------------------------------------------------------------------ #
    # Posts / timeline / search
    # ------------------------------------------------------------------ #
    def posts(self, filters: AnalysisFilters, page: int = 1, page_size: int = 25,
              sort: str = "recent") -> dict:
        rows = self.filtered_posts(filters)
        if sort == "engagement":
            rows = sorted(rows, key=lambda r: r.engagement_count, reverse=True)
        elif sort == "sarcasm":
            rows = sorted(rows, key=lambda r: (r.sarcasm_detected, r.engagement_count),
                          reverse=True)
        else:
            rows = sorted(rows, key=lambda r: r.created_at, reverse=True)

        total = len(rows)
        page = max(1, page)
        start = (page - 1) * page_size
        window = rows[start:start + page_size]

        ids = [r.id for r in window]
        details = {
            s.post_id: s for s in self.db.execute(
                select(SentimentResult).where(SentimentResult.post_id.in_(ids))).scalars()
        } if ids else {}
        anon = dict(self.db.execute(select(Author.id, Author.anon_id)).all())
        topic_labels = dict(self.db.execute(select(Topic.id, Topic.label)).all())

        items = []
        for r in window:
            detail = details.get(r.id)
            items.append({
                "id": r.id,
                "platform": r.platform,
                "author_anon_id": anon.get(r.author_id, "A?"),
                "text": r.text,
                "created_at": r.created_at.isoformat(),
                "language": r.language,
                "engagement": {
                    "total": r.engagement_count, "likes": r.likes,
                    "comments": r.comments_count, "shares": r.shares, "views": r.views,
                },
                "topic_id": r.topic_id,
                "topic_label": topic_labels.get(r.topic_id or "", None),
                "is_reply": bool(r.reply_to_id),
                "analysis": {
                    "sentiment": r.sentiment,
                    "sentiment_confidence": r.sentiment_confidence,
                    "confidence_band": confidence_band(r.sentiment_confidence or 0.0),
                    "polarity": r.polarity,
                    "emotion": r.emotion,
                    "emotion_confidence": detail.emotion_confidence if detail else None,
                    "stance": r.stance,
                    "sarcasm_detected": bool(r.sarcasm_detected),
                    "sarcasm_confidence": detail.sarcasm_confidence if detail else 0.0,
                    "literal_sentiment": detail.literal_sentiment if detail else None,
                    "contextual_sentiment": detail.contextual_sentiment if detail else None,
                    "cues": detail.cues if detail else {},
                    "model": detail.model if detail else None,
                    "model_version": detail.model_version if detail else None,
                    "status": detail.status if detail else None,
                } if detail else None,
            })

        return {
            "items": items, "page": page, "page_size": page_size, "total": total,
            "pages": max(1, (total + page_size - 1) // page_size),
        }

    def timeline_events(self, filters: AnalysisFilters) -> dict:
        """Chronological event feed combining volume, sentiment, influence and
        cross-platform milestones."""
        rows = self.filtered_posts(filters)
        if not rows:
            return {"events": [], "buckets": []}

        timeline = self.sentiment_timeline(filters)
        events: list[dict] = []

        for event in self.intelligence(filters):
            events.append({
                "ts": event["detected_at"],
                "kind": "intelligence",
                "category": event["category"],
                "title": event["title"],
                "detail": event["summary"],
                "severity": event["severity"],
                "topic_id": event.get("topic_id"),
                "reference_id": event["id"],
            })

        trends = self.trend_results(filters)
        for trend in trends[:6]:
            journey = build_journey(self.db, trend.topic_id, max_milestones=6)
            for milestone in journey["milestones"]:
                events.append({
                    "ts": milestone["ts"],
                    "kind": "journey",
                    "category": milestone["kind"],
                    "title": f"{trend.topic_id}: {milestone['title']}",
                    "detail": milestone["detail"],
                    "severity": "info",
                    "topic_id": trend.topic_id,
                    "reference_id": milestone.get("sample_post_id"),
                    "platform": milestone.get("platform"),
                })

        events.sort(key=lambda e: e["ts"], reverse=True)
        return {"events": events[:80], "buckets": timeline["points"]}

    def search(self, query: str, limit: int = 8) -> dict:
        needle = query.strip().lower()
        if len(needle) < 2:
            return {"query": query, "results": []}

        results: list[dict] = []

        for topic in self.db.execute(select(Topic)).scalars():
            haystack = f"{topic.label} {topic.description} {' '.join(topic.keywords or [])}".lower()
            if needle in haystack:
                results.append({
                    "type": "topic", "id": topic.id, "label": topic.label,
                    "detail": f"{topic.post_count} posts", "href": f"/topics/{topic.id}",
                })

        for segment in self.db.execute(select(AudienceSegment)).scalars():
            if needle in f"{segment.name} {segment.description}".lower():
                results.append({
                    "type": "segment", "id": segment.id, "label": segment.name,
                    "detail": f"{segment.size} accounts", "href": f"/audience?segment={segment.id}",
                })

        for author_id, anon_id, platform in self.db.execute(
            select(Author.id, Author.anon_id, Author.platform)
        ).all():
            if needle in anon_id.lower():
                results.append({
                    "type": "account", "id": author_id, "label": anon_id,
                    "detail": f"account on {platform}", "href": f"/network?node={author_id}",
                })

        for platform, count in self.db.execute(
            select(Post.platform, func.count(Post.id)).group_by(Post.platform)
        ).all():
            if needle in platform.lower():
                results.append({
                    "type": "platform", "id": platform, "label": platform,
                    "detail": f"{count} posts", "href": f"/?platform={platform}",
                })

        for event in self.db.execute(select(IntelligenceEvent)).scalars():
            if needle in f"{event.title} {event.summary}".lower():
                results.append({
                    "type": "event", "id": event.id, "label": event.title,
                    "detail": event.severity, "href": f"/timeline?event={event.id}",
                })

        matches = self.db.execute(
            select(Post.id, Post.text, Post.platform)
            .where(Post.text.ilike(f"%{query.strip()}%")).limit(limit)
        ).all()
        for post_id, text, platform in matches:
            results.append({
                "type": "post", "id": post_id, "label": text[:90],
                "detail": platform, "href": f"/posts?q={query}",
            })

        return {"query": query, "results": results[:limit * 3]}

    # ------------------------------------------------------------------ #
    def latest_run(self) -> dict | None:
        run = self.db.execute(
            select(AnalysisRun).order_by(AnalysisRun.started_at.desc()).limit(1)
        ).scalar_one_or_none()
        if run is None:
            return None
        return {
            "id": run.id,
            "status": run.status,
            "trigger": run.trigger,
            "seed": run.seed,
            "started_at": run.started_at.isoformat(),
            "finished_at": run.finished_at.isoformat() if run.finished_at else None,
            "posts_ingested": run.posts_ingested,
            "authors_ingested": run.authors_ingested,
            "sentiment_model": run.sentiment_model,
            "stage_log": run.stage_log,
            "validation": run.validation,
            "error": run.error,
        }
