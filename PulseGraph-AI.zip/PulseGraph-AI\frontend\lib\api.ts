/**
 * Backend client.
 *
 * One place builds URLs and one place turns a failed response into a typed
 * error, so every view can render a useful error state instead of a blank
 * panel. Raw exception text from the server is never shown to the user.
 */

import type {
  AnalyzeResult,
  AudienceResponse,
  FilterOptions,
  HealthResponse,
  IngestionResponse,
  InfluenceFlow,
  Influencer,
  IntelligenceCard,
  Journey,
  NetworkResponse,
  Overview,
  PostsResponse,
  Recommendation,
  SearchResult,
  SegmentComparison,
  SentimentTimeline,
  SourcesResponse,
  TimelineResponse,
  TopicDetail,
  TopicPlatforms,
  Trend,
} from '@/types/api';

export const API_BASE =
  process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, '') ?? 'http://127.0.0.1:8000';

export class ApiError extends Error {
  readonly status: number;
  readonly hint: string;
  readonly needsDataset: boolean;

  constructor(status: number, message: string, hint = '') {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.hint = hint;
    this.needsDataset = status === 409;
  }
}

/** Filter values shared by every analytical endpoint. */
export interface QueryFilters {
  range?: string;
  start?: string;
  end?: string;
  platforms?: string[];
  topics?: string[];
  segments?: string[];
  sentiments?: string[];
  emotions?: string[];
  search?: string;
  granularity?: string;
}

export function buildQuery(
  filters: QueryFilters = {},
  extra: Record<string, string | number | undefined> = {},
): string {
  const params = new URLSearchParams();
  const lists: [string, string[] | undefined][] = [
    ['platforms', filters.platforms],
    ['topics', filters.topics],
    ['segments', filters.segments],
    ['sentiments', filters.sentiments],
    ['emotions', filters.emotions],
  ];
  for (const [key, value] of lists) {
    if (value && value.length) params.set(key, value.join(','));
  }
  if (filters.range && filters.range !== 'all') params.set('range', filters.range);
  if (filters.start) params.set('start', filters.start);
  if (filters.end) params.set('end', filters.end);
  if (filters.search) params.set('search', filters.search);
  if (filters.granularity) params.set('granularity', filters.granularity);
  for (const [key, value] of Object.entries(extra)) {
    if (value !== undefined && value !== '') params.set(key, String(value));
  }
  const query = params.toString();
  return query ? `?${query}` : '';
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      ...init,
      headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
      cache: 'no-store',
    });
  } catch {
    throw new ApiError(
      0,
      'Cannot reach the PulseGraph backend.',
      `Start it with: uvicorn app.main:app --reload  (expected at ${API_BASE})`,
    );
  }

  if (!response.ok) {
    let detail = `Request failed with status ${response.status}.`;
    let hint = '';
    try {
      const body = await response.json();
      detail = body.detail ?? body.error ?? detail;
      hint = body.hint ?? '';
    } catch {
      /* non-JSON error body: keep the generic message */
    }
    throw new ApiError(response.status, String(detail), hint);
  }

  return (await response.json()) as T;
}

export const api = {
  health: () => request<HealthResponse>('/api/health'),
  filterOptions: () => request<FilterOptions>('/api/meta/filters'),

  overview: (f: QueryFilters) => request<Overview>(`/api/overview${buildQuery(f)}`),
  sentimentTimeline: (f: QueryFilters) =>
    request<SentimentTimeline>(`/api/sentiment/timeline${buildQuery(f)}`),

  trends: (f: QueryFilters) =>
    request<{ items: Trend[] }>(`/api/trends${buildQuery(f)}`),
  topic: (topicId: string, f: QueryFilters) =>
    request<TopicDetail>(`/api/topics/${encodeURIComponent(topicId)}${buildQuery(f)}`),
  journey: (topicId: string) =>
    request<Journey>(`/api/topics/${encodeURIComponent(topicId)}/journey`),
  topicPlatforms: (topicId: string, f: QueryFilters) =>
    request<TopicPlatforms>(
      `/api/topics/${encodeURIComponent(topicId)}/platforms${buildQuery(f)}`,
    ),

  audience: (f: QueryFilters) => request<AudienceResponse>(`/api/audience${buildQuery(f)}`),
  compareSegments: (left: string, right: string, f: QueryFilters) =>
    request<SegmentComparison>(`/api/audience/compare${buildQuery(f, { left, right })}`),

  network: (f: QueryFilters, maxNodes = 140) =>
    request<NetworkResponse>(`/api/network${buildQuery(f, { max_nodes: maxNodes })}`),
  influencers: (f: QueryFilters, limit = 10) =>
    request<{ items: Influencer[] }>(
      `/api/network/influencers${buildQuery(f, { limit })}`,
    ),
  influenceFlow: (topicId: string, f: QueryFilters) =>
    request<InfluenceFlow>(
      `/api/network/flow/${encodeURIComponent(topicId)}${buildQuery(f)}`,
    ),

  intelligence: (f: QueryFilters, topicId?: string) =>
    request<{ items: IntelligenceCard[] }>(
      `/api/intelligence${buildQuery(f, { topic_id: topicId })}`,
    ),
  recommendations: (f: QueryFilters) =>
    request<{ items: Recommendation[] }>(
      `/api/intelligence/recommendations${buildQuery(f)}`,
    ),

  timeline: (f: QueryFilters) => request<TimelineResponse>(`/api/timeline${buildQuery(f)}`),

  posts: (f: QueryFilters, page = 1, pageSize = 25, sort = 'recent') =>
    request<PostsResponse>(
      `/api/posts${buildQuery(f, { page, page_size: pageSize, sort })}`,
    ),

  search: (q: string) => request<{ query: string; results: SearchResult[] }>(
    `/api/search?q=${encodeURIComponent(q)}`,
  ),

  sources: () => request<SourcesResponse>('/api/sources'),
  loadDemo: (body: { sources?: string[]; seed?: number; target_posts?: number } = {}) =>
    request<IngestionResponse>('/api/ingestion/demo', {
      method: 'POST',
      body: JSON.stringify({ sources: ['demo'], ...body }),
    }),
  resetDemo: () =>
    request<IngestionResponse>('/api/ingestion/reset', { method: 'POST' }),

  analyze: (text: string, language = 'en') =>
    request<AnalyzeResult>('/api/analyze', {
      method: 'POST',
      body: JSON.stringify({ text, language }),
    }),
};
