'use client';

/**
 * Topic deep dive.
 *
 * Brings the whole intelligence stack to bear on one topic: trend and momentum,
 * sentiment composition, the AI summary with its evidence, the Narrative
 * Journey, cross-platform divergence, observed propagation and the accounts
 * driving it.
 */

import Link from 'next/link';
import { ArrowLeft, Hash, Radar } from 'lucide-react';

import { PlatformDivergence } from '@/components/charts/PlatformDivergence';
import { WhyPanel } from '@/components/ui/Evidence';
import {
  Badge,
  Bar,
  EmptyState,
  ErrorState,
  Panel,
  PanelSkeleton,
  SentimentBadge,
  TrendBadge,
  cx,
} from '@/components/ui/primitives';
import { NarrativeJourney } from '@/features/journey/NarrativeJourney';
import { IntelligenceFeed } from '@/features/intelligence/IntelligenceFeed';
import { filterKey, useFilters } from '@/features/filters/FilterContext';
import { useApi } from '@/hooks/useApi';
import { api } from '@/lib/api';
import { COLORS, SENTIMENT_COLORS, polarityColor } from '@/lib/colors';
import { compactNumber, growth, platformLabel, polarity, titleCase } from '@/lib/format';
import type { TopicDetail, TopicPlatforms } from '@/types/api';

function VelocityBlock({ detail }: { detail: TopicDetail }) {
  if (!detail.trend) return null;
  const { velocity, momentum, classification, trend_score } = detail.trend;

  const cells: { label: string; value: string; tone?: string }[] = [
    { label: 'Mentions (current period)', value: compactNumber(velocity.current_mentions) },
    { label: 'Previous period', value: compactNumber(velocity.previous_mentions) },
    {
      label: 'Volume growth',
      value: growth(velocity.growth_percentage),
      tone: velocity.growth_percentage > 0 ? 'text-negative' : 'text-positive',
    },
    { label: 'Acceleration', value: velocity.acceleration.toFixed(2) },
    { label: 'Engagement / hour', value: compactNumber(velocity.engagement_velocity) },
    { label: 'Engagement growth', value: growth(velocity.engagement_growth) },
    { label: 'Unique authors', value: compactNumber(velocity.unique_authors) },
    { label: 'Author growth', value: growth(velocity.author_growth) },
  ];

  return (
    <Panel
      title="Trend velocity"
      subtitle="Current period against the immediately preceding one of equal length"
      actions={<TrendBadge classification={classification} score={trend_score} />}
    >
      <dl className="grid grid-cols-2 gap-x-4 gap-y-2.5 sm:grid-cols-4">
        {cells.map((cell) => (
          <div key={cell.label}>
            <dt className="text-[10px] leading-tight text-ink-faint">{cell.label}</dt>
            <dd
              className={cx(
                'mt-0.5 font-mono text-sm tabular-nums',
                cell.tone ?? 'text-ink',
              )}
            >
              {cell.value}
            </dd>
          </div>
        ))}
      </dl>

      <div className="mt-3 rounded border border-edge-subtle bg-canvas-sunken px-3 py-2">
        <p className="text-2xs font-semibold uppercase tracking-wider text-ink-faint">
          Momentum forecast
        </p>
        <p className="mt-1 text-2xs text-ink-muted">
          <span className="font-medium text-ink">{titleCase(momentum.label)}</span> ·{' '}
          {momentum.confidence_band} confidence ({momentum.confidence.toFixed(2)}) · next
          interval estimate {momentum.forecast_next_bucket.toFixed(0)} mentions
        </p>
        <p className="mt-1 text-[10px] leading-relaxed text-ink-faint">
          An estimate from exponential smoothing and the slope of recent intervals. It is a
          momentum forecast, not a guaranteed prediction.
        </p>
      </div>

      <WhyPanel
        label="How was this scored?"
        evidence={Object.entries(detail.trend.components.values ?? {}).map(([metric, value]) => ({
          metric,
          value,
          change:
            detail.trend!.components.weights?.[metric] !== undefined
              ? `weight ${detail.trend!.components.weights[metric]}`
              : undefined,
          period: 'normalised 0–1',
        }))}
        method={detail.trend.components.formula}
      />
    </Panel>
  );
}

function AiSummary({ detail }: { detail: TopicDetail }) {
  const journey = detail.journey;
  const lead = journey.lead_lag?.[0];
  const topSegment = detail.audience.segments[0];
  // "unknown" means no public signal supported an inference — reporting it as a
  // concentration would misrepresent an absence of evidence as a finding.
  const topAge = detail.audience.age_brackets.find((b) => b.bracket !== 'unknown');
  const velocity = detail.trend?.velocity;

  // Composed strictly from values already present in the payload.
  const sentences: string[] = [];
  if (velocity) {
    sentences.push(
      `Interest in ${detail.topic.label} moved ${growth(velocity.growth_percentage)} over the last period, from ${velocity.previous_mentions} to ${velocity.current_mentions} mentions across ${detail.platforms.length} platforms.`,
    );
  }
  if (lead) {
    sentences.push(
      `The increase appeared first on ${platformLabel(lead.lead_platform)}, followed about ${Math.round(lead.minutes)} minutes later by ${platformLabel(lead.lag_platform)}.`,
    );
  }
  if (topSegment) {
    sentences.push(
      `${topSegment.name} account for ${topSegment.percentage}% of segmented posts on this topic${topAge ? `, concentrated in the ${topAge.bracket} bracket` : ''}.`,
    );
  }
  const influentialCount = detail.top_accounts.filter((a) => a.influence_score >= 20).length;
  if (influentialCount) {
    sentences.push(
      `${influentialCount} high-centrality accounts participated during this window.`,
    );
  }
  if (detail.sentiment.sarcasm_rate > 0.04) {
    sentences.push(
      `${(detail.sentiment.sarcasm_rate * 100).toFixed(0)}% of posts were read as sarcastic, so a literal keyword reading would overstate positive sentiment here.`,
    );
  }

  return (
    <Panel
      title={
        <span className="flex items-center gap-1.5">
          <Radar className="h-3.5 w-3.5 text-trend" aria-hidden />
          AI summary
        </span>
      }
      subtitle="Generated from the computed analytics on this page — every figure appears in the evidence below"
    >
      <p className="text-pretty text-[13px] leading-relaxed text-ink">
        {sentences.join(' ')}
      </p>

      <WhyPanel
        defaultOpen={false}
        evidence={[
          ...(velocity
            ? [
                {
                  metric: 'mentions',
                  value: velocity.current_mentions,
                  change: growth(velocity.growth_percentage),
                  period: 'current vs previous period',
                },
                {
                  metric: 'engagement_velocity',
                  value: velocity.engagement_velocity,
                  period: 'interactions per hour',
                },
              ]
            : []),
          {
            metric: 'avg_polarity',
            value: detail.sentiment.avg_polarity,
            period: `${detail.post_count} posts`,
          },
          {
            metric: 'sarcasm_rate',
            value: detail.sentiment.sarcasm_rate,
            period: 'share of posts on this topic',
          },
          { metric: 'platforms_with_activity', value: detail.platforms.length, period: 'window' },
          ...(lead
            ? [
                {
                  metric: 'lead_time_minutes',
                  value: Math.round(lead.minutes),
                  period: `${lead.lead_platform} → ${lead.lag_platform}`,
                  note: 'Ordering of sustained activity onset; not causal.',
                },
              ]
            : []),
          ...(topSegment
            ? [
                {
                  metric: 'dominant_segment_share',
                  value: `${topSegment.percentage}%`,
                  period: topSegment.name,
                },
              ]
            : []),
        ]}
        method="Sentences are templated from computed values. No figure is generated by a model."
      />
    </Panel>
  );
}

export function TopicView({ topicId }: { topicId: string }) {
  const { filters } = useFilters();
  const key = filterKey(filters);

  const topic = useApi<TopicDetail>(`topic:${topicId}:${key}`, () =>
    api.topic(topicId, filters),
  );
  const platforms = useApi<TopicPlatforms>(`topic-platforms:${topicId}:${key}`, () =>
    api.topicPlatforms(topicId, filters),
  );

  if (topic.error) {
    return (
      <Panel>
        <ErrorState error={topic.error} onRetry={topic.reload} />
      </Panel>
    );
  }

  const detail = topic.data;
  const maxKeyword = Math.max(...(detail?.keywords.map((k) => k.score) ?? [1]), 1);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="min-w-0">
          <Link
            href="/dashboard"
            className="inline-flex items-center gap-1 text-2xs text-ink-faint hover:text-ink"
          >
            <ArrowLeft className="h-3 w-3" aria-hidden />
            Dashboard
          </Link>
          <h1 className="mt-1 truncate text-lg font-semibold tracking-tight text-ink">
            {detail?.topic.label ?? topicId}
          </h1>
          {detail && (
            <p className="mt-0.5 text-2xs text-ink-muted">{detail.topic.description}</p>
          )}
        </div>

        {detail && (
          <div className="flex flex-wrap items-center gap-1.5">
            <Badge tone="neutral">{compactNumber(detail.post_count)} posts</Badge>
            <SentimentBadge
              sentiment={
                detail.sentiment.avg_polarity <= -0.12
                  ? 'negative'
                  : detail.sentiment.avg_polarity >= 0.12
                    ? 'positive'
                    : 'neutral'
              }
              value={polarity(detail.sentiment.avg_polarity)}
            />
            {detail.trend && (
              <TrendBadge
                classification={detail.trend.classification}
                score={detail.trend.trend_score}
              />
            )}
          </div>
        )}
      </div>

      {topic.loading && (
        <Panel>
          <PanelSkeleton rows={8} height="h-8" />
        </Panel>
      )}

      {detail && (
        <>
          <AiSummary detail={detail} />
          <VelocityBlock detail={detail} />

          <div className="grid gap-3 lg:grid-cols-2">
            <NarrativeJourney journey={detail.journey} />

            <div className="space-y-3">
              <Panel
                title="Sentiment composition"
                subtitle={`${detail.post_count} posts · ${(detail.sentiment.sarcasm_rate * 100).toFixed(1)}% read as sarcastic`}
              >
                <div className="space-y-2">
                  {detail.sentiment.distribution.map((row) => (
                    <div key={row.sentiment} className="flex items-center gap-2.5">
                      <span className="w-16 shrink-0 text-2xs capitalize text-ink-muted">
                        {row.sentiment}
                      </span>
                      <div className="flex-1">
                        <Bar
                          value={row.percentage}
                          max={100}
                          color={SENTIMENT_COLORS[row.sentiment]}
                        />
                      </div>
                      <span className="w-16 shrink-0 text-right font-mono text-2xs tabular-nums text-ink">
                        {row.percentage}%
                        <span className="ml-1 text-ink-faint">{row.count}</span>
                      </span>
                    </div>
                  ))}
                </div>
              </Panel>

              <Panel
                title={
                  <span className="flex items-center gap-1.5">
                    <Hash className="h-3.5 w-3.5 text-trend" aria-hidden />
                    Distinctive keywords
                  </span>
                }
                subtitle="TF-IDF terms that separate this topic from the rest of the corpus"
              >
                {detail.keywords.length === 0 && (
                  <EmptyState title="Not enough text to extract distinctive terms" />
                )}
                <div className="space-y-1.5">
                  {detail.keywords.map((keyword) => (
                    <div key={keyword.term} className="flex items-center gap-2.5">
                      <span className="w-28 shrink-0 truncate font-mono text-2xs text-ink-muted">
                        {keyword.term}
                      </span>
                      <div className="flex-1">
                        <Bar value={keyword.score} max={maxKeyword} color={COLORS.trend} />
                      </div>
                      <span className="w-20 shrink-0 text-right font-mono text-[10px] tabular-nums text-ink-faint">
                        {keyword.mentions}× · lift {keyword.lift.toFixed(1)}
                      </span>
                    </div>
                  ))}
                </div>
              </Panel>

              <Panel
                title="Audience composition"
                subtitle="Segments and inferred demographics for accounts posting on this topic"
              >
                <div className="space-y-1.5">
                  {detail.audience.segments.map((segment) => (
                    <div key={segment.segment_id} className="flex items-center gap-2.5">
                      <span className="w-36 shrink-0 truncate text-2xs text-ink-muted">
                        {segment.name}
                      </span>
                      <div className="flex-1">
                        <Bar value={segment.percentage} max={100} color={COLORS.influence} />
                      </div>
                      <span className="w-14 shrink-0 text-right font-mono text-2xs tabular-nums text-ink">
                        {segment.percentage}%
                      </span>
                    </div>
                  ))}
                </div>

                <div className="mt-3 border-t border-edge-subtle pt-2.5">
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-faint">
                    Inferred age brackets
                  </p>
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    {detail.audience.age_brackets.map((bracket) => (
                      <Badge key={bracket.bracket} tone="neutral">
                        {bracket.bracket}: {bracket.percentage}%
                      </Badge>
                    ))}
                  </div>
                  <p className="mt-1.5 text-[10px] leading-relaxed text-ink-faint">
                    Aggregate inference from public signals, not verified attributes.
                  </p>
                </div>
              </Panel>
            </div>
          </div>

          <div className="grid gap-3 lg:grid-cols-2">
            <PlatformDivergence
              platforms={platforms.data?.platforms ?? detail.platforms}
              divergence={platforms.data?.divergence}
              interpretation={platforms.data?.interpretation}
              loading={platforms.loading}
            />

            <Panel
              title="Observed propagation"
              subtitle="How activity spread outward from the earliest participants"
            >
              {platforms.loading && <PanelSkeleton rows={4} height="h-8" />}
              {platforms.data && platforms.data.flow.layers.length === 0 && (
                <EmptyState
                  title="No propagation path"
                  description="This topic has too few cross-account interactions to trace a path."
                />
              )}
              {platforms.data && platforms.data.flow.layers.length > 0 && (
                <>
                  <ol className="space-y-2">
                    {platforms.data.flow.layers.map((layer) => (
                      <li key={layer.hop} className="flex items-start gap-2.5">
                        <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-influence/12 font-mono text-[10px] text-influence">
                          {layer.hop}
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="text-2xs text-ink">
                            {layer.accounts} accounts reached across{' '}
                            {layer.communities.length} communit
                            {layer.communities.length === 1 ? 'y' : 'ies'}
                          </p>
                          <div className="mt-1 flex flex-wrap gap-1">
                            {layer.sample_nodes.map((node) => (
                              <Badge key={node} tone="neutral">
                                {node}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </li>
                    ))}
                  </ol>
                  <p className="mt-3 border-t border-edge-subtle pt-2 text-[10px] leading-relaxed text-ink-faint">
                    {platforms.data.flow.disclaimer}
                  </p>
                </>
              )}
            </Panel>
          </div>

          <Panel
            title="Top contributing accounts"
            subtitle="Ranked by network influence, then by engagement earned on this topic"
            dense
          >
            <div className="scroll-x">
              <table className="w-full min-w-[640px] border-collapse text-2xs">
                <thead>
                  <tr className="border-b border-edge-subtle text-left text-ink-faint">
                    <th className="px-4 py-2 font-medium">Account</th>
                    <th className="px-2 py-2 text-right font-medium">Influence</th>
                    <th className="px-2 py-2 text-right font-medium">Posts</th>
                    <th className="px-2 py-2 text-right font-medium">Engagement</th>
                    <th className="px-2 py-2 font-medium">Segment</th>
                    <th className="px-4 py-2 font-medium">Community</th>
                  </tr>
                </thead>
                <tbody>
                  {detail.top_accounts.map((account) => (
                    <tr
                      key={account.anon_id}
                      className="border-b border-edge-subtle/60 last:border-0 hover:bg-canvas-hover/40"
                    >
                      <td className="px-4 py-2">
                        <Link
                          href={`/network?node=${encodeURIComponent(account.anon_id)}`}
                          className="font-mono text-ink hover:underline"
                        >
                          {account.anon_id}
                        </Link>
                        {account.is_bridge && (
                          <Badge tone="warning" className="ml-1.5">
                            bridge
                          </Badge>
                        )}
                      </td>
                      <td className="px-2 py-2 text-right font-mono tabular-nums text-ink-muted">
                        {account.influence_score.toFixed(1)}
                      </td>
                      <td className="px-2 py-2 text-right font-mono tabular-nums text-ink-muted">
                        {account.posts}
                      </td>
                      <td className="px-2 py-2 text-right font-mono tabular-nums text-ink-muted">
                        {compactNumber(account.engagement)}
                      </td>
                      <td className="px-2 py-2 text-ink-muted">{account.segment}</td>
                      <td className="px-4 py-2 font-mono text-ink-faint">
                        #{account.community_id ?? '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>

          <IntelligenceFeed
            cards={detail.intelligence}
            title="Detections for this topic"
            subtitle="Every intelligence event the engine attributed to this topic"
          />
        </>
      )}
    </div>
  );
}
