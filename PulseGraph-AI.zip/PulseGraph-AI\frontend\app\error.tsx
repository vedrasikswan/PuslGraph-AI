'use client';

import { useEffect } from 'react';

/** Route-level error boundary. Users never see a stack trace. */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error('Unhandled view error:', error);
  }, [error]);

  return (
    <div className="grid min-h-[60vh] place-items-center px-6">
      <div className="max-w-md text-center">
        <h1 className="text-lg font-semibold text-ink">Something went wrong in this view</h1>
        <p className="mt-2 text-2xs leading-relaxed text-ink-muted">
          The rest of the application is unaffected. Retrying re-runs the queries for the
          current filters.
        </p>
        {error.digest && (
          <p className="mt-1 font-mono text-[10px] text-ink-faint">ref {error.digest}</p>
        )}
        <button
          type="button"
          onClick={reset}
          className="mt-4 rounded border border-edge-strong px-3 py-1.5 text-2xs text-ink-muted hover:bg-canvas-hover hover:text-ink"
        >
          Retry
        </button>
      </div>
    </div>
  );
}
