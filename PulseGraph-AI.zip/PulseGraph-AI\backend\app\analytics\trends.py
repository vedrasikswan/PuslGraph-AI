"""Trend detection, velocity and momentum forecasting.

All of this is deterministic time-series statistics, not model output. A trend
score is a weighted, normalised blend of six measurable components; every
component is returned alongside the score so the UI can show the arithmetic
instead of asserting a number.

The forecast layer is intentionally lightweight - exponential smoothing plus a
slope on the recent buckets - and is labelled a *momentum forecast* with a
confidence, never a prediction.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta

CLASSIFICATIONS: list[tuple[float, str]] = [
    (81.0, "viral"),
    (61.0, "accelerating"),
    (41.0, "growing"),
    (21.0, "emerging"),
    (0.0, "stable"),
]


@dataclass(slots=True)
class TopicObservation:
    """One post's contribution to a topic, already extracted from the DB."""

    timestamp: datetime
    author_id: str
    platform: str
    engagement: int
    polarity: float
    influence_score: float = 0.0


@dataclass(slots=True)
class TrendResult:
    topic_id: str
    window_start: datetime
    window_end: datetime
    mentions: int = 0
    prev_mentions: int = 0
    growth_rate: float = 0.0
    acceleration: float = 0.0
    engagement_velocity: float = 0.0
    prev_engagement_velocity: float = 0.0
    unique_authors: int = 0
    prev_unique_authors: int = 0
    author_growth: float = 0.0
    sentiment_shift: float = 0.0
    current_polarity: float = 0.0
    prev_polarity: float = 0.0
    platform_count: int = 0
    platforms: list[str] = field(default_factory=list)
    influencer_participation: float = 0.0
    persistence: float = 0.0
    trend_score: float = 0.0
    classification: str = "stable"
    momentum: str = "stabilising"
    momentum_confidence: float = 0.0
    forecast_next: float = 0.0
    components: dict = field(default_factory=dict)
    series: list[dict] = field(default_factory=list)


def bucket_size_for(hours: float) -> timedelta:
    if hours <= 12:
        return timedelta(minutes=30)
    if hours <= 48:
        return timedelta(hours=1)
    if hours <= 24 * 10:
        return timedelta(hours=3)
    return timedelta(days=1)


def _floor(ts: datetime, size: timedelta) -> datetime:
    seconds = int(size.total_seconds())
    epoch = int(ts.timestamp())
    return datetime.fromtimestamp(epoch - (epoch % seconds))


def build_series(
    observations: list[TopicObservation], start: datetime, end: datetime, size: timedelta
) -> list[dict]:
    """Zero-filled time buckets so gaps are visible rather than interpolated."""
    buckets: dict[datetime, dict] = {}
    cursor = _floor(start, size)
    stop = _floor(end, size)
    while cursor <= stop:
        buckets[cursor] = {"ts": cursor, "mentions": 0, "engagement": 0,
                           "authors": set(), "polarity_sum": 0.0}
        cursor += size

    for obs in observations:
        key = _floor(obs.timestamp, size)
        bucket = buckets.get(key)
        if bucket is None:
            continue
        bucket["mentions"] += 1
        bucket["engagement"] += obs.engagement
        bucket["authors"].add(obs.author_id)
        bucket["polarity_sum"] += obs.polarity

    series = []
    for key in sorted(buckets):
        b = buckets[key]
        series.append({
            "ts": key,
            "mentions": b["mentions"],
            "engagement": b["engagement"],
            "unique_authors": len(b["authors"]),
            "avg_polarity": round(b["polarity_sum"] / b["mentions"], 4) if b["mentions"] else 0.0,
        })
    return series


def exponential_smoothing(values: list[float], alpha: float = 0.4) -> list[float]:
    if not values:
        return []
    smoothed = [float(values[0])]
    for value in values[1:]:
        smoothed.append(alpha * float(value) + (1 - alpha) * smoothed[-1])
    return smoothed


def linear_slope(values: list[float]) -> float:
    """Least-squares slope per bucket."""
    n = len(values)
    if n < 2:
        return 0.0
    mean_x = (n - 1) / 2.0
    mean_y = sum(values) / n
    num = sum((i - mean_x) * (v - mean_y) for i, v in enumerate(values))
    den = sum((i - mean_x) ** 2 for i in range(n))
    return num / den if den else 0.0


def _growth(current: float, previous: float) -> float:
    """Percentage growth that stays finite when the baseline is zero."""
    if previous > 0:
        return (current - previous) / previous * 100.0
    if current > 0:
        return 100.0 * min(current, 12)  # capped so a 0 -> n jump cannot dominate
    return 0.0


FLAT_GROWTH_SCORE = 0.18
GROWTH_CEILING_PCT = 900.0

# Evidence weighting: mention volume at which a trend score carries full weight,
# and the floor applied to a topic with almost no volume behind it.
VOLUME_SATURATION = 300
MIN_EVIDENCE_WEIGHT = 0.25


def _normalise_growth(pct: float) -> float:
    """Map an unbounded growth percentage into 0..1 with diminishing returns.

    Anchored so that flat volume scores low (a topic that is not moving is not
    trending) and decline approaches zero. A ~900% jump saturates the scale.
    """
    if pct <= 0:
        return max(0.0, FLAT_GROWTH_SCORE * (1 + pct / 100.0))
    span = math.log10(1 + GROWTH_CEILING_PCT / 25.0)
    return min(1.0, FLAT_GROWTH_SCORE + (1 - FLAT_GROWTH_SCORE) * math.log10(1 + pct / 25.0) / span)


def classify(score: float) -> str:
    for threshold, label in CLASSIFICATIONS:
        if score >= threshold:
            return label
    return "stable"


def analyse_topic(
    topic_id: str,
    observations: list[TopicObservation],
    window_start: datetime,
    window_end: datetime,
    influencer_ids: set[str],
    total_platforms: int = 6,
) -> TrendResult:
    """Compute the full trend profile for one topic inside one window."""
    span = window_end - window_start
    half = span / 2
    mid = window_start + half

    current = [o for o in observations if mid <= o.timestamp <= window_end]
    previous = [o for o in observations if window_start <= o.timestamp < mid]

    result = TrendResult(topic_id=topic_id, window_start=window_start, window_end=window_end)
    result.mentions = len(current)
    result.prev_mentions = len(previous)

    hours = max(half.total_seconds() / 3600.0, 0.25)
    result.growth_rate = round(_growth(len(current), len(previous)), 2)

    current_engagement = sum(o.engagement for o in current)
    previous_engagement = sum(o.engagement for o in previous)
    result.engagement_velocity = round(current_engagement / hours, 2)
    result.prev_engagement_velocity = round(previous_engagement / hours, 2)

    current_authors = {o.author_id for o in current}
    previous_authors = {o.author_id for o in previous}
    result.unique_authors = len(current_authors)
    result.prev_unique_authors = len(previous_authors)
    result.author_growth = round(_growth(len(current_authors), len(previous_authors)), 2)

    result.current_polarity = round(
        sum(o.polarity for o in current) / len(current), 4) if current else 0.0
    result.prev_polarity = round(
        sum(o.polarity for o in previous) / len(previous), 4) if previous else 0.0
    result.sentiment_shift = round(result.current_polarity - result.prev_polarity, 4)

    platforms = sorted({o.platform for o in current})
    result.platforms = platforms
    result.platform_count = len(platforms)

    if current:
        influencer_posts = sum(1 for o in current if o.author_id in influencer_ids)
        result.influencer_participation = round(influencer_posts / len(current), 4)

    # Persistence: fraction of buckets in the window that saw any activity.
    size = bucket_size_for(span.total_seconds() / 3600.0)
    series = build_series(observations, window_start, window_end, size)
    result.series = [{**s, "ts": s["ts"].isoformat()} for s in series]
    active = sum(1 for s in series if s["mentions"] > 0)
    result.persistence = round(active / len(series), 4) if series else 0.0

    # --- composite score -------------------------------------------------
    volume_growth = _normalise_growth(result.growth_rate)
    engagement_component = _normalise_growth(
        _growth(result.engagement_velocity, result.prev_engagement_velocity)
    )
    author_component = _normalise_growth(result.author_growth)
    # A single platform is not "spread"; each additional one adds evidence.
    spread_component = min(1.0, max(0, result.platform_count - 1) / max(total_platforms - 1, 1))
    influencer_component = min(1.0, result.influencer_participation * 3.2)
    persistence_component = result.persistence
    volume_floor = min(1.0, math.log10(1 + result.mentions) / math.log10(220))

    components = {
        "volume_growth": round(volume_growth, 4),
        "engagement_velocity": round(engagement_component, 4),
        "unique_author_growth": round(author_component, 4),
        "cross_platform_spread": round(spread_component, 4),
        "influencer_activity": round(influencer_component, 4),
        "persistence": round(persistence_component, 4),
        "volume_floor": round(volume_floor, 4),
    }
    weights = {
        "volume_growth": 0.26,
        "engagement_velocity": 0.2,
        "unique_author_growth": 0.16,
        "cross_platform_spread": 0.13,
        "influencer_activity": 0.1,
        "persistence": 0.07,
        "volume_floor": 0.08,
    }
    raw = sum(components[k] * w for k, w in weights.items())

    # Evidence discount: percentage growth off a small base is cheap. Confidence
    # in a trend score should scale with the volume behind it, so the score is
    # attenuated on a log curve that only reaches full weight around
    # VOLUME_SATURATION mentions. Without this, a topic going 5 -> 70 outranks
    # one going 9 -> 533 purely on percentages.
    discount = min(
        1.0,
        MIN_EVIDENCE_WEIGHT
        + (1 - MIN_EVIDENCE_WEIGHT)
        * math.log10(1 + result.mentions)
        / math.log10(1 + VOLUME_SATURATION),
    )
    components["small_sample_discount"] = round(discount, 4)

    result.trend_score = round(min(100.0, max(0.0, raw * discount * 100.0)), 2)
    result.classification = classify(result.trend_score)
    result.components = {
        "weights": weights,
        "values": components,
        "formula": (
            "trend_score = 100 x small_sample_discount x (0.26*volume_growth + "
            "0.20*engagement_velocity + 0.16*unique_author_growth + "
            "0.13*cross_platform_spread + 0.10*influencer_activity + "
            "0.07*persistence + 0.08*volume_floor)"
        ),
    }

    # --- momentum forecast ------------------------------------------------
    mentions_series = [s["mentions"] for s in series]
    result.momentum, result.momentum_confidence, result.forecast_next, accel = forecast_momentum(
        mentions_series
    )
    result.acceleration = accel
    return result


def forecast_momentum(mentions: list[float]) -> tuple[str, float, float, float]:
    """Lightweight momentum forecast.

    Returns (label, confidence, next-bucket estimate, acceleration).
    Deliberately simple: exponential smoothing for level, least-squares slope on
    the recent tail for direction, and the change in slope for acceleration.
    """
    if len(mentions) < 4:
        return "insufficient_data", 0.3, float(mentions[-1] if mentions else 0.0), 0.0

    smoothed = exponential_smoothing([float(m) for m in mentions], alpha=0.4)
    tail = smoothed[-6:] if len(smoothed) >= 6 else smoothed
    prior = smoothed[-12:-6] if len(smoothed) >= 12 else smoothed[: max(1, len(smoothed) - len(tail))]

    slope = linear_slope(tail)
    prior_slope = linear_slope(prior) if len(prior) >= 2 else 0.0
    acceleration = round(slope - prior_slope, 4)

    level = max(sum(tail) / len(tail), 0.5)
    relative_slope = slope / level

    forecast_next = max(0.0, round(smoothed[-1] + slope, 2))

    if relative_slope > 0.12:
        label = "likely to continue growing"
    elif relative_slope < -0.12:
        label = "likely to decline"
    else:
        label = "likely to stabilise"

    # Confidence reflects how consistent the recent direction is.
    directions = [1 if b > a else -1 if b < a else 0
                  for a, b in zip(tail, tail[1:])]
    if directions:
        agreement = abs(sum(directions)) / len(directions)
    else:
        agreement = 0.0
    volume_support = min(1.0, level / 12.0)
    confidence = round(min(0.92, 0.4 + 0.35 * agreement + 0.25 * volume_support), 3)

    return label, confidence, forecast_next, acceleration


def velocity_summary(result: TrendResult) -> dict:
    """The headline velocity block the dashboard renders."""
    direction = "up" if result.growth_rate > 2 else "down" if result.growth_rate < -2 else "flat"
    return {
        "current_mentions": result.mentions,
        "previous_mentions": result.prev_mentions,
        "growth_percentage": result.growth_rate,
        "direction": direction,
        "acceleration": result.acceleration,
        "engagement_velocity": result.engagement_velocity,
        "previous_engagement_velocity": result.prev_engagement_velocity,
        "engagement_growth": round(
            _growth(result.engagement_velocity, result.prev_engagement_velocity), 2
        ),
        "unique_authors": result.unique_authors,
        "author_growth": result.author_growth,
    }
