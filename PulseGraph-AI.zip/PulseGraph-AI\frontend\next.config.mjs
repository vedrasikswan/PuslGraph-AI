/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  eslint: { dirs: ['app', 'components', 'features', 'lib', 'hooks', 'types'] },
};

export default nextConfig;
