'use client';

/**
 * Data ingestion page.
 *
 * Shows the real status of every adapter (credentials present or not — never a
 * fabricated connection), the demo controls, the last pipeline run with its
 * per-stage timings and seed validation, and a live NLP probe so the sarcasm
 * reasoning can be demonstrated on arbitrary text.
 */

import { useState } from 'react';
import {
  CheckCircle2,
  CircleSlash,
  Cpu,
  FlaskConical,
  Loader2,
  Play,
  RotateCcw,
  XCircle,
} from 'lucide-react';

import {
  Badge,
  ConfidenceBadge,
  EmptyState,
  ErrorState,
  Panel,
  PanelSkeleton,
  SentimentBadge,
  cx,
} from '@/components/ui/primitives';
import { clearApiCache, useApi } from '@/hooks/useApi';
import { ApiError, api } from '@/lib/api';
import { compactNumber, dateTime, platformLabel, polarity, titleCase } from '@/lib/format';
import type { AnalyzeResult, SourceInfo, SourcesResponse } from '@/types/api';

const TIER_COPY: Record<string, { label: string; tone: 'negative' | 'warning' | 'neutral' | 'trend' }> = {
  essential: { label: 'Essential', tone: 'negative' },
  desirable: { label: 'Good to have', tone: 'warning' },
  appreciable: { label: 'Appreciable', tone: 'neutral' },
  synthetic: { label: 'Synthetic', tone: 'trend' },
};

function SourceCard({ source }: { source: SourceInfo }) {
  const tier = TIER_COPY[source.tier] ?? TIER_COPY.appreciable;
  const connected = source.live_ready;

  return (
    <div className="rounded border border-edge bg-canvas-raised p-3">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate text-[13px] font-medium text-ink">{source.display_name}</p>
          <p className="mt-0.5 text-[10px] text-ink-faint">{platformLabel(source.platform)}</p>
        </div>
        <Badge tone={tier.tone}>{tier.label}</Badge>
      </div>

      <div className="mt-2 flex flex-wrap items-center gap-1.5">
        {connected ? (
          <Badge tone="positive">
            <CheckCircle2 className="h-3 w-3" aria-hidden />
            Connected
          </Badge>
        ) : (
          <>
            <Badge tone="warning">
              <FlaskConical className="h-3 w-3" aria-hidden />
              Demo mode
            </Badge>
            <Badge tone="neutral" title="No credentials configured for this platform.">
              <CircleSlash className="h-3 w-3" aria-hidden />
              Not connected
            </Badge>
          </>
        )}
        {source.post_count > 0 && (
          <Badge tone="neutral">{compactNumber(source.post_count)} posts loaded</Badge>
        )}
      </div>

      {source.capabilities.length > 0 && (
        <p className="mt-2 text-[10px] leading-relaxed text-ink-faint">
          Normalises: {source.capabilities.join(', ')}
        </p>
      )}

      {source.credential_fields.length > 0 && (
        <div className="mt-2 space-y-1">
          <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-faint">
            Credentials (optional — not required for the demo)
          </p>
          {source.credential_fields.map((field) => {
            const missing = source.missing_credentials.includes(field);
            return (
              <div key={field} className="flex items-center gap-2">
                <label className="w-40 shrink-0 truncate font-mono text-[10px] text-ink-faint" htmlFor={field}>
                  {field.toUpperCase()}
                </label>
                <input
                  id={field}
                  type="password"
                  readOnly
                  value={missing ? '' : '••••••••••••'}
                  placeholder="set in .env to enable live ingestion"
                  className="min-w-0 flex-1 rounded border border-edge bg-canvas-sunken px-1.5 py-1 text-[10px] text-ink-muted placeholder:text-ink-faint"
                />
              </div>
            );
          })}
          <p className="text-[10px] leading-relaxed text-ink-faint">
            Credentials are read from the backend environment only — this form is a
            read-only status view and never transmits secrets.
          </p>
        </div>
      )}

      {source.docs_url && (
        <a
          href={source.docs_url}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-2 inline-block text-[10px] text-ink-faint underline decoration-dotted hover:text-ink-muted"
        >
          Platform API documentation
        </a>
      )}
    </div>
  );
}

function LiveAnalyzer() {
  const [text, setText] = useState('Great, another three-hour outage. Amazing service.');
  const [result, setResult] = useState<AnalyzeResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function run() {
    setBusy(true);
    setError(null);
    try {
      setResult(await api.analyze(text));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Analysis failed.');
      setResult(null);
    } finally {
      setBusy(false);
    }
  }

  const flipped =
    result && result.literal_sentiment !== result.contextual_sentiment;

  return (
    <Panel
      title={
        <span className="flex items-center gap-1.5">
          <Cpu className="h-3.5 w-3.5 text-trend" aria-hidden />
          Live NLP probe
        </span>
      }
      subtitle="Run the same engine that produced every stored result over arbitrary text"
    >
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={3}
        aria-label="Text to analyse"
        className="w-full rounded border border-edge bg-canvas-sunken px-2.5 py-2 text-2xs text-ink placeholder:text-ink-faint"
        placeholder="Paste a post to analyse…"
      />

      <div className="mt-2 flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={run}
          disabled={busy || !text.trim()}
          className="inline-flex items-center gap-1.5 rounded bg-trend px-2.5 py-1 text-2xs font-medium text-canvas disabled:opacity-50"
        >
          {busy ? (
            <Loader2 className="h-3 w-3 animate-spin" aria-hidden />
          ) : (
            <Play className="h-3 w-3" aria-hidden />
          )}
          Analyse
        </button>
        {[
          'Great, another three-hour outage. Amazing service.',
          'Low light shots on this camera are genuinely excellent.',
          'Yaar update ke baad battery bilkul khatam ho jaati hai.',
        ].map((sample) => (
          <button
            key={sample}
            type="button"
            onClick={() => setText(sample)}
            className="text-[10px] text-ink-faint underline decoration-dotted hover:text-ink-muted"
          >
            {sample.slice(0, 26)}…
          </button>
        ))}
      </div>

      {error && <p className="mt-2 text-2xs text-negative">{error}</p>}

      {result && (
        <div className="mt-3 rounded border border-edge-subtle bg-canvas-sunken p-3">
          <div className="flex flex-wrap items-center gap-1.5">
            <SentimentBadge sentiment={result.sentiment} value={polarity(result.polarity)} />
            <ConfidenceBadge band={result.confidence_band} value={result.sentiment_confidence} />
            <Badge tone="neutral">Emotion: {titleCase(result.emotion)}</Badge>
            <Badge tone="neutral">Stance: {titleCase(result.stance)}</Badge>
            {result.sarcasm_detected && (
              <Badge tone="warning">
                Sarcasm likely · {result.sarcasm_confidence.toFixed(2)}
              </Badge>
            )}
          </div>

          {flipped && (
            <div className="mt-2.5 rounded border border-warning/30 bg-warning/[0.06] p-2.5">
              <p className="text-2xs font-semibold text-warning">
                Literal and contextual readings disagree
              </p>
              <dl className="mt-1.5 space-y-0.5 text-2xs">
                <div className="flex gap-2">
                  <dt className="w-32 shrink-0 text-ink-faint">Literal sentiment</dt>
                  <dd className="capitalize text-ink-muted">{result.literal_sentiment}</dd>
                </div>
                <div className="flex gap-2">
                  <dt className="w-32 shrink-0 text-ink-faint">Contextual sentiment</dt>
                  <dd className="capitalize text-ink-muted">{result.contextual_sentiment}</dd>
                </div>
                <div className="flex gap-2">
                  <dt className="w-32 shrink-0 text-ink-faint">Sarcasm</dt>
                  <dd className="text-ink-muted">
                    Likely ({result.sarcasm_confidence.toFixed(2)})
                  </dd>
                </div>
                <div className="flex gap-2">
                  <dt className="w-32 shrink-0 text-ink-faint">Final interpretation</dt>
                  <dd className="font-medium capitalize text-ink">
                    {result.sentiment} / {result.emotion}
                  </dd>
                </div>
              </dl>
            </div>
          )}

          {result.cues.sarcasm_signals && result.cues.sarcasm_signals.length > 0 && (
            <div className="mt-2.5">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-faint">
                Sarcasm signals
              </p>
              <ul className="mt-1 space-y-0.5">
                {result.cues.sarcasm_signals.map((signal) => (
                  <li key={signal} className="flex gap-1.5 text-2xs text-ink-muted">
                    <span aria-hidden className="text-ink-faint">·</span>
                    {signal}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {result.cues.weighted_terms && result.cues.weighted_terms.length > 0 && (
            <div className="mt-2.5">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-faint">
                Weighted terms
              </p>
              <div className="mt-1 flex flex-wrap gap-1">
                {result.cues.weighted_terms.map((term, i) => (
                  <Badge
                    key={`${term.term}-${i}`}
                    tone={term.weight > 0 ? 'positive' : 'negative'}
                  >
                    {term.term}
                    <span className="font-mono opacity-70">
                      {term.weight > 0 ? '+' : ''}
                      {term.weight.toFixed(1)}
                    </span>
                    {term.negated && <span className="opacity-70">neg</span>}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <p className="mt-2.5 border-t border-edge-subtle pt-2 font-mono text-[10px] text-ink-faint">
            {result.model} v{result.model_version} · status {result.status}
          </p>
        </div>
      )}
    </Panel>
  );
}

export function DataView() {
  const sources = useApi<SourcesResponse>('sources', () => api.sources());
  const [busy, setBusy] = useState<'load' | 'reset' | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [failure, setFailure] = useState<string | null>(null);

  async function run(kind: 'load' | 'reset') {
    setBusy(kind);
    setMessage(null);
    setFailure(null);
    try {
      const result = kind === 'load' ? await api.loadDemo() : await api.resetDemo();
      clearApiCache();
      setMessage(result.message);
      sources.reload();
    } catch (err) {
      setFailure(
        err instanceof ApiError ? `${err.message} ${err.hint}`.trim() : 'The pipeline failed.',
      );
    } finally {
      setBusy(null);
    }
  }

  const run_ = sources.data?.last_run;
  const validation = Object.entries(run_?.validation ?? {}).filter(
    ([, value]) => typeof value === 'object',
  ) as [string, { passed: boolean; detail: string }][];

  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-lg font-semibold tracking-tight text-ink">Data sources</h1>
        <p className="mt-0.5 text-2xs text-ink-muted">
          Multi-platform ingestion architecture. Every adapter normalises into one internal
          schema; adding real credentials swaps the source without changing anything downstream.
        </p>
      </div>

      <Panel
        title="Demo dataset"
        subtitle="Deterministic synthetic corpus — no API keys, no external services, no paid dependencies"
        actions={
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => run('load')}
              disabled={busy !== null}
              className="inline-flex items-center gap-1.5 rounded bg-trend px-2.5 py-1 text-2xs font-medium text-canvas disabled:opacity-50"
            >
              {busy === 'load' ? (
                <Loader2 className="h-3 w-3 animate-spin" aria-hidden />
              ) : (
                <Play className="h-3 w-3" aria-hidden />
              )}
              Load Demo Intelligence
            </button>
            <button
              type="button"
              onClick={() => run('reset')}
              disabled={busy !== null}
              className="inline-flex items-center gap-1.5 rounded border border-edge-strong px-2.5 py-1 text-2xs text-ink-muted hover:bg-canvas-hover hover:text-ink disabled:opacity-50"
            >
              {busy === 'reset' ? (
                <Loader2 className="h-3 w-3 animate-spin" aria-hidden />
              ) : (
                <RotateCcw className="h-3 w-3" aria-hidden />
              )}
              Reset Demo
            </button>
          </div>
        }
      >
        {busy && (
          <p className="text-2xs text-ink-muted">
            Running the pipeline: ingest → normalise → store → sentiment → topics →
            interactions → network → demographics → segments → trends → intelligence.
          </p>
        )}
        {message && (
          <p className="rounded border border-positive/25 bg-positive/[0.06] px-2.5 py-2 text-2xs text-ink-muted">
            {message}
          </p>
        )}
        {failure && (
          <p className="rounded border border-negative/25 bg-negative/[0.06] px-2.5 py-2 text-2xs text-negative">
            {failure}
          </p>
        )}
        {!busy && !message && !failure && (
          <p className="text-2xs leading-relaxed text-ink-muted">
            Loading regenerates the corpus from a fixed seed and recomputes every analytic.
            Resetting clears all data first, so both produce identical results.
          </p>
        )}
      </Panel>

      {sources.error && (
        <Panel>
          <ErrorState error={sources.error} onRetry={sources.reload} />
        </Panel>
      )}

      {sources.loading && (
        <Panel>
          <PanelSkeleton rows={5} height="h-16" />
        </Panel>
      )}

      {sources.data && (
        <Panel
          title="Ingestion adapters"
          subtitle="Status reflects whether credentials are actually configured — a platform is never reported as connected when it is not"
        >
          <div className="grid gap-2 md:grid-cols-2 xl:grid-cols-3">
            {sources.data.sources.map((source) => (
              <SourceCard key={source.id} source={source} />
            ))}
          </div>
        </Panel>
      )}

      <div className="grid gap-3 lg:grid-cols-2">
        {run_ && (
          <Panel
            title="Last pipeline run"
            subtitle={`Run #${run_.id} · ${run_.trigger} · seed ${run_.seed} · model ${run_.sentiment_model}`}
            actions={
              <Badge tone={run_.status === 'completed' ? 'positive' : 'warning'}>
                {titleCase(run_.status)}
              </Badge>
            }
          >
            <dl className="grid grid-cols-2 gap-x-4 gap-y-1.5 sm:grid-cols-4">
              <div>
                <dt className="text-[10px] text-ink-faint">Posts</dt>
                <dd className="font-mono text-sm tabular-nums text-ink">
                  {compactNumber(run_.posts_ingested)}
                </dd>
              </div>
              <div>
                <dt className="text-[10px] text-ink-faint">Accounts</dt>
                <dd className="font-mono text-sm tabular-nums text-ink">
                  {compactNumber(run_.authors_ingested)}
                </dd>
              </div>
              <div>
                <dt className="text-[10px] text-ink-faint">Started</dt>
                <dd className="text-2xs text-ink-muted">{dateTime(run_.started_at)}</dd>
              </div>
              <div>
                <dt className="text-[10px] text-ink-faint">Stages</dt>
                <dd className="font-mono text-sm tabular-nums text-ink">
                  {run_.stage_log.length}
                </dd>
              </div>
            </dl>

            <div className="mt-3">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-faint">
                Pipeline stages
              </p>
              <div className="mt-1.5 space-y-0.5">
                {run_.stage_log.map((stage, index) => {
                  const previous = index > 0 ? run_.stage_log[index - 1].elapsed_ms : 0;
                  return (
                    <div
                      key={`${stage.stage}-${index}`}
                      className="flex items-baseline justify-between gap-2 text-2xs"
                    >
                      <span className="text-ink-muted">
                        {index + 1}. {titleCase(stage.stage)}
                      </span>
                      <span className="font-mono tabular-nums text-ink-faint">
                        +{Math.max(0, stage.elapsed_ms - previous).toFixed(0)} ms
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </Panel>
        )}

        {validation.length > 0 && (
          <Panel
            title="Seed data validation"
            subtitle="Automatic checks run after every load; each is a real query against what was stored"
            actions={
              <Badge tone={validation.every(([, v]) => v.passed) ? 'positive' : 'warning'}>
                {validation.filter(([, v]) => v.passed).length}/{validation.length} passed
              </Badge>
            }
          >
            <div className="space-y-1">
              {validation.map(([name, check]) => (
                <div key={name} className="flex items-start gap-2">
                  {check.passed ? (
                    <CheckCircle2 className="mt-0.5 h-3 w-3 shrink-0 text-positive" aria-hidden />
                  ) : (
                    <XCircle className="mt-0.5 h-3 w-3 shrink-0 text-negative" aria-hidden />
                  )}
                  <span className="min-w-0 flex-1 text-2xs text-ink-muted">
                    {titleCase(name)}
                  </span>
                  <span
                    className={cx(
                      'shrink-0 font-mono text-[10px]',
                      check.passed ? 'text-ink-faint' : 'text-negative',
                    )}
                  >
                    {check.detail}
                  </span>
                </div>
              ))}
            </div>
          </Panel>
        )}
      </div>

      <LiveAnalyzer />

      {!sources.loading && !sources.data && !sources.error && (
        <Panel>
          <EmptyState title="No sources configured" />
        </Panel>
      )}
    </div>
  );
}
