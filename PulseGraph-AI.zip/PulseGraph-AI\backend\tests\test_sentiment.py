"""NLP engine behaviour, including the sarcasm reasoning path."""

from __future__ import annotations

import pytest

from app.ai.local_provider import LocalNLPProvider
from app.ai.provider import TextAnalysis

provider = LocalNLPProvider()


class TestPolarity:
    @pytest.mark.parametrize("text", [
        "Battery on the NovaPhone X is draining way faster after v14.2.",
        "Support asked me to factory reset without even looking at the logs. Not acceptable.",
        "Third day waiting on Nova support. Terrible experience.",
    ])
    def test_clear_complaints_read_negative(self, text):
        result = provider.analyze_text(text)
        assert result.sentiment == "negative"
        assert result.polarity < 0

    @pytest.mark.parametrize("text", [
        "Low light shots on the NovaPhone X are genuinely excellent.",
        "Build quality is superb and the display is stunning.",
        "Support engineer was actually helpful and collected the logs remotely. Good handling.",
    ])
    def test_clear_praise_reads_positive(self, text):
        result = provider.analyze_text(text)
        assert result.sentiment == "positive"
        assert result.polarity > 0

    def test_factual_statement_reads_neutral(self):
        result = provider.analyze_text(
            "Rollout appears staged. Some regions got the build two days before others."
        )
        assert result.sentiment == "neutral"

    def test_negation_flips_polarity(self):
        positive = provider.analyze_text("The battery life is good.")
        negated = provider.analyze_text("The battery life is not good.")
        assert positive.polarity > 0
        assert negated.polarity < positive.polarity

    def test_intensifier_increases_magnitude(self):
        plain = provider.analyze_text("This is disappointing.")
        intense = provider.analyze_text("This is extremely disappointing.")
        assert abs(intense.polarity) > abs(plain.polarity)

    def test_empty_text_is_flagged_not_guessed(self):
        result = provider.analyze_text("   ")
        assert result.status == "empty"
        assert result.sentiment == "neutral"


class TestSarcasm:
    def test_canonical_case_separates_literal_from_contextual(self):
        """The spec's worked example: surface praise, negative meaning."""
        result = provider.analyze_text(
            "Great, another three-hour outage. Amazing service."
        )
        assert result.literal_sentiment == "positive"
        assert result.sarcasm_detected is True
        assert result.contextual_sentiment == "negative"
        assert result.sentiment == "negative"
        assert result.emotion == "sarcastic"
        assert result.polarity < 0
        assert result.sarcasm_confidence > 0.5
        assert result.cues["sarcasm_signals"]

    @pytest.mark.parametrize("text", [
        "Love how my premium phone now needs charging twice a day. Fantastic upgrade.",
        "Wonderful. The battery lasts 3 hours now. Best update ever, no notes.",
        "Thanks for the amazing new feature where my battery dies before dinner.",
        "Nothing says confidence like a price cut 10 days after launch. Very reassuring.",
    ])
    def test_ironic_praise_is_inverted(self, text):
        result = provider.analyze_text(text)
        assert result.sarcasm_detected is True
        assert result.sentiment == "negative"

    @pytest.mark.parametrize("text", [
        "Low light shots on the NovaPhone X are genuinely excellent.",
        "The new gesture navigation is much smoother than before.",
        "Picked one up at the reduced price. At this number the hardware is hard to beat.",
    ])
    def test_sincere_praise_is_not_flagged(self, text):
        result = provider.analyze_text(text)
        assert result.sarcasm_detected is False
        assert result.sentiment == "positive"

    def test_plain_negative_text_is_not_called_sarcastic(self):
        result = provider.analyze_text(
            "This is terrible and I am extremely disappointed with the battery."
        )
        assert result.sarcasm_detected is False
        assert result.sentiment == "negative"

    def test_sarcastic_result_carries_lower_confidence_than_plain(self):
        sarcastic = provider.analyze_text("Great, another outage. Amazing service.")
        plain = provider.analyze_text("This service is terrible and disappointing.")
        assert sarcastic.sentiment_confidence < plain.sentiment_confidence


class TestEmotionAndStance:
    @pytest.mark.parametrize("text,emotion", [
        ("Now I am worried about charging it next to my bed. Is it dangerous?", "anxious"),
        ("Third day waiting, no response, going in circles.", "frustrated"),
        ("Has anyone found a workaround? Wondering if a reset helps.", "curious"),
        ("Getting conflicting information, not sure which setting causes this.", "confused"),
        ("It is here!! Been waiting for this since the announcement.", "excited"),
    ])
    def test_emotion_classification(self, text, emotion):
        assert provider.analyze_text(text).emotion == emotion

    def test_stance_against_detected_from_switching_language(self):
        result = provider.analyze_text(
            "Switching to the Orbit 12. The battery situation was the last straw for me."
        )
        assert result.stance == "against"

    def test_stance_supportive_detected_from_defence_language(self):
        result = provider.analyze_text(
            "Mine is completely fine on v14.2. This is being blown out of proportion."
        )
        assert result.stance == "supportive"


class TestHinglish:
    def test_code_switched_complaint_reads_negative(self):
        result = provider.analyze_text(
            "Yaar update ke baad battery bilkul khatam ho jaati hai. Poora din nahi chalta.",
            language="hi-en",
        )
        assert result.sentiment == "negative"
        assert result.polarity < 0

    def test_hinglish_detected_without_explicit_language_tag(self):
        result = provider.analyze_text(
            "Bhai battery drain ka issue serious hai, phone garam bhi ho raha hai."
        )
        assert result.sentiment == "negative"


class TestExplainability:
    def test_every_result_carries_provenance_and_cues(self):
        result = provider.analyze_text("The battery drain is really frustrating.")
        assert result.model == "pulsegraph-rule-nlp"
        assert result.model_version
        assert result.status == "ok"
        assert result.cues["matched_terms"]
        assert result.cues["weighted_terms"]
        assert result.cues["token_count"] > 0

    def test_confidence_is_bounded_and_never_certain(self):
        for text in ["terrible awful horrible disaster useless worst broken failure",
                     "excellent superb outstanding brilliant perfect amazing"]:
            result = provider.analyze_text(text)
            assert 0.0 < result.sentiment_confidence <= 0.97

    def test_deterministic_across_calls(self):
        text = "Battery drain after the update is unacceptable."
        a = provider.analyze_text(text)
        b = provider.analyze_text(text)
        assert (a.sentiment, a.polarity, a.emotion) == (b.sentiment, b.polarity, b.emotion)

    def test_returns_typed_result(self):
        assert isinstance(provider.analyze_text("hello"), TextAnalysis)


class TestNarration:
    def test_interpret_uses_only_supplied_values(self):
        narrative = provider.interpret({
            "headline": "Negative sentiment rose 31%.",
            "drivers": ["volume growth +184%"],
            "platforms": ["telegram", "x"],
            "segments": ["Concerned Customers"],
            "lead_time_minutes": 47,
            "lead_platform": "telegram",
            "lag_platform": "x",
            "recommended_action": "Investigate within 2-4 hours.",
        })
        assert "31%" in narrative.summary
        assert "47 minutes" in narrative.summary
        assert "telegram" in narrative.summary.lower()
        assert narrative.recommended_action == "Investigate within 2-4 hours."
        # No figure absent from the brief may appear.
        assert "62%" not in narrative.summary

    def test_interpret_handles_sparse_brief(self):
        narrative = provider.interpret({"headline": "Something changed."})
        assert narrative.summary == "Something changed."
