# PulseGraph AI - one-command start (Windows / PowerShell)
#
#   .\start.ps1            first run: sets up, loads demo data, starts both services
#   .\start.ps1 -SkipSetup skip dependency install
#   .\start.ps1 -Verify    run the full test + build validation instead of serving
#
# Leaves the backend on :8000 and the frontend on :3000.

param(
    [switch]$SkipSetup,
    [switch]$Verify
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$backend = Join-Path $root 'backend'
$frontend = Join-Path $root 'frontend'
$venvPython = Join-Path $backend '.venv\Scripts\python.exe'

function Write-Step($message) {
    Write-Host ""
    Write-Host "==> $message" -ForegroundColor Cyan
}

function Resolve-Python {
    foreach ($candidate in @('python', 'python3', 'py')) {
        $cmd = Get-Command $candidate -ErrorAction SilentlyContinue
        if ($cmd) {
            # The Microsoft Store stub reports a version but cannot run code.
            & $cmd.Source -c "import sys" 2>$null
            if ($LASTEXITCODE -eq 0) { return $cmd.Source }
        }
    }
    throw "Python 3.11+ not found. Install it from https://python.org and re-run."
}

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    throw "Node.js 18+ not found. Install it from https://nodejs.org and re-run."
}

# --- backend setup ---------------------------------------------------------
if (-not $SkipSetup) {
    Write-Step "Setting up the backend"
    if (-not (Test-Path $venvPython)) {
        $python = Resolve-Python
        Write-Host "Creating virtual environment with $python"
        & $python -m venv (Join-Path $backend '.venv')
    }
    & $venvPython -m pip install --upgrade pip --quiet
    & $venvPython -m pip install -r (Join-Path $backend 'requirements.txt') --quiet
    Write-Host "Backend dependencies ready." -ForegroundColor Green

    Write-Step "Setting up the frontend"
    Push-Location $frontend
    if (-not (Test-Path 'node_modules')) { npm install --no-fund --no-audit }
    if (-not (Test-Path '.env.local')) { Copy-Item '.env.local.example' '.env.local' }
    Pop-Location
    Write-Host "Frontend dependencies ready." -ForegroundColor Green
}

# --- verification mode -----------------------------------------------------
if ($Verify) {
    Write-Step "Backend tests"
    Push-Location $backend
    & $venvPython -m pytest -q
    if ($LASTEXITCODE -ne 0) { Pop-Location; throw "Backend tests failed." }
    Pop-Location

    Write-Step "Frontend typecheck, lint, tests and build"
    Push-Location $frontend
    npm run typecheck; if ($LASTEXITCODE -ne 0) { Pop-Location; throw "Typecheck failed." }
    npm run lint;      if ($LASTEXITCODE -ne 0) { Pop-Location; throw "Lint failed." }
    npm run test;      if ($LASTEXITCODE -ne 0) { Pop-Location; throw "Frontend tests failed." }
    npm run build;     if ($LASTEXITCODE -ne 0) { Pop-Location; throw "Build failed." }
    Pop-Location

    Write-Host ""
    Write-Host "All checks passed." -ForegroundColor Green
    exit 0
}

# --- seed the database -----------------------------------------------------
Write-Step "Loading the demo dataset"
Push-Location $backend
& $venvPython -c @"
from app.db import init_db, session_scope
from app.analytics.pipeline import Pipeline
init_db()
with session_scope() as db:
    run = Pipeline(db).run(['demo'], trigger='startup')
    checks = [v for v in run.validation.values() if isinstance(v, dict)]
    passed = sum(1 for v in checks if v['passed'])
    print(f'{run.posts_ingested} posts from {run.authors_ingested} accounts')
    print(f'seed validation: {passed}/{len(checks)} checks passed')
"@
Pop-Location

# --- serve -----------------------------------------------------------------
Write-Step "Starting services"
$backendJob = Start-Process -PassThru -WindowStyle Minimized `
    -FilePath $venvPython `
    -ArgumentList '-m', 'uvicorn', 'app.main:app', '--port', '8000' `
    -WorkingDirectory $backend

$frontendJob = Start-Process -PassThru -WindowStyle Minimized `
    -FilePath 'cmd.exe' -ArgumentList '/c', 'npm', 'run', 'dev' `
    -WorkingDirectory $frontend

Write-Host ""
Write-Host "  Dashboard : http://localhost:3000/dashboard" -ForegroundColor Green
Write-Host "  API docs  : http://127.0.0.1:8000/docs"      -ForegroundColor Green
Write-Host ""
Write-Host "Press Ctrl+C to stop both services."

try {
    Wait-Process -Id $backendJob.Id
} finally {
    foreach ($proc in @($backendJob, $frontendJob)) {
        Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
    }
}
