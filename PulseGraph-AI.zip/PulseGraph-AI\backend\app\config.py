"""Application configuration.

Every setting has a working default so that the platform boots with no .env
file at all. Credentials are optional by design: absent credentials simply mean
the corresponding ingestion adapter reports NOT_CONNECTED and the platform
falls back to the deterministic demo dataset.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = BACKEND_DIR.parent
DATA_DIR = PROJECT_ROOT / "data"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(PROJECT_ROOT / ".env", BACKEND_DIR / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # Core
    app_env: str = "development"
    log_level: str = "INFO"
    database_url: str = f"sqlite:///{(DATA_DIR / 'pulsegraph.db').as_posix()}"
    cors_origins: str = "http://localhost:3000,http://127.0.0.1:3000"

    # AI
    ai_provider: str = "local"
    ai_api_key: str = ""
    ai_model: str = "gpt-4o-mini"

    # Demo dataset
    demo_seed: int = 20260825
    demo_post_target: int = 1600

    # Platform credentials (all optional)
    x_api_key: str = ""
    x_api_secret: str = ""
    x_bearer_token: str = ""
    telegram_api_id: str = ""
    telegram_api_hash: str = ""
    telegram_bot_token: str = ""
    instagram_access_token: str = ""
    facebook_access_token: str = ""
    reddit_client_id: str = ""
    reddit_client_secret: str = ""
    reddit_user_agent: str = "pulsegraph-ai/1.0"
    youtube_api_key: str = ""

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def demo_mode(self) -> bool:
        """True when no live platform credentials are configured."""
        return not any(
            [
                self.x_bearer_token,
                self.telegram_api_hash,
                self.instagram_access_token,
                self.facebook_access_token,
                self.reddit_client_id,
                self.youtube_api_key,
            ]
        )


@lru_cache
def get_settings() -> Settings:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    return Settings()


settings = get_settings()
