import { Suspense } from 'react';

import { AppShell } from '@/components/layout/AppShell';
import { FilterProvider } from '@/features/filters/FilterContext';

import { DashboardView } from './DashboardView';

export const metadata = { title: 'Dashboard — PulseGraph AI' };

export default function DashboardPage() {
  return (
    <Suspense fallback={null}>
      <FilterProvider>
        <AppShell>
          <DashboardView />
        </AppShell>
      </FilterProvider>
    </Suspense>
  );
}
