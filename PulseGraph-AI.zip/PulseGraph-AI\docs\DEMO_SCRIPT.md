# Demo script (3–5 minutes)

Everything below is produced by the analytics engine from the demo corpus. No
part of the narrative is hard-coded — reloading with the same seed reproduces
it exactly, and the numbers shift correctly whenever a filter is applied.

**Before you start:** backend on `:8000`, frontend on `:3000`, demo data loaded
(the `/data` page will tell you, and load it in one click if not).

---

## 0:00 — Frame the problem (20s)

> "Most social dashboards tell you a number went up. They don't tell you who
> drove it, where it started, or which part of your audience actually moved.
> PulseGraph correlates sentiment, topics, demographics and network influence,
> and then explains the change with the evidence attached."

Open `http://localhost:3000` → **Open Intelligence Dashboard**.

---

## 0:20 — Audience Pulse (45s)

Point at the top panel.

> "This is the Audience Pulse. One statement combining four analytical
> dimensions."

Read it aloud — for example:

> *NovaPhone X battery drain is viral: 545 mentions in the last 12 hours versus
> 11 in the 12 before. Telegram activity preceded the increase elsewhere by
> about 54 minutes.*

> "Note what it answers: **what** changed, **when**, **where**, **who**
> contributed, and **how** it spread."

Click **Why?**.

> "And this is why it matters — every figure in that sentence is a computed
> metric with its value, change and period. The system shows its arithmetic
> instead of saying 'AI detected this'."

Point at the confidence badge.

> "High confidence, 0.88. Nothing here is presented as certain."

---

## 1:05 — KPIs and the timeline (30s)

> "Every KPI carries its change against the previous window of equal length —
> a number without a baseline isn't information."

Point at Negative: 60.1%, ↑43.7.

Scroll to the sentiment timeline.

> "Volume by sentiment, with average polarity overlaid. Clicking any interval
> filters the entire dashboard to that window."

---

## 1:35 — Trend Radar (35s)

> "Eight topics, scored 0–100. This one is Viral, this one is Stable, and this
> one is actually declining — the engine distinguishes them."

Click **How was this scored?** on the top row.

> "Seven weighted components, and the formula. Including an evidence discount:
> percentage growth off a tiny base is cheap, so a topic going 5 to 70 can't
> outrank one going 11 to 545."

Point at the momentum badge.

> "Momentum forecast — labelled a forecast, with a confidence band. Not a
> guaranteed prediction."

---

## 2:10 — Narrative Journey (60s) ★ the centrepiece

Click the top topic → `/topics/battery-drain`.

Scroll to **Narrative Journey**.

> "This reconstructs how the topic actually evolved. Read it top to bottom:"

- **Episode opens on Telegram** — a niche channel, technical reports
- **Technical Reviewers enter** — corroboration from high-reach accounts
- **Discussion reaches X, +51 minutes** — the cross-platform jump, quantified
- **Sentiment turns measurably more negative** — polarity −0.20 → −0.45
- **Reaches Reddit, then Facebook, then YouTube**
- **Volume breaks out of its own baseline**
- **Peak activity**

> "None of that is scripted. The engine located the episode by finding where
> volume breaks away from the topic's own baseline, then measured when each
> platform joined. And notice the language — 'preceded', 'observed ordering
> only, not evidence of causation'. Time ordering is all the data supports."

---

## 3:10 — Cross-platform divergence (30s)

Scroll to the platform panel.

> "The same narrative reads differently per community. Telegram sits here,
> Reddit sits here — that spread is the point. A response written for one
> community will not land on the other."

---

## 3:40 — Network (35s)

Open `/network`.

> "The real interaction graph. Node size is influence — PageRank, betweenness
> and degree centrality combined. Colour is audience segment. The ringed nodes
> are bridges."

Click a bridge node.

> "A bridge isn't just a popular account. It's one where a large share of
> interactions cross community boundaries *and* betweenness is top-decile.
> These accounts decide whether a narrative stays in one community."

Point at the influence table.

> "And every account is pseudonymous throughout — A6892, not a real handle."

---

## 4:15 — Audience (25s)

Open `/audience`.

> "Six behavioural segments, derived from reach, activity, negativity,
> amplification and technical register — not a demographic pie chart."

Point at the comparison panel.

> "And you can put two audiences side by side to see which one actually moved."

Scroll to demographics.

> "Every inferred attribute carries a confidence band and the public signal
> behind it. Where there's no signal, it says 'not inferable' rather than
> guessing."

---

## 4:40 — Sarcasm (30s) ★ the NLP proof point

Open `/data` → **Live NLP probe**.

Paste: `Great, another three-hour outage. Amazing service.`

> "A keyword sentiment model scores this positive — 'great', 'amazing'."

Click **Analyse**.

> "Literal sentiment: positive. Contextual sentiment: negative. Sarcasm:
> likely. Final interpretation: negative. And here are the signals that flipped
> it — the praise opener, and positive wording wrapped around a failure."

Optionally paste the Hinglish sample.

> "It also handles code-switched Hinglish, which a generic English lexicon
> scores as exactly zero."

---

## 5:10 — Close (20s)

Apply a platform filter in the top bar.

> "And it's one system, not a collection of widgets. Filter to a single
> platform and everything re-derives — including the Pulse itself, which now
> reports 302 mentions instead of 545."

> "So: the system doesn't just tell us something is trending. It explains who
> is driving it, where it started, how it's spreading, which audience is
> reacting, and what changed."

---

## If asked

**"Is this real data?"**
No — deterministic synthetic data, and the DEMO MODE badge says so at all times.
All six platform adapters are implemented against the real API payload shapes
and unit-tested; supplying credentials switches a platform to live without
changing anything downstream.

**"Where is the AI?"**
Sentiment, emotion, stance and sarcasm classification. Deliberately *not* in the
arithmetic — trend scores and growth rates are deterministic statistics. The AI
provider phrases already-computed numbers; it never produces one.

**"How would this scale?"**
Aggregation is server-side, betweenness uses pivot sampling above 220 nodes, and
graph payloads are capped before rendering. The data layer is `DATABASE_URL`
away from PostgreSQL.

**"What about privacy?"**
Public data only, no private messages, aggregate demographics with confidence
bands, no sensitive-attribute inference, pseudonymous identifiers throughout.
The `/privacy` page states each commitment and where it is enforced.
