"""Narrative Journey: reconstruct how a topic actually evolved.

Every milestone is discovered from stored rows - first observed mention per
platform, the bucket where sentiment inflects, the first high-influence
participation, the point where volume breaks out of its own baseline, and the
moment each audience segment enters. Nothing is scripted.

Wording is deliberately observational ("preceded", "appears to originate from")
because ordering in time is all the data can support.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import (
    Author,
    AuthorSegment,
    AudienceSegment,
    NetworkMetric,
    Post,
    PostTopic,
    SentimentResult,
)

# A platform has joined the episode once it carries this many posts within it.
MIN_PLATFORM_ACTIVITY = 3

# Episode detection: resolution of the volume curve, the fraction of peak volume
# that still counts as "elevated", the floor below which a bucket is background,
# and how long a lull may last before the run is considered broken.
EPISODE_BUCKET = timedelta(minutes=30)
EPISODE_SHOULDER_RATIO = 0.08
MIN_EPISODE_BUCKET_VOLUME = 3
MAX_EPISODE_LULL_BUCKETS = 3


@dataclass(slots=True)
class Milestone:
    ts: datetime
    kind: str
    title: str
    detail: str
    platform: str | None = None
    evidence: list[dict] = field(default_factory=list)
    sample_post_id: str | None = None
    sample_text: str | None = None
    actors: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "ts": self.ts.isoformat(),
            "kind": self.kind,
            "title": self.title,
            "detail": self.detail,
            "platform": self.platform,
            "evidence": self.evidence,
            "sample_post_id": self.sample_post_id,
            "sample_text": self.sample_text,
            "actors": self.actors,
        }


def _bucket(ts: datetime, size: timedelta) -> datetime:
    seconds = int(size.total_seconds())
    epoch = int(ts.timestamp())
    return datetime.fromtimestamp(epoch - epoch % seconds)


def detect_episode_start(rows: list[tuple]) -> datetime:
    """Find where the current episode begins.

    A topic can carry weeks of low-level background chatter. Measuring "first
    activity" against that history makes whichever platform is chattiest at
    baseline look like the origin, which is wrong.

    Instead: locate the peak of the topic's own volume curve, then walk backwards
    to the start of the contiguous elevated run containing it, tolerating short
    lulls. The episode is that run.
    """
    if not rows:
        raise ValueError("cannot detect an episode in an empty row set")

    times = [r[3] for r in rows]
    counts: dict[datetime, int] = defaultdict(int)
    for ts in times:
        counts[_bucket(ts, EPISODE_BUCKET)] += 1

    series = sorted(counts.items())
    if len(series) < 3:
        return times[0]

    peak_index = max(range(len(series)), key=lambda i: series[i][1])
    peak_volume = series[peak_index][1]
    threshold = max(float(MIN_EPISODE_BUCKET_VOLUME), peak_volume * EPISODE_SHOULDER_RATIO)

    start_index = peak_index
    lull = 0
    for i in range(peak_index - 1, -1, -1):
        if series[i][1] >= threshold:
            start_index = i
            lull = 0
        else:
            lull += 1
            if lull > MAX_EPISODE_LULL_BUCKETS:
                break

    episode_bucket = series[start_index][0]
    candidates = [ts for ts in times if ts >= episode_bucket]
    return min(candidates) if candidates else times[0]


def platform_first_activity(
    rows: list[tuple], episode_start: datetime
) -> dict[str, tuple[datetime, str]]:
    """When each platform joins the episode.

    Scoped to the episode, so a simple count is meaningful: the onset is the
    MIN_PLATFORM_ACTIVITY-th post, which filters out a lone incidental mention.

    Returns platform -> (onset timestamp, id of the post that opened it).
    """
    by_platform: dict[str, list[tuple[datetime, str]]] = defaultdict(list)
    for post_id, _text, platform, created_at, *_rest in rows:
        if created_at >= episode_start:
            by_platform[platform].append((created_at, post_id))

    firsts: dict[str, tuple[datetime, str]] = {}
    for platform, entries in by_platform.items():
        entries.sort(key=lambda kv: kv[0])
        if len(entries) >= MIN_PLATFORM_ACTIVITY:
            firsts[platform] = entries[MIN_PLATFORM_ACTIVITY - 1]
        elif entries:
            firsts[platform] = entries[0]
    return firsts


def build_journey(db: Session, topic_id: str, max_milestones: int = 12) -> dict:
    rows = db.execute(
        select(
            Post.id, Post.text, Post.platform, Post.created_at, Post.author_id,
            Post.engagement_count, SentimentResult.polarity, SentimentResult.sentiment,
        )
        .join(PostTopic, (PostTopic.post_id == Post.id) & (PostTopic.is_primary.is_(True)))
        .join(SentimentResult, SentimentResult.post_id == Post.id, isouter=True)
        .where(PostTopic.topic_id == topic_id)
        .order_by(Post.created_at)
    ).all()

    if not rows:
        return {"topic_id": topic_id, "milestones": [], "lead_lag": [], "span": None}

    influence = dict(db.execute(
        select(NetworkMetric.author_id, NetworkMetric.influence_score)).all())
    anon = dict(db.execute(select(Author.id, Author.anon_id)).all())
    segment_of = dict(db.execute(
        select(AuthorSegment.author_id, AuthorSegment.segment_id)).all())
    segment_names = dict(db.execute(
        select(AudienceSegment.id, AudienceSegment.name)).all())

    milestones: list[Milestone] = []

    # --- 1. locate the episode --------------------------------------------
    episode_start = detect_episode_start(rows)
    firsts = platform_first_activity(rows, episode_start)
    ordered = sorted(firsts.items(), key=lambda kv: kv[1][0])

    if ordered:
        lead_platform, (_lead_ts, origin_post_id) = ordered[0]
    else:
        lead_platform, origin_post_id = rows[0][2], rows[0][0]

    # Milestones describe the episode, not the topic's entire history: a week of
    # background chatter would otherwise flatten every baseline comparison.
    episode = [r for r in rows if r[3] >= episode_start] or rows
    start, end = episode[0][3], episode[-1][3]
    span_hours = max((end - start).total_seconds() / 3600.0, 0.5)
    size = timedelta(minutes=30) if span_hours <= 36 else timedelta(hours=2)

    origin_row = next((r for r in rows if r[0] == origin_post_id), episode[0])
    prior_posts = sum(1 for r in rows if r[3] < episode_start)
    milestones.append(Milestone(
        ts=episode_start, kind="origin",
        title=f"Episode opens on {lead_platform}",
        detail=(
            f"Volume for this topic breaks away from its own baseline here, and "
            f"{lead_platform} is the first platform to carry it"
            + (f", against {prior_posts} scattered earlier mentions. " if prior_posts else ". ")
            + "Stated as first-observed, not as proven source."
        ),
        platform=lead_platform,
        sample_post_id=origin_row[0], sample_text=origin_row[1][:220],
        evidence=[
            {"metric": "episode_start", "value": episode_start.isoformat(),
             "period": "sustained-activity onset"},
            {"metric": "prior_background_mentions", "value": prior_posts,
             "period": "before onset"},
        ],
    ))

    # --- 2. cross-platform arrivals + lead/lag ----------------------------
    lead_lag: list[dict] = []
    lead_onset = ordered[0][1][0] if ordered else episode_start
    for platform, (ts, _pid) in ordered[1:]:
        minutes = (ts - lead_onset).total_seconds() / 60.0
        lead_lag.append({
            "lead_platform": lead_platform,
            "lag_platform": platform,
            "minutes": round(minutes, 1),
            "lead_first_activity": lead_onset.isoformat(),
            "lag_first_activity": ts.isoformat(),
        })
        milestones.append(Milestone(
            ts=ts, kind="cross_platform",
            title=f"Discussion reaches {platform}",
            detail=(
                f"{platform} shows sustained activity about {int(minutes)} minutes after "
                f"{lead_platform}. Temporal ordering only; no causal claim."
            ),
            platform=platform,
            evidence=[
                {"metric": "lead_time_minutes", "value": round(minutes, 1),
                 "period": f"{lead_platform} -> {platform}"},
                {"metric": "lead_platform", "value": lead_platform, "period": "episode"},
            ],
        ))

    # --- 3. sentiment inflection ------------------------------------------
    buckets: dict[datetime, list[float]] = defaultdict(list)
    for _pid, _text, _plat, created_at, _aid, _eng, polarity, _sent in episode:
        if polarity is not None:
            buckets[_bucket(created_at, size)].append(polarity)
    series = [(k, sum(v) / len(v), len(v)) for k, v in sorted(buckets.items()) if v]

    if len(series) >= 4:
        baseline_slice = series[: max(2, len(series) // 4)]
        baseline = sum(p for _k, p, _n in baseline_slice) / len(baseline_slice)
        for key, polarity, count in series[len(baseline_slice):]:
            if count >= 3 and polarity - baseline <= -0.18:
                milestones.append(Milestone(
                    ts=key, kind="sentiment_shift",
                    title="Sentiment turns measurably more negative",
                    detail=(
                        f"Average polarity moves from {baseline:+.2f} to {polarity:+.2f} "
                        f"across {count} posts in this interval."
                    ),
                    evidence=[
                        {"metric": "avg_polarity", "value": round(polarity, 3),
                         "change": round(polarity - baseline, 3), "period": "vs topic baseline"},
                        {"metric": "posts_in_bucket", "value": count, "period": str(size)},
                    ],
                ))
                break

    # --- 4. first high-influence participation ----------------------------
    if influence:
        ranked = sorted(influence.values(), reverse=True)
        cut = ranked[max(0, len(ranked) // 20 - 1)]
        for post_id, text, platform, created_at, author_id, engagement, _pol, _sent in episode:
            if influence.get(author_id, 0.0) >= cut and cut > 0:
                milestones.append(Milestone(
                    ts=created_at, kind="influencer",
                    title="High-influence account joins the conversation",
                    detail=(
                        f"Account {anon.get(author_id, 'A?')} sits in the top influence tier "
                        f"of the interaction graph (score "
                        f"{influence.get(author_id, 0):.1f}/100)."
                    ),
                    platform=platform,
                    sample_post_id=post_id, sample_text=text[:220],
                    actors=[{"anon_id": anon.get(author_id, "A?"),
                             "influence_score": round(influence.get(author_id, 0.0), 2)}],
                    evidence=[
                        {"metric": "influence_score",
                         "value": round(influence.get(author_id, 0.0), 2), "period": "graph"},
                        {"metric": "post_engagement", "value": engagement, "period": "post"},
                    ],
                ))
                break

    # --- 5. volume breakout ------------------------------------------------
    volume: dict[datetime, int] = defaultdict(int)
    for _pid, _text, _plat, created_at, *_rest in episode:
        volume[_bucket(created_at, size)] += 1
    volume_series = sorted(volume.items())
    if len(volume_series) >= 5:
        head = volume_series[: max(2, len(volume_series) // 4)]
        base = sum(v for _k, v in head) / len(head)
        threshold = max(base * 2.5, base + 3)
        for key, count in volume_series[len(head):]:
            if count >= threshold:
                milestones.append(Milestone(
                    ts=key, kind="acceleration",
                    title="Volume breaks out of its own baseline",
                    detail=(
                        f"{count} posts in a {int(size.total_seconds() // 60)}-minute interval "
                        f"against an early-window baseline of {base:.1f}."
                    ),
                    evidence=[
                        {"metric": "mentions_per_bucket", "value": count,
                         "change": f"+{count - base:.1f} vs baseline", "period": str(size)},
                    ],
                ))
                break

        peak_key, peak_count = max(volume_series, key=lambda kv: kv[1])
        milestones.append(Milestone(
            ts=peak_key, kind="peak",
            title="Peak activity",
            detail=f"Highest observed volume for this topic: {peak_count} posts in one interval.",
            evidence=[{"metric": "peak_mentions", "value": peak_count, "period": str(size)}],
        ))

    # --- 6. audience segment entry ----------------------------------------
    segment_first: dict[str, tuple[datetime, int]] = {}
    segment_counts: dict[str, int] = defaultdict(int)
    for _pid, _text, _plat, created_at, author_id, *_rest in episode:
        segment_id = segment_of.get(author_id)
        if not segment_id:
            continue
        segment_counts[segment_id] += 1
        if segment_counts[segment_id] == 5:
            segment_first[segment_id] = (created_at, segment_counts[segment_id])

    entries = sorted(segment_first.items(), key=lambda kv: kv[1][0])
    for segment_id, (ts, count) in entries[1:3]:
        milestones.append(Milestone(
            ts=ts, kind="segment_entry",
            title=f"{segment_names.get(segment_id, segment_id)} enter the conversation",
            detail=(
                f"This segment reaches {count} posts on the topic here, after the "
                f"conversation had already started elsewhere."
            ),
            evidence=[
                {"metric": "segment_posts", "value": count, "period": "cumulative"},
                {"metric": "segment", "value": segment_names.get(segment_id, segment_id),
                 "period": "topic"},
            ],
        ))

    milestones.sort(key=lambda m: m.ts)
    trimmed = milestones[:max_milestones]

    return {
        "topic_id": topic_id,
        "span": {"start": start.isoformat(), "end": end.isoformat(),
                 "hours": round(span_hours, 2)},
        "bucket_minutes": int(size.total_seconds() // 60),
        "total_posts": len(rows),
        "episode_posts": len(episode),
        "lead_platform": lead_platform,
        "milestones": [m.to_dict() for m in trimmed],
        "lead_lag": lead_lag,
    }
