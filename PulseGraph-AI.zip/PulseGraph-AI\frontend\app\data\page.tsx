import { Suspense } from 'react';

import { AppShell } from '@/components/layout/AppShell';
import { FilterProvider } from '@/features/filters/FilterContext';

import { DataView } from './DataView';

export const metadata = { title: 'Data sources — PulseGraph AI' };

export default function Page() {
  return (
    <Suspense fallback={null}>
      <FilterProvider>
        <AppShell>
          <DataView />
        </AppShell>
      </FilterProvider>
    </Suspense>
  );
}
