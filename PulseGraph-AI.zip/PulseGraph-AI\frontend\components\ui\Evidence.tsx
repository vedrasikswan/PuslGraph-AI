'use client';

/**
 * Explainability surface.
 *
 * Every AI-attributed conclusion in the product carries a "Why?" control that
 * expands into the metrics that triggered it. The panel deliberately renders
 * the raw metric name, value, change and period rather than a prose
 * restatement - the point is to show the arithmetic, not to reassure.
 */

import { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

import { evidenceValue, metricLabel } from '@/lib/format';
import type { ConfidenceBand, Evidence } from '@/types/api';

import { Badge, ConfidenceBadge, cx } from './primitives';

export function EvidenceTable({ evidence }: { evidence: Evidence[] }) {
  if (!evidence.length) {
    return (
      <p className="text-2xs text-ink-faint">
        No supporting metrics were recorded for this conclusion.
      </p>
    );
  }
  return (
    <table className="w-full border-collapse text-2xs">
      <thead>
        <tr className="border-b border-edge-subtle text-left text-ink-faint">
          <th className="py-1 pr-3 font-medium">Metric</th>
          <th className="py-1 pr-3 text-right font-medium">Value</th>
          <th className="py-1 pr-3 text-right font-medium">Change</th>
          <th className="py-1 font-medium">Period</th>
        </tr>
      </thead>
      <tbody>
        {evidence.map((item, index) => (
          <tr key={`${item.metric}-${index}`} className="border-b border-edge-subtle/60 last:border-0">
            <td className="py-1.5 pr-3 align-top text-ink-muted">
              {metricLabel(item.metric)}
              {item.note && (
                <span className="mt-0.5 block text-[10px] leading-snug text-ink-faint">
                  {item.note}
                </span>
              )}
            </td>
            <td className="py-1.5 pr-3 text-right align-top font-mono tabular-nums text-ink">
              {evidenceValue(item.value)}
            </td>
            <td
              className={cx(
                'py-1.5 pr-3 text-right align-top font-mono tabular-nums',
                item.change?.startsWith('+') ? 'text-negative' : item.change?.startsWith('-')
                  ? 'text-positive'
                  : 'text-ink-faint',
              )}
            >
              {item.change ?? '—'}
            </td>
            <td className="py-1.5 align-top text-ink-faint">{item.period ?? '—'}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

/**
 * Collapsible "Why?" control.
 *
 * `source` names what produced the interpretation, so a reader can tell a
 * deterministic computation from an LLM phrasing of it.
 */
export function WhyPanel({
  evidence,
  confidence,
  confidenceBand,
  drivers,
  source,
  method,
  defaultOpen = false,
  label = 'Why?',
}: {
  evidence: Evidence[];
  confidence?: number;
  confidenceBand?: ConfidenceBand;
  drivers?: string[];
  source?: string;
  method?: string;
  defaultOpen?: boolean;
  label?: string;
}) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="mt-2">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className={cx(
          'inline-flex items-center gap-1 rounded border px-1.5 py-0.5 text-2xs font-medium transition-colors',
          open
            ? 'border-influence/40 bg-influence/10 text-influence'
            : 'border-edge-strong text-ink-muted hover:bg-canvas-hover hover:text-ink',
        )}
      >
        <HelpCircle className="h-3 w-3" aria-hidden />
        {label}
        <ChevronDown
          className={cx('h-3 w-3 transition-transform', open && 'rotate-180')}
          aria-hidden
        />
      </button>

      {open && (
        <div className="mt-2 animate-fade-in rounded border border-edge-subtle bg-canvas-sunken p-3">
          <div className="mb-2 flex flex-wrap items-center gap-1.5">
            <span className="text-2xs font-semibold uppercase tracking-wider text-ink-faint">
              Evidence used
            </span>
            {confidence !== undefined && confidenceBand && (
              <ConfidenceBadge band={confidenceBand} value={confidence} />
            )}
            {source && (
              <Badge tone={source === 'local' ? 'neutral' : 'trend'}>
                {source === 'local' ? 'Computed + templated' : `Phrased by ${source}`}
              </Badge>
            )}
          </div>

          {drivers && drivers.length > 0 && (
            <ul className="mb-2.5 space-y-0.5">
              {drivers.map((driver) => (
                <li key={driver} className="flex gap-1.5 text-2xs text-ink-muted">
                  <span className="text-ink-faint" aria-hidden>
                    ·
                  </span>
                  <span>Likely driver: {driver}</span>
                </li>
              ))}
            </ul>
          )}

          <EvidenceTable evidence={evidence} />

          {method && (
            <p className="mt-2.5 border-t border-edge-subtle pt-2 font-mono text-[10px] leading-relaxed text-ink-faint">
              {method}
            </p>
          )}

          <p className="mt-2 text-[10px] leading-relaxed text-ink-faint">
            Metrics are computed deterministically from the filtered dataset. Ordering in
            time is reported as observed; it is not evidence of causation.
          </p>
        </div>
      )}
    </div>
  );
}
