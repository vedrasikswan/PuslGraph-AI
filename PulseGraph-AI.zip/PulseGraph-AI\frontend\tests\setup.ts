import '@testing-library/jest-dom/vitest';
import { cleanup } from '@testing-library/react';
import { afterEach, vi } from 'vitest';

// Recharts and Cytoscape both measure their container; jsdom reports zero.
class ResizeObserverStub {
  observe() {}
  unobserve() {}
  disconnect() {}
}
globalThis.ResizeObserver = ResizeObserverStub as unknown as typeof ResizeObserver;

Object.defineProperty(HTMLElement.prototype, 'offsetWidth', {
  configurable: true,
  value: 900,
});
Object.defineProperty(HTMLElement.prototype, 'offsetHeight', {
  configurable: true,
  value: 400,
});

vi.mock('cytoscape', () => ({
  default: () => ({
    on: vi.fn(),
    elements: () => ({
      removeClass: vi.fn().mockReturnThis(),
      unselect: vi.fn().mockReturnThis(),
      difference: () => ({ addClass: vi.fn() }),
      addClass: vi.fn(),
    }),
    nodes: () => ({ forEach: vi.fn() }),
    getElementById: () => ({ nonempty: () => false }),
    destroy: vi.fn(),
    zoom: vi.fn(),
    width: () => 900,
    height: () => 400,
    animate: vi.fn(),
  }),
}));

afterEach(() => cleanup());
