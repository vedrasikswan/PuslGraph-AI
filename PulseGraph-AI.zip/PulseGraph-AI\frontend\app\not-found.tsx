import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="grid min-h-screen place-items-center px-6">
      <div className="max-w-md text-center">
        <p className="font-mono text-2xs uppercase tracking-widest text-ink-faint">404</p>
        <h1 className="mt-2 text-lg font-semibold text-ink">This view does not exist</h1>
        <p className="mt-2 text-2xs leading-relaxed text-ink-muted">
          The topic, segment or account you followed is not part of the loaded dataset.
        </p>
        <Link
          href="/dashboard"
          className="mt-4 inline-block rounded border border-edge-strong px-3 py-1.5 text-2xs text-ink-muted hover:bg-canvas-hover hover:text-ink"
        >
          Back to the dashboard
        </Link>
      </div>
    </div>
  );
}
