'use client';

/**
 * Interactive influence graph (Cytoscape).
 *
 * Visual encoding, stated in the legend so it is never guesswork:
 *   node size  = influence score (PageRank-weighted composite)
 *   node fill  = audience segment
 *   ring       = bridge account (connects otherwise separate communities)
 *   edge       = observed interaction (reply / mention / repost)
 *
 * The backend aggregates the graph before sending it, so this never renders
 * thousands of nodes.
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import cytoscape, { type Core, type ElementDefinition } from 'cytoscape';
import { Crosshair, Maximize2, ZoomIn, ZoomOut } from 'lucide-react';

import { COLORS } from '@/lib/colors';
import { compactNumber, platformLabel, polarity } from '@/lib/format';
import { Badge, cx } from '@/components/ui/primitives';
import type { GraphNode, NetworkResponse } from '@/types/api';

interface Props {
  data: NetworkResponse;
  height?: number;
  selectedId?: string | null;
  onSelect?: (node: GraphNode | null) => void;
  highlightSegment?: string | null;
}

export function InfluenceGraph({
  data,
  height = 520,
  selectedId,
  onSelect,
  highlightSegment,
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const cyRef = useRef<Core | null>(null);
  const onSelectRef = useRef(onSelect);
  onSelectRef.current = onSelect;

  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!containerRef.current || !data.nodes.length) return;

    const maxInfluence = Math.max(...data.nodes.map((n) => n.influence_score), 1);
    const maxWeight = Math.max(...data.edges.map((e) => e.weight), 1);

    const elements: ElementDefinition[] = [
      ...data.nodes.map((node) => ({
        data: {
          id: node.id,
          label: node.anon_id,
          size: 12 + (node.influence_score / maxInfluence) * 34,
          color: node.segment_color || COLORS.neutral,
          bridge: node.is_bridge ? 1 : 0,
          raw: node,
        },
      })),
      ...data.edges.map((edge, index) => ({
        data: {
          id: `e${index}`,
          source: edge.source,
          target: edge.target,
          width: 0.5 + (edge.weight / maxWeight) * 2.2,
        },
      })),
    ];

    const cy = cytoscape({
      container: containerRef.current,
      elements,
      minZoom: 0.2,
      maxZoom: 3.5,
      style: [
        {
          selector: 'node',
          style: {
            width: 'data(size)',
            height: 'data(size)',
            'background-color': 'data(color)',
            'background-opacity': 0.85,
            label: 'data(label)',
            color: COLORS.muted,
            'font-size': '7px',
            'font-family': 'ui-monospace, monospace',
            'text-valign': 'bottom',
            'text-margin-y': 3,
            'text-opacity': 0,
            'border-width': 0,
            'transition-property': 'background-opacity, border-width, text-opacity',
            'transition-duration': 120,
          },
        },
        {
          selector: 'node[bridge = 1]',
          style: {
            'border-width': 2,
            'border-color': COLORS.warning,
            'border-opacity': 0.9,
          },
        },
        {
          selector: 'node[size > 30]',
          style: { 'text-opacity': 1 },
        },
        {
          selector: 'edge',
          style: {
            width: 'data(width)',
            'line-color': COLORS.grid,
            'curve-style': 'straight',
            opacity: 0.5,
            'target-arrow-shape': 'none',
          },
        },
        {
          selector: 'node:selected',
          style: {
            'border-width': 3,
            'border-color': COLORS.influence,
            'text-opacity': 1,
            'background-opacity': 1,
          },
        },
        {
          selector: '.faded',
          style: { opacity: 0.12, 'text-opacity': 0 },
        },
        {
          selector: '.neighbour',
          style: { 'background-opacity': 1, 'text-opacity': 1 },
        },
        {
          selector: 'edge.neighbour',
          style: { 'line-color': COLORS.influence, opacity: 0.85 },
        },
      ],
      layout: {
        name: 'cose',
        animate: false,
        nodeRepulsion: () => 9000,
        idealEdgeLength: () => 55,
        gravity: 0.6,
        numIter: 900,
        randomize: false,
        componentSpacing: 90,
      },
    });

    cy.on('tap', 'node', (event) => {
      const node = event.target;
      const raw = node.data('raw') as GraphNode;
      cy.elements().removeClass('faded neighbour');
      const neighbourhood = node.closedNeighborhood();
      cy.elements().difference(neighbourhood).addClass('faded');
      neighbourhood.addClass('neighbour');
      onSelectRef.current?.(raw);
    });

    cy.on('tap', (event) => {
      if (event.target === cy) {
        cy.elements().removeClass('faded neighbour');
        onSelectRef.current?.(null);
      }
    });

    cyRef.current = cy;
    setReady(true);

    return () => {
      cy.destroy();
      cyRef.current = null;
      setReady(false);
    };
  }, [data]);

  // Reflect externally-driven selection (e.g. clicking an influencer row).
  useEffect(() => {
    const cy = cyRef.current;
    if (!cy || !ready) return;
    cy.elements().removeClass('faded neighbour').unselect();
    if (!selectedId) return;
    const node = cy.getElementById(selectedId);
    if (node.nonempty()) {
      node.select();
      const neighbourhood = node.closedNeighborhood();
      cy.elements().difference(neighbourhood).addClass('faded');
      neighbourhood.addClass('neighbour');
      cy.animate({ center: { eles: node }, zoom: 1.4 }, { duration: 220 });
    }
  }, [selectedId, ready]);

  // Segment highlighting driven by the global filter selection.
  useEffect(() => {
    const cy = cyRef.current;
    if (!cy || !ready || selectedId) return;
    cy.elements().removeClass('faded neighbour');
    if (!highlightSegment) return;
    cy.nodes().forEach((node) => {
      const raw = node.data('raw') as GraphNode;
      if (raw.segment_id !== highlightSegment) node.addClass('faded');
    });
  }, [highlightSegment, ready, selectedId]);

  const zoom = useCallback((factor: number) => {
    const cy = cyRef.current;
    if (!cy) return;
    cy.zoom({ level: cy.zoom() * factor, renderedPosition: { x: cy.width() / 2, y: cy.height() / 2 } });
  }, []);

  const fit = useCallback(() => {
    cyRef.current?.animate({ fit: { eles: cyRef.current.elements(), padding: 30 } }, { duration: 220 });
  }, []);

  return (
    <div className="relative">
      <div
        ref={containerRef}
        style={{ height }}
        className="w-full rounded border border-edge-subtle bg-canvas-sunken"
        role="application"
        aria-label={`Influence network with ${data.nodes.length} accounts and ${data.edges.length} interactions`}
      />

      <div className="absolute right-2 top-2 flex flex-col gap-1">
        {[
          { icon: ZoomIn, label: 'Zoom in', action: () => zoom(1.3) },
          { icon: ZoomOut, label: 'Zoom out', action: () => zoom(0.77) },
          { icon: Maximize2, label: 'Fit to view', action: fit },
        ].map(({ icon: Icon, label, action }) => (
          <button
            key={label}
            type="button"
            onClick={action}
            aria-label={label}
            title={label}
            className="grid h-6 w-6 place-items-center rounded border border-edge-strong bg-canvas-raised text-ink-muted hover:text-ink"
          >
            <Icon className="h-3 w-3" aria-hidden />
          </button>
        ))}
      </div>

      <div className="pointer-events-none absolute bottom-2 left-2 rounded border border-edge-subtle bg-canvas-raised/90 px-2.5 py-1.5">
        <p className="text-[10px] leading-relaxed text-ink-faint">
          <span className="text-ink-muted">Size</span> = influence ·{' '}
          <span className="text-ink-muted">Colour</span> = audience segment ·{' '}
          <span className="text-warning">Ring</span> = bridge account ·{' '}
          <span className="text-ink-muted">Edge</span> = interaction
        </p>
      </div>
    </div>
  );
}

/** Details panel for the currently selected account. */
export function NodeInspector({ node }: { node: GraphNode | null }) {
  if (!node) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-1.5 px-4 py-8 text-center">
        <Crosshair className="h-4 w-4 text-ink-faint" aria-hidden />
        <p className="text-2xs text-ink-muted">Select a node to inspect an account</p>
        <p className="text-[10px] leading-relaxed text-ink-faint">
          Accounts are shown pseudonymously. No profile identifiers are exposed here.
        </p>
      </div>
    );
  }

  const rows: [string, string][] = [
    ['Influence score', `${node.influence_score.toFixed(1)} / 100`],
    ['PageRank', node.pagerank.toFixed(5)],
    ['Betweenness', node.betweenness.toFixed(5)],
    ['Degree centrality', node.degree_centrality.toFixed(4)],
    ['Connections', `${node.degree} (${node.in_degree} in / ${node.out_degree} out)`],
    ['Community', `#${node.community_id}`],
    ['Posts in window', String(node.posts)],
    ['Avg polarity', polarity(node.avg_polarity)],
    ['Public followers', compactNumber(node.reach)],
    ['Platform', platformLabel(node.platform)],
  ];

  return (
    <div className="p-3">
      <div className="flex flex-wrap items-center gap-1.5">
        <span className="font-mono text-[13px] font-semibold text-ink">{node.anon_id}</span>
        {node.is_bridge && <Badge tone="warning">Bridge account</Badge>}
        {node.verified && <Badge tone="influence">Verified</Badge>}
      </div>

      <div className="mt-1.5 flex items-center gap-1.5">
        <span
          className="h-2 w-2 rounded-full"
          style={{ backgroundColor: node.segment_color }}
          aria-hidden
        />
        <span className="text-2xs text-ink-muted">{node.segment_name}</span>
      </div>

      <dl className="mt-3 divide-y divide-edge-subtle">
        {rows.map(([label, value]) => (
          <div key={label} className="flex items-baseline justify-between gap-3 py-1">
            <dt className="text-2xs text-ink-faint">{label}</dt>
            <dd className="font-mono text-2xs tabular-nums text-ink-muted">{value}</dd>
          </div>
        ))}
      </dl>

      {node.is_bridge && (
        <p className="mt-2.5 rounded border border-warning/25 bg-warning/[0.06] px-2.5 py-2 text-2xs leading-relaxed text-ink-muted">
          {node.cross_community_edges} of this account&apos;s interactions cross community
          boundaries. Accounts like this determine whether a narrative stays inside one
          community.
        </p>
      )}

      {node.rationale.length > 0 && (
        <ul className="mt-2 space-y-0.5">
          {node.rationale.map((reason) => (
            <li key={reason} className={cx('flex gap-1.5 text-[10px] text-ink-faint')}>
              <span aria-hidden>·</span>
              {reason}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
