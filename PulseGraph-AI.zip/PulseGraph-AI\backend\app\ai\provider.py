"""AI provider contract.

Two responsibilities are deliberately separated:

1. `analyze_text` - per-post NLP classification (sentiment, stance, emotion,
   sarcasm). This is where a model genuinely adds value.
2. `interpret` - turning *already computed* statistics into an analyst-readable
   narrative. The numbers are never produced by the model; the model only
   phrases them.

Arithmetic is never routed through a provider. That distinction keeps the
product honest about where AI is and is not being used.
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field


@dataclass(slots=True)
class TextAnalysis:
    """Multi-dimensional result for a single piece of text."""

    sentiment: str = "neutral"            # positive | negative | neutral
    sentiment_confidence: float = 0.0
    stance: str = "neutral"               # supportive | against | neutral
    emotion: str = "neutral"              # excited | angry | anxious | ...
    emotion_confidence: float = 0.0
    polarity: float = 0.0                 # -1.0 .. +1.0
    literal_sentiment: str = "neutral"    # surface reading, before sarcasm
    contextual_sentiment: str = "neutral" # reading after contextual cues
    sarcasm_detected: bool = False
    sarcasm_confidence: float = 0.0
    cues: dict = field(default_factory=dict)
    model: str = ""
    model_version: str = ""
    status: str = "ok"


@dataclass(slots=True)
class Narrative:
    """Model-phrased interpretation of computed metrics."""

    summary: str
    recommended_action: str = ""
    source: str = "local"


class AIProvider(abc.ABC):
    name: str = "abstract"
    version: str = "0"

    @abc.abstractmethod
    def analyze_text(self, text: str, language: str = "en") -> TextAnalysis:
        ...

    @abc.abstractmethod
    def interpret(self, brief: dict) -> Narrative:
        """Phrase a computed analytical brief. Must not invent numbers."""

    def analyze_batch(self, items: list[tuple[str, str]]) -> list[TextAnalysis]:
        return [self.analyze_text(text, lang) for text, lang in items]

    def health(self) -> dict:
        return {"provider": self.name, "version": self.version, "status": "ok"}
