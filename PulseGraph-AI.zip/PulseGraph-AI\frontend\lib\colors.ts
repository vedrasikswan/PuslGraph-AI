/**
 * Semantic colour tokens.
 *
 * Charts and SVG need literal values, so the palette is mirrored here from the
 * Tailwind config. Colour is never the sole carrier of meaning in the UI - each
 * of these is always accompanied by a label, number or icon.
 */

import type { Sentiment, Severity, TrendClass } from '@/types/api';

export const COLORS = {
  positive: '#22c55e',
  negative: '#ef4444',
  neutral: '#94a3b8',
  warning: '#f59e0b',
  trend: '#818cf8',
  influence: '#22d3ee',
  critical: '#f43f5e',
  grid: '#1e2836',
  axis: '#64748b',
  ink: '#e6ebf3',
  muted: '#94a3b8',
} as const;

export const SENTIMENT_COLORS: Record<Sentiment, string> = {
  positive: COLORS.positive,
  negative: COLORS.negative,
  neutral: COLORS.neutral,
};

export const SEVERITY_STYLES: Record<Severity, { text: string; bg: string; border: string; dot: string }> = {
  critical: {
    text: 'text-critical',
    bg: 'bg-critical/10',
    border: 'border-critical/40',
    dot: 'bg-critical',
  },
  high: {
    text: 'text-negative',
    bg: 'bg-negative/10',
    border: 'border-negative/35',
    dot: 'bg-negative',
  },
  medium: {
    text: 'text-warning',
    bg: 'bg-warning/10',
    border: 'border-warning/35',
    dot: 'bg-warning',
  },
  low: {
    text: 'text-ink-muted',
    bg: 'bg-neutral/10',
    border: 'border-edge-strong',
    dot: 'bg-neutral',
  },
  info: {
    text: 'text-influence',
    bg: 'bg-influence/10',
    border: 'border-influence/30',
    dot: 'bg-influence',
  },
};

export const TREND_STYLES: Record<TrendClass, { text: string; bg: string; bar: string }> = {
  viral: { text: 'text-critical', bg: 'bg-critical/12', bar: '#f43f5e' },
  accelerating: { text: 'text-negative', bg: 'bg-negative/12', bar: '#ef4444' },
  growing: { text: 'text-warning', bg: 'bg-warning/12', bar: '#f59e0b' },
  emerging: { text: 'text-trend', bg: 'bg-trend/12', bar: '#818cf8' },
  stable: { text: 'text-ink-muted', bg: 'bg-neutral/10', bar: '#64748b' },
};

/** Distinct, colour-blind-safer hues for graph communities. */
export const COMMUNITY_COLORS = [
  '#38bdf8', '#f97316', '#a855f7', '#22c55e', '#eab308',
  '#f43f5e', '#14b8a6', '#c084fc', '#fb7185', '#84cc16',
];

export function communityColor(id: number): string {
  return COMMUNITY_COLORS[Math.abs(id) % COMMUNITY_COLORS.length];
}

/** Map a polarity in -1..1 onto the negative/neutral/positive ramp. */
export function polarityColor(value: number): string {
  if (value <= -0.12) return COLORS.negative;
  if (value >= 0.12) return COLORS.positive;
  return COLORS.neutral;
}
