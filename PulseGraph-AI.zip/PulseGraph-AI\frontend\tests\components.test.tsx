/**
 * Component behaviour: rendering real payload shapes, loading and error states,
 * and the explainability affordances.
 */

import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';

import { EvidenceTable, WhyPanel } from '@/components/ui/Evidence';
import { KpiStrip } from '@/components/ui/KpiStrip';
import {
  ConfidenceBadge,
  Delta,
  EmptyState,
  ErrorState,
  SentimentBadge,
  SeverityBadge,
  TrendBadge,
} from '@/components/ui/primitives';
import { PlatformDivergence } from '@/components/charts/PlatformDivergence';

import { intelligenceCard, kpis } from './fixtures';

// The FilterProvider depends on Next navigation; components under test that use
// it are exercised in interactions.test.tsx with the router mocked there.
vi.mock('next/navigation', () => ({
  useRouter: () => ({ replace: vi.fn(), push: vi.fn() }),
  usePathname: () => '/dashboard',
  useSearchParams: () => new URLSearchParams(),
}));

describe('KpiStrip', () => {
  it('renders every KPI with a formatted value', () => {
    render(<KpiStrip kpis={kpis} />);
    expect(screen.getByText('Total posts')).toBeInTheDocument();
    expect(screen.getByText('973')).toBeInTheDocument();
    expect(screen.getByText('16.3%')).toBeInTheDocument();
    expect(screen.getByText('45k')).toBeInTheDocument();
  });

  it('shows a change against the previous window', () => {
    render(<KpiStrip kpis={kpis} />);
    expect(screen.getAllByText(/472\.4%/).length).toBeGreaterThan(0);
  });

  it('states plainly when there is no baseline rather than showing 0%', () => {
    render(<KpiStrip kpis={kpis} />);
    expect(screen.getAllByText('no prior window').length).toBe(2);
  });

  it('renders a skeleton while loading and no values', () => {
    render(<KpiStrip kpis={null} loading />);
    expect(screen.getAllByRole('status')).toBeTruthy();
    expect(screen.queryByText('973')).not.toBeInTheDocument();
  });
});

describe('Delta', () => {
  it('treats rising negative sentiment as bad news', () => {
    const { container } = render(<Delta value={12} invert />);
    expect(container.querySelector('.text-negative')).toBeTruthy();
  });

  it('treats rising post volume as neutral-good', () => {
    const { container } = render(<Delta value={12} />);
    expect(container.querySelector('.text-positive')).toBeTruthy();
  });

  it('handles a missing baseline', () => {
    render(<Delta value={null} />);
    expect(screen.getByText('no prior window')).toBeInTheDocument();
  });
});

describe('Badges pair colour with text', () => {
  it('severity badge names the level', () => {
    render(<SeverityBadge severity="critical" />);
    expect(screen.getByText('Critical')).toBeInTheDocument();
  });

  it('trend badge shows classification and score', () => {
    render(<TrendBadge classification="viral" score={87} />);
    expect(screen.getByText('Viral')).toBeInTheDocument();
    expect(screen.getByText('87')).toBeInTheDocument();
  });

  it('sentiment badge carries a glyph and a label, not colour alone', () => {
    render(<SentimentBadge sentiment="negative" value="-0.39" />);
    expect(screen.getByText('negative')).toBeInTheDocument();
    expect(screen.getByText('-0.39')).toBeInTheDocument();
    expect(screen.getByText('▼')).toBeInTheDocument();
  });

  it('confidence badge always shows the band and the number', () => {
    render(<ConfidenceBadge band="Medium" value={0.72} />);
    expect(screen.getByText(/Medium/)).toBeInTheDocument();
    expect(screen.getByText('0.72')).toBeInTheDocument();
  });
});

describe('Evidence', () => {
  it('renders each metric with value, change and period', () => {
    render(<EvidenceTable evidence={intelligenceCard.evidence} />);
    expect(screen.getByText('Negative Sentiment Share')).toBeInTheDocument();
    expect(screen.getByText('0.634')).toBeInTheDocument();
    expect(screen.getByText('+30.1%')).toBeInTheDocument();
    expect(screen.getAllByText('last 6 hours').length).toBeGreaterThan(0);
  });

  it('says so when a conclusion has no supporting metrics', () => {
    render(<EvidenceTable evidence={[]} />);
    expect(screen.getByText(/No supporting metrics/)).toBeInTheDocument();
  });

  it('Why? is collapsed until asked, then reveals the evidence', async () => {
    const user = userEvent.setup();
    render(
      <WhyPanel
        evidence={intelligenceCard.evidence}
        confidence={0.93}
        confidenceBand="High"
        drivers={['battery-drain discussion volume']}
        source="local"
      />,
    );

    expect(screen.queryByText('Evidence used')).not.toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: /Why\?/ }));

    expect(screen.getByText('Evidence used')).toBeInTheDocument();
    expect(screen.getByText('Negative Sentiment Share')).toBeInTheDocument();
    expect(screen.getByText(/Likely driver/)).toBeInTheDocument();
  });

  it('never presents ordering in time as causation', async () => {
    const user = userEvent.setup();
    render(<WhyPanel evidence={intelligenceCard.evidence} />);
    await user.click(screen.getByRole('button', { name: /Why\?/ }));
    expect(screen.getByText(/not evidence of causation/i)).toBeInTheDocument();
  });

  it('names what produced the interpretation', async () => {
    const user = userEvent.setup();
    render(<WhyPanel evidence={intelligenceCard.evidence} source="openai" />);
    await user.click(screen.getByRole('button', { name: /Why\?/ }));
    expect(screen.getByText(/Phrased by openai/)).toBeInTheDocument();
  });
});

describe('States', () => {
  it('empty state explains what to do next', () => {
    render(<EmptyState />);
    expect(screen.getByText('No data for these filters')).toBeInTheDocument();
    expect(screen.getByText(/Widen the time range/)).toBeInTheDocument();
  });

  it('error state distinguishes an unreachable backend', () => {
    render(
      <ErrorState
        error={{ message: 'Cannot reach the PulseGraph backend.', status: 0, hint: 'start uvicorn' }}
      />,
    );
    expect(screen.getByText('Backend unreachable')).toBeInTheDocument();
    expect(screen.getByText('start uvicorn')).toBeInTheDocument();
  });

  it('error state distinguishes a missing dataset', () => {
    render(
      <ErrorState error={{ message: 'No dataset loaded.', status: 409, needsDataset: true }} />,
    );
    expect(screen.getByText('No dataset loaded')).toBeInTheDocument();
  });

  it('error state offers a retry that calls back', async () => {
    const user = userEvent.setup();
    const onRetry = vi.fn();
    render(<ErrorState error={{ message: 'boom' }} onRetry={onRetry} />);
    await user.click(screen.getByRole('button', { name: /Retry/ }));
    expect(onRetry).toHaveBeenCalledOnce();
  });

  it('never shows a raw stack trace', () => {
    render(<ErrorState error={{ message: 'Something went wrong while computing this view.' }} />);
    expect(screen.queryByText(/Traceback/)).not.toBeInTheDocument();
    expect(screen.queryByText(/sqlalchemy/i)).not.toBeInTheDocument();
  });
});

describe('PlatformDivergence', () => {
  const platforms = [
    { platform: 'telegram', posts: 40, unique_authors: 22, engagement: 900, avg_polarity: -0.62, negative_share: 0.7, positive_share: 0.1 },
    { platform: 'x', posts: 120, unique_authors: 80, engagement: 5400, avg_polarity: -0.41, negative_share: 0.6, positive_share: 0.15 },
    { platform: 'reddit', posts: 30, unique_authors: 20, engagement: 700, avg_polarity: 0.08, negative_share: 0.2, positive_share: 0.35 },
  ];

  it('lists every platform with its own polarity', () => {
    render(<PlatformDivergence platforms={platforms} divergence={0.7} interpretation="Communities differ." />);
    const table = screen.getByRole('table');
    expect(within(table).getByText('Telegram')).toBeInTheDocument();
    expect(within(table).getByText('Reddit')).toBeInTheDocument();
    expect(screen.getByText('Spread 0.70')).toBeInTheDocument();
    expect(screen.getByText('Communities differ.')).toBeInTheDocument();
  });

  it('suppresses platforms with too little data to report', () => {
    render(<PlatformDivergence platforms={[{ ...platforms[0], posts: 1 }]} />);
    expect(screen.getByText(/Not enough per-platform data/)).toBeInTheDocument();
  });
});
