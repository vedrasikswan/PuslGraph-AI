'use client';

/**
 * Live system status: demo-mode indicator, AI provider, dataset size.
 *
 * The demo badge is deliberately prominent - a viewer should never be unsure
 * whether they are looking at live platform data or the synthetic corpus.
 */

import Link from 'next/link';
import { CircleDot, Cpu, FlaskConical } from 'lucide-react';

import { api } from '@/lib/api';
import { useApi } from '@/hooks/useApi';
import { compactNumber } from '@/lib/format';
import { Badge, cx } from '@/components/ui/primitives';
import type { HealthResponse } from '@/types/api';

export function StatusStrip() {
  const { data, error } = useApi<HealthResponse>('health', () => api.health());

  if (error) {
    return (
      <Badge tone="negative" title={error.hint || error.message}>
        <CircleDot className="h-3 w-3" aria-hidden />
        Backend offline
      </Badge>
    );
  }

  if (!data) {
    return (
      <span className="text-2xs text-ink-faint" role="status">
        Connecting…
      </span>
    );
  }

  const degraded = data.status === 'degraded';

  return (
    <div className="flex items-center gap-1.5">
      {data.demo_mode && (
        <Link href="/data" title="No live platform credentials configured. Showing the deterministic demo corpus.">
          <Badge tone="warning" className="font-semibold">
            <FlaskConical className="h-3 w-3" aria-hidden />
            DEMO MODE
          </Badge>
        </Link>
      )}

      <Badge
        tone={degraded ? 'warning' : 'neutral'}
        className="hidden lg:inline-flex"
        title={`AI provider: ${data.ai_provider.provider} ${data.ai_provider.version}${
          data.ai_provider.fallback ? ` (falls back to ${data.ai_provider.fallback})` : ''
        }`}
      >
        <Cpu className="h-3 w-3" aria-hidden />
        {data.ai_provider.provider}
      </Badge>

      <span
        className={cx(
          'hidden items-center gap-1 text-2xs text-ink-faint xl:flex',
          !data.dataset_ready && 'text-warning',
        )}
      >
        {data.dataset_ready ? `${compactNumber(data.posts)} posts` : 'no dataset'}
      </span>
    </div>
  );
}
