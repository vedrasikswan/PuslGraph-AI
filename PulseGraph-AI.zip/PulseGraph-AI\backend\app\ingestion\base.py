"""Ingestion contract shared by every platform adapter.

The whole platform reads from `NormalizedPost` / `NormalizedAuthor`, never from
a platform-specific payload. Adding a real API later means implementing
`fetch()` on one adapter; nothing downstream changes.
"""

from __future__ import annotations

import abc
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class SourceStatus(str, Enum):
    CONNECTED = "connected"
    DEMO = "demo"
    NOT_CONNECTED = "not_connected"
    ERROR = "error"


class SourceTier(str, Enum):
    ESSENTIAL = "essential"
    DESIRABLE = "desirable"
    APPRECIABLE = "appreciable"
    SYNTHETIC = "synthetic"


HASHTAG_RE = re.compile(r"#(\w+)")
MENTION_RE = re.compile(r"@([A-Za-z0-9_]+)")


@dataclass(slots=True)
class NormalizedAuthor:
    """Public account metadata, normalised across platforms."""

    author_id: str
    platform: str
    display_name: str
    handle: str = ""
    bio: str = ""
    followers_count: int = 0
    following_count: int = 0
    verified: bool = False
    account_created_at: datetime | None = None
    location: str = ""
    language: str = "en"


@dataclass(slots=True)
class NormalizedPost:
    """The single internal representation of any social item.

    Every adapter must produce this shape. Fields that a platform does not
    expose stay at their neutral default rather than being invented.
    """

    id: str
    platform: str
    author_id: str
    author_name: str
    text: str
    timestamp: datetime
    language: str = "en"
    reply_to_id: str | None = None
    parent_post_id: str | None = None
    hashtags: list[str] = field(default_factory=list)
    mentions: list[str] = field(default_factory=list)
    likes: int = 0
    comments: int = 0
    shares: int = 0
    views: int = 0
    location: str = ""
    source_id: str = ""

    @property
    def engagement_count(self) -> int:
        return self.likes + self.comments + self.shares

    def __post_init__(self) -> None:
        if not self.hashtags:
            self.hashtags = [h.lower() for h in HASHTAG_RE.findall(self.text)]
        if not self.mentions:
            self.mentions = MENTION_RE.findall(self.text)


@dataclass(slots=True)
class IngestionBatch:
    source_id: str
    platform: str
    status: SourceStatus
    posts: list[NormalizedPost] = field(default_factory=list)
    authors: list[NormalizedAuthor] = field(default_factory=list)
    message: str = ""


class DataSourceAdapter(abc.ABC):
    """Base class for every platform connector."""

    source_id: str = "generic"
    platform: str = "generic"
    display_name: str = "Generic source"
    tier: SourceTier = SourceTier.APPRECIABLE
    credential_fields: tuple[str, ...] = ()
    capabilities: tuple[str, ...] = ()
    docs_url: str = ""

    def __init__(self, credentials: dict[str, str] | None = None) -> None:
        self.credentials = {k: v for k, v in (credentials or {}).items() if v}

    # -- credential handling -------------------------------------------------
    def has_credentials(self) -> bool:
        if not self.credential_fields:
            return True
        return all(self.credentials.get(f) for f in self.credential_fields)

    def status(self) -> SourceStatus:
        return SourceStatus.CONNECTED if self.has_credentials() else SourceStatus.NOT_CONNECTED

    def missing_credentials(self) -> list[str]:
        return [f for f in self.credential_fields if not self.credentials.get(f)]

    # -- data --------------------------------------------------------------
    @abc.abstractmethod
    def fetch(self, query: str, limit: int = 200) -> IngestionBatch:
        """Pull items for `query`. Adapters without credentials must not
        fabricate connectivity - they return an empty batch with an
        explanatory message and NOT_CONNECTED status."""

    def describe(self) -> dict:
        return {
            "id": self.source_id,
            "platform": self.platform,
            "display_name": self.display_name,
            "tier": self.tier.value,
            "status": self.status().value,
            "requires_credentials": bool(self.credential_fields),
            "credential_fields": list(self.credential_fields),
            "missing_credentials": self.missing_credentials(),
            "capabilities": list(self.capabilities),
            "docs_url": self.docs_url,
        }


class LiveApiAdapter(DataSourceAdapter):
    """Shared behaviour for adapters backed by a real HTTP API.

    The demo ships without credentials, so `fetch` short-circuits with an
    honest NOT_CONNECTED batch instead of pretending to reach the network.
    Implementations override `_fetch_live`.
    """

    def fetch(self, query: str, limit: int = 200) -> IngestionBatch:
        if not self.has_credentials():
            missing = ", ".join(self.missing_credentials())
            return IngestionBatch(
                source_id=self.source_id,
                platform=self.platform,
                status=SourceStatus.NOT_CONNECTED,
                message=f"{self.display_name} is not connected. Missing credentials: {missing}.",
            )
        try:
            return self._fetch_live(query, limit)
        except Exception as exc:  # pragma: no cover - network paths
            return IngestionBatch(
                source_id=self.source_id,
                platform=self.platform,
                status=SourceStatus.ERROR,
                message=f"{self.display_name} request failed: {exc}",
            )

    def _fetch_live(self, query: str, limit: int) -> IngestionBatch:  # pragma: no cover
        raise NotImplementedError
