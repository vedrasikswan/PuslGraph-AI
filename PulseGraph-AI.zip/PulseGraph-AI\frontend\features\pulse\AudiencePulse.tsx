'use client';

/**
 * The Audience Pulse — the product's central intelligence statement.
 *
 * It answers, in one block: what changed, when, where, who contributed, how it
 * spread, and why the system thinks so. Confidence and evidence sit next to the
 * claim rather than behind a tooltip, and every number comes from the API.
 */

import Link from 'next/link';
import { ArrowUpRight, Radar } from 'lucide-react';

import { WhyPanel } from '@/components/ui/Evidence';
import {
  Badge,
  ConfidenceBadge,
  EmptyState,
  Panel,
  PanelSkeleton,
  SeverityBadge,
  cx,
} from '@/components/ui/primitives';
import { SEVERITY_STYLES } from '@/lib/colors';
import { platformLabel, relativeTime } from '@/lib/format';
import type { AudiencePulse as Pulse } from '@/types/api';

import { useFilters } from '../filters/FilterContext';

export function AudiencePulseCard({
  pulse,
  loading,
}: {
  pulse: Pulse | null;
  loading?: boolean;
}) {
  const { toggle, filters } = useFilters();

  if (loading) {
    return (
      <Panel title="Audience Pulse">
        <PanelSkeleton rows={4} height="h-5" />
      </Panel>
    );
  }

  if (!pulse) {
    return (
      <Panel title="Audience Pulse" subtitle="Correlated view of what changed">
        <EmptyState
          icon={Radar}
          title="No significant change detected"
          description="Nothing in the current selection crossed a detection threshold. Widen the time range or clear a filter to see the full picture."
        />
      </Panel>
    );
  }

  const style = SEVERITY_STYLES[pulse.severity];

  return (
    <Panel
      className={cx('border-l-2', style.border.replace('border-', 'border-l-'))}
      title={
        <span className="flex items-center gap-2">
          <Radar className="h-3.5 w-3.5 text-trend" aria-hidden />
          Audience Pulse
        </span>
      }
      subtitle={`Detected ${relativeTime(pulse.detected_at)} · correlated across sentiment, topic momentum, audience and network`}
      actions={
        <>
          <SeverityBadge severity={pulse.severity} />
          <ConfidenceBadge band={pulse.confidence_band} value={pulse.confidence} />
        </>
      }
    >
      <p className="text-pretty text-[15px] font-medium leading-relaxed text-ink">
        {pulse.statement}
      </p>

      <div className="mt-3 flex flex-wrap items-center gap-1.5">
        {pulse.topic_id && (
          <Link href={`/topics/${pulse.topic_id}`} className="group">
            <Badge tone="trend" className="group-hover:border-trend/60">
              Topic: {pulse.topic_label ?? pulse.topic_id}
              <ArrowUpRight className="h-2.5 w-2.5" aria-hidden />
            </Badge>
          </Link>
        )}

        {pulse.affected_segments.map((segment) => (
          <Badge key={segment} tone="influence">
            Segment: {segment}
          </Badge>
        ))}

        {pulse.affected_platforms.map((platform) => (
          <button
            key={platform}
            type="button"
            onClick={() => toggle('platforms', platform)}
            title={`Filter the whole dashboard to ${platformLabel(platform)}`}
          >
            <Badge
              tone={filters.platforms.includes(platform) ? 'trend' : 'neutral'}
              className="hover:border-edge-strong"
            >
              {platformLabel(platform)}
            </Badge>
          </button>
        ))}
      </div>

      {pulse.recommended_action && (
        <div className="mt-3 rounded border border-edge-subtle bg-canvas-sunken px-3 py-2">
          <p className="text-2xs font-semibold uppercase tracking-wider text-ink-faint">
            Recommended next step
          </p>
          <p className="mt-1 text-2xs leading-relaxed text-ink-muted">
            {pulse.recommended_action}
          </p>
        </div>
      )}

      <WhyPanel
        evidence={pulse.evidence}
        confidence={pulse.confidence}
        confidenceBand={pulse.confidence_band}
        source={pulse.interpretation_source}
        method="Pooled from the highest-ranked detection and its supporting events for this topic. Ranking weights category, severity, materiality (share of conversation covered) and confidence."
      />

      {pulse.supporting_events.length > 0 && (
        <div className="mt-3 border-t border-edge-subtle pt-2.5">
          <p className="text-2xs font-semibold uppercase tracking-wider text-ink-faint">
            Corroborating detections
          </p>
          <ul className="mt-1.5 space-y-1">
            {pulse.supporting_events.map((event) => (
              <li key={event.id} className="flex items-start gap-1.5 text-2xs text-ink-muted">
                <span className="mt-1 h-1 w-1 shrink-0 rounded-full bg-ink-faint" aria-hidden />
                {event.title}
              </li>
            ))}
          </ul>
        </div>
      )}
    </Panel>
  );
}
