/**
 * Feature-level behaviour: the Pulse, the intelligence feed, the journey, the
 * trend radar, and the global filter state that ties them together.
 */

import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, describe, expect, it, vi } from 'vitest';

const replace = vi.fn();
let currentParams = new URLSearchParams();

vi.mock('next/navigation', () => ({
  useRouter: () => ({ replace, push: vi.fn() }),
  usePathname: () => '/dashboard',
  useSearchParams: () => currentParams,
}));

import { FilterProvider, useFilters } from '@/features/filters/FilterContext';
import { IntelligenceFeed } from '@/features/intelligence/IntelligenceFeed';
import { NarrativeJourney } from '@/features/journey/NarrativeJourney';
import { AudiencePulseCard } from '@/features/pulse/AudiencePulse';
import { TrendRadar } from '@/features/trends/TrendRadar';
import { AudienceMap } from '@/features/audience/AudienceMap';

import { infoCard, intelligenceCard, journey, pulse, segment, stableTrend, trend } from './fixtures';

function wrap(ui: React.ReactNode) {
  return render(<FilterProvider>{ui}</FilterProvider>);
}

beforeEach(() => {
  currentParams = new URLSearchParams();
  replace.mockClear();
});

describe('Audience Pulse', () => {
  it('leads with the full intelligence statement', () => {
    wrap(<AudiencePulseCard pulse={pulse} />);
    expect(screen.getByText(/is viral: 545 mentions/)).toBeInTheDocument();
    expect(screen.getByText(/preceded the increase elsewhere/)).toBeInTheDocument();
  });

  it('shows severity and confidence next to the claim, not hidden', () => {
    wrap(<AudiencePulseCard pulse={pulse} />);
    expect(screen.getByText('High')).toBeInTheDocument();
    expect(screen.getByText('0.88')).toBeInTheDocument();
  });

  it('surfaces the affected topic, segment and platforms', () => {
    wrap(<AudiencePulseCard pulse={pulse} />);
    expect(screen.getByText(/Topic: NovaPhone X battery drain/)).toBeInTheDocument();
    expect(screen.getByText(/Segment: Concerned Customers/)).toBeInTheDocument();
    expect(screen.getByText('Telegram')).toBeInTheDocument();
  });

  it('exposes the evidence behind the statement', async () => {
    const user = userEvent.setup();
    wrap(<AudiencePulseCard pulse={pulse} />);
    await user.click(screen.getByRole('button', { name: /Why\?/ }));
    expect(screen.getByText('Lead Time Minutes')).toBeInTheDocument();
    expect(screen.getByText('Engagement Velocity')).toBeInTheDocument();
  });

  it('clicking a platform chip filters the whole dashboard', async () => {
    const user = userEvent.setup();
    wrap(<AudiencePulseCard pulse={pulse} />);
    await user.click(screen.getByTitle(/Filter the whole dashboard to Telegram/));
    expect(replace).toHaveBeenCalledWith(
      expect.stringContaining('platforms=telegram'),
      expect.anything(),
    );
  });

  it('states that nothing was detected rather than inventing a headline', () => {
    wrap(<AudiencePulseCard pulse={null} />);
    expect(screen.getByText('No significant change detected')).toBeInTheDocument();
  });

  it('shows a loading state without a stale statement', () => {
    wrap(<AudiencePulseCard pulse={null} loading />);
    expect(screen.queryByText(/545 mentions/)).not.toBeInTheDocument();
  });
});

describe('Intelligence feed', () => {
  it('renders each card with severity, confidence and evidence', () => {
    wrap(<IntelligenceFeed cards={[intelligenceCard]} />);
    const card = screen.getByRole('article');
    expect(within(card).getByText(intelligenceCard.title)).toBeInTheDocument();
    expect(within(card).getByText('Critical')).toBeInTheDocument();
    expect(within(card).getByText('0.93')).toBeInTheDocument();
  });

  it('lists the accounts involved pseudonymously', () => {
    wrap(<IntelligenceFeed cards={[intelligenceCard]} />);
    expect(screen.getByText('A2218')).toBeInTheDocument();
    expect(screen.getByText('bridge')).toBeInTheDocument();
  });

  it('orders by severity so the most serious detection is first', () => {
    wrap(<IntelligenceFeed cards={[infoCard, intelligenceCard]} />);
    const headings = screen.getAllByRole('heading', { level: 3 });
    expect(headings[0]).toHaveTextContent('Negative sentiment spike');
  });

  it('can be filtered by severity', async () => {
    const user = userEvent.setup();
    wrap(<IntelligenceFeed cards={[infoCard, intelligenceCard]} />);
    await user.click(screen.getByRole('button', { name: /^Info/ }));
    expect(screen.queryByText(intelligenceCard.title)).not.toBeInTheDocument();
    expect(screen.getByText(infoCard.title)).toBeInTheDocument();
  });

  it('explains an empty feed instead of showing a blank panel', () => {
    wrap(<IntelligenceFeed cards={[]} />);
    expect(screen.getByText('No detections for this selection')).toBeInTheDocument();
  });

  it('shows a loading state', () => {
    wrap(<IntelligenceFeed cards={null} loading />);
    expect(screen.queryByText(intelligenceCard.title)).not.toBeInTheDocument();
  });
});

describe('Narrative Journey', () => {
  it('renders milestones in order with their platform', () => {
    wrap(<NarrativeJourney journey={journey} />);
    expect(screen.getByText('Episode opens on telegram')).toBeInTheDocument();
    expect(screen.getByText('Discussion reaches x')).toBeInTheDocument();
  });

  it('quantifies the cross-platform lead and refuses a causal reading', () => {
    wrap(<NarrativeJourney journey={journey} />);
    // The lead time is stated in the summary callout and again on the milestone.
    expect(screen.getAllByText(/51 min/).length).toBeGreaterThanOrEqual(1);
    expect(screen.getByText(/not evidence of causation/i)).toBeInTheDocument();
  });

  it('separates the episode from background chatter', () => {
    wrap(<NarrativeJourney journey={journey} />);
    expect(screen.getByText(/537 of 615 posts/)).toBeInTheDocument();
  });

  it('handles a topic with too little activity', () => {
    wrap(<NarrativeJourney journey={{ ...journey, milestones: [], lead_lag: [] }} />);
    expect(screen.getByText(/Not enough activity/)).toBeInTheDocument();
  });
});

describe('Trend radar', () => {
  it('shows the score, classification and velocity', () => {
    wrap(<TrendRadar trends={[trend]} />);
    expect(screen.getByText('Viral')).toBeInTheDocument();
    // Score appears in the classification badge and as the headline figure.
    expect(screen.getAllByText('87')).toHaveLength(2);
    expect(screen.getByText(/vs previous period/)).toBeInTheDocument();
  });

  it('labels momentum as a forecast with a confidence band', () => {
    wrap(<TrendRadar trends={[trend]} />);
    expect(screen.getByText(/Momentum: Likely To Stabilise · High/)).toBeInTheDocument();
  });

  it('exposes the scoring formula rather than asserting a number', async () => {
    const user = userEvent.setup();
    wrap(<TrendRadar trends={[trend]} />);
    await user.click(screen.getByRole('button', { name: /How was this scored\?/ }));
    expect(screen.getByText(/trend_score = 100 x small_sample_discount/)).toBeInTheDocument();
    expect(screen.getByText('Volume Growth')).toBeInTheDocument();
  });

  it('renders a declining topic distinctly from a rising one', () => {
    wrap(<TrendRadar trends={[trend, stableTrend]} />);
    expect(screen.getByText('Viral')).toBeInTheDocument();
    expect(screen.getByText('Stable')).toBeInTheDocument();
  });

  it('explains an empty radar', () => {
    wrap(<TrendRadar trends={[]} />);
    expect(screen.getByText('No topics in this selection')).toBeInTheDocument();
  });
});

describe('Audience map', () => {
  it('shows size, sentiment and the behavioural basis for the segment', () => {
    wrap(<AudienceMap segments={[segment]} />);
    expect(screen.getByText('Concerned Customers')).toBeInTheDocument();
    expect(screen.getByText('27')).toBeInTheDocument();
    expect(screen.getByText(/Segment defined by:/)).toBeInTheDocument();
  });

  it('clicking a segment filters the dashboard to it', async () => {
    const user = userEvent.setup();
    wrap(<AudienceMap segments={[segment]} />);
    await user.click(screen.getByTitle(/Filter the dashboard to this segment/));
    expect(replace).toHaveBeenCalledWith(
      expect.stringContaining('segments=concerned-customers'),
      expect.anything(),
    );
  });

  it('states that segments are behavioural, not identities', () => {
    wrap(<AudienceMap segments={[segment]} />);
    expect(screen.getByText(/not verified identities/)).toBeInTheDocument();
  });
});

/** Direct exercise of the shared filter state. */
function FilterProbe() {
  const { filters, activeCount, toggle, setRange, setWindow, clear } = useFilters();
  return (
    <div>
      <span data-testid="count">{activeCount}</span>
      <span data-testid="platforms">{filters.platforms.join(',')}</span>
      <span data-testid="range">{filters.range}</span>
      <button onClick={() => toggle('platforms', 'x')}>toggle-x</button>
      <button onClick={() => setRange('6h')}>range-6h</button>
      <button onClick={() => setWindow('2026-08-25T01:00:00', '2026-08-25T02:00:00')}>window</button>
      <button onClick={clear}>clear</button>
    </div>
  );
}

describe('Global filter state', () => {
  it('defaults to the last 24 hours with nothing active', () => {
    wrap(<FilterProbe />);
    expect(screen.getByTestId('range')).toHaveTextContent('24h');
    expect(screen.getByTestId('count')).toHaveTextContent('0');
  });

  it('writes selections to the URL so every view reads the same state', async () => {
    const user = userEvent.setup();
    wrap(<FilterProbe />);
    await user.click(screen.getByText('toggle-x'));
    await waitFor(() =>
      expect(replace).toHaveBeenCalledWith(
        expect.stringContaining('platforms=x'),
        expect.anything(),
      ),
    );
  });

  it('reads existing URL state on mount', () => {
    currentParams = new URLSearchParams('platforms=x,telegram&range=6h');
    wrap(<FilterProbe />);
    expect(screen.getByTestId('platforms')).toHaveTextContent('x,telegram');
    expect(screen.getByTestId('range')).toHaveTextContent('6h');
    expect(screen.getByTestId('count')).toHaveTextContent('2');
  });

  it('an explicit window overrides the relative range', () => {
    currentParams = new URLSearchParams('start=2026-08-25T01:00:00&end=2026-08-25T02:00:00');
    wrap(<FilterProbe />);
    expect(screen.getByTestId('range')).toHaveTextContent('custom');
  });

  it('selecting a time window clears the relative range', async () => {
    const user = userEvent.setup();
    currentParams = new URLSearchParams('range=6h');
    wrap(<FilterProbe />);
    await user.click(screen.getByText('window'));
    const url = replace.mock.calls.at(-1)?.[0] as string;
    expect(url).toContain('start=');
    expect(url).not.toContain('range=');
  });

  it('clearing removes every filter from the URL', async () => {
    const user = userEvent.setup();
    currentParams = new URLSearchParams('platforms=x&topics=battery-drain&search=nova');
    wrap(<FilterProbe />);
    await user.click(screen.getByText('clear'));
    const url = replace.mock.calls.at(-1)?.[0] as string;
    expect(url).not.toContain('platforms=');
    expect(url).not.toContain('topics=');
    expect(url).not.toContain('search=');
  });
});
