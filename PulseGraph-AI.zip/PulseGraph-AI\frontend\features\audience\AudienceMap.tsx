'use client';

/**
 * Audience Map — dynamic segments rather than a static demographic pie.
 *
 * Each card reports size, dominant sentiment, dominant topics, engagement and
 * the sentiment trajectory, plus the behavioural rationale that put accounts in
 * the segment. Clicking a card filters the whole dashboard to that segment.
 */

import Link from 'next/link';
import { ArrowUpRight, Users } from 'lucide-react';

import {
  Badge,
  Bar,
  EmptyState,
  Panel,
  PanelSkeleton,
  SentimentBadge,
  cx,
} from '@/components/ui/primitives';
import { SENTIMENT_COLORS, polarityColor } from '@/lib/colors';
import { compactNumber, platformLabel, polarity, titleCase } from '@/lib/format';
import type { SegmentSummary } from '@/types/api';

import { useFilters } from '../filters/FilterContext';

function Sparkline({ points }: { points: { avg_polarity: number }[] }) {
  if (points.length < 2) return null;
  const values = points.map((p) => p.avg_polarity);
  const min = Math.min(...values, -0.1);
  const max = Math.max(...values, 0.1);
  const range = max - min || 1;
  const path = values
    .map((value, index) => {
      const x = (index / (values.length - 1)) * 100;
      const y = 20 - ((value - min) / range) * 18;
      return `${index === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');
  const last = values[values.length - 1];

  return (
    <svg
      viewBox="0 0 100 22"
      preserveAspectRatio="none"
      className="h-5 w-full"
      role="img"
      aria-label={`Sentiment trajectory, ending at ${polarity(last)}`}
    >
      <line x1="0" y1={20 - ((0 - min) / range) * 18} x2="100"
            y2={20 - ((0 - min) / range) * 18}
            stroke="#1e2836" strokeWidth="0.5" strokeDasharray="2 2" />
      <path d={path} fill="none" stroke={polarityColor(last)} strokeWidth="1.2" />
    </svg>
  );
}

export function SegmentCard({ segment }: { segment: SegmentSummary }) {
  const { filters, toggle } = useFilters();
  const active = filters.segments.includes(segment.id);
  const maxTopic = Math.max(...segment.dominant_topics.map((t) => t.posts), 1);

  return (
    <div
      className={cx(
        'rounded border bg-canvas-raised p-3 transition-colors',
        active ? 'border-trend/50' : 'border-edge hover:border-edge-strong',
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <button
          type="button"
          onClick={() => toggle('segments', segment.id)}
          className="min-w-0 flex-1 text-left"
          title={active ? 'Remove this segment filter' : 'Filter the dashboard to this segment'}
        >
          <span className="flex items-center gap-1.5">
            <span
              className="h-2 w-2 shrink-0 rounded-full"
              style={{ backgroundColor: segment.color }}
              aria-hidden
            />
            <span className="truncate text-[13px] font-medium text-ink">{segment.name}</span>
          </span>
        </button>
        <SentimentBadge
          sentiment={segment.dominant_sentiment}
          value={polarity(segment.avg_polarity)}
        />
      </div>

      <p className="mt-1.5 line-clamp-2 text-2xs leading-relaxed text-ink-faint">
        {segment.description}
      </p>

      <dl className="mt-2.5 grid grid-cols-3 gap-2">
        <div>
          <dt className="text-[10px] text-ink-faint">Accounts</dt>
          <dd className="font-mono text-sm tabular-nums text-ink">{segment.size}</dd>
        </div>
        <div>
          <dt className="text-[10px] text-ink-faint">Posts</dt>
          <dd className="font-mono text-sm tabular-nums text-ink">
            {compactNumber(segment.posts)}
          </dd>
        </div>
        <div>
          <dt className="text-[10px] text-ink-faint">Engagement</dt>
          <dd className="font-mono text-sm tabular-nums text-ink">
            {compactNumber(segment.avg_engagement)}
            <span className="ml-1 text-[10px] font-normal text-ink-faint">
              {titleCase(segment.engagement_level)}
            </span>
          </dd>
        </div>
      </dl>

      {segment.sentiment_trend.length > 1 && (
        <div className="mt-2">
          <p className="text-[10px] text-ink-faint">Sentiment trajectory</p>
          <Sparkline points={segment.sentiment_trend} />
        </div>
      )}

      {segment.dominant_topics.length > 0 && (
        <div className="mt-2 space-y-1">
          <p className="text-[10px] text-ink-faint">Dominant topics</p>
          {segment.dominant_topics.slice(0, 3).map((topic) => (
            <div key={topic.topic_id} className="flex items-center gap-2">
              <Link
                href={`/topics/${topic.topic_id}`}
                className="min-w-0 flex-1 truncate text-2xs text-ink-muted hover:text-ink hover:underline"
              >
                {topic.topic_id}
              </Link>
              <div className="w-16">
                <Bar value={topic.posts} max={maxTopic} color={segment.color} />
              </div>
              <span className="w-7 shrink-0 text-right font-mono text-[10px] tabular-nums text-ink-faint">
                {topic.posts}
              </span>
            </div>
          ))}
        </div>
      )}

      <div className="mt-2 flex flex-wrap gap-1">
        {segment.platforms.slice(0, 4).map((p) => (
          <Badge key={p.platform} tone="neutral">
            {platformLabel(p.platform)} {p.posts}
          </Badge>
        ))}
      </div>

      {segment.influential_members.length > 0 && (
        <div className="mt-2 flex flex-wrap items-center gap-1">
          <span className="text-[10px] text-ink-faint">Key nodes</span>
          {segment.influential_members.slice(0, 3).map((member) => (
            <Link key={member.anon_id} href={`/network?node=${encodeURIComponent(member.anon_id)}`}>
              <Badge tone={member.is_bridge ? 'warning' : 'neutral'}>
                {member.anon_id}
                <span className="font-mono opacity-70">
                  {member.influence_score.toFixed(0)}
                </span>
              </Badge>
            </Link>
          ))}
        </div>
      )}

      {/* A segment whose observed sentiment contradicts its defining profile is
          a finding in itself, not an inconsistency to hide. */}
      {segment.description.toLowerCase().includes('positively') &&
        segment.avg_polarity < -0.05 && (
          <p className="mt-2 rounded border border-warning/25 bg-warning/[0.06] px-2 py-1.5 text-[10px] leading-relaxed text-ink-muted">
            This segment is defined by supportive behaviour, but its observed sentiment in
            this window is {polarity(segment.avg_polarity)}. A previously supportive audience
            moving against the product is an early indicator worth tracking.
          </p>
        )}

      {segment.assignment_rationale.length > 0 && (
        <p className="mt-2 border-t border-edge-subtle pt-1.5 text-[10px] leading-relaxed text-ink-faint">
          Segment defined by: {segment.assignment_rationale.slice(0, 3).join('; ')}.
        </p>
      )}
    </div>
  );
}

export function AudienceMap({
  segments,
  loading,
  limit,
}: {
  segments: SegmentSummary[] | null;
  loading?: boolean;
  limit?: number;
}) {
  const visible = segments?.filter((s) => s.posts > 0) ?? null;

  return (
    <Panel
      title="Audience Map"
      subtitle="Segments derived from observed behaviour: reach, activity, negativity, amplification and technical register"
      actions={
        <Link
          href="/audience"
          className="inline-flex items-center gap-1 text-2xs text-ink-muted hover:text-ink"
        >
          Compare segments
          <ArrowUpRight className="h-3 w-3" aria-hidden />
        </Link>
      }
    >
      {loading && <PanelSkeleton rows={4} height="h-24" />}

      {!loading && visible && visible.length === 0 && (
        <EmptyState
          icon={Users}
          title="No segment activity in this selection"
          description="No account in the current filters posted during this window."
        />
      )}

      {!loading && visible && visible.length > 0 && (
        <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {(limit ? visible.slice(0, limit) : visible).map((segment) => (
            <SegmentCard key={segment.id} segment={segment} />
          ))}
        </div>
      )}

      <p className="mt-3 border-t border-edge-subtle pt-2 text-[10px] leading-relaxed text-ink-faint">
        Segments are behavioural clusters, not verified identities. Colour is paired with a
        label and value everywhere it appears.
      </p>
    </Panel>
  );
}

export { SENTIMENT_COLORS };
