import Link from 'next/link';
import { Activity, ArrowRight, GitBranch, Radar, Share2 } from 'lucide-react';

/**
 * Landing screen. Deliberately minimal - the analytics product is the point,
 * so this exists only to name the three differentiators and get out of the way.
 */

const VALUE_PROPS = [
  {
    icon: Radar,
    title: 'Audience Pulse',
    body: 'One statement that combines sentiment, topic momentum, audience segments and network influence into what actually changed — with the evidence attached.',
  },
  {
    icon: GitBranch,
    title: 'Narrative Journey',
    body: 'Reconstructs how a topic travelled: where it started, when sentiment turned, which accounts amplified it, and when it crossed to another platform.',
  },
  {
    icon: Share2,
    title: 'Influence Graph',
    body: 'PageRank, betweenness and community detection over the real interaction graph, surfacing the bridge accounts that connect otherwise separate communities.',
  },
];

export default function Home() {
  return (
    <main className="relative min-h-screen overflow-hidden bg-canvas">
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-trend/40 to-transparent"
        aria-hidden
      />

      <div className="mx-auto flex min-h-screen max-w-5xl flex-col justify-center px-6 py-16">
        <div className="flex items-center gap-2.5">
          <span className="grid h-8 w-8 place-items-center rounded bg-trend/15 ring-1 ring-trend/30">
            <Activity className="h-4.5 w-4.5 text-trend" aria-hidden />
          </span>
          <div>
            <h1 className="text-xl font-semibold tracking-tight text-ink">PulseGraph AI</h1>
            <p className="text-2xs text-ink-faint">Social Intelligence. Explained.</p>
          </div>
        </div>

        <p className="mt-8 max-w-2xl text-balance text-2xl font-semibold leading-snug tracking-tight text-ink">
          See what changed. Understand why. Trace how it spread.
        </p>

        <p className="mt-4 max-w-2xl text-sm leading-relaxed text-ink-muted">
          Most social dashboards tell you a number went up. PulseGraph correlates sentiment,
          topic momentum, audience segments and network influence across platforms, then
          explains the change and shows the metrics behind it.
        </p>

        <div className="mt-10 grid gap-px overflow-hidden rounded-card border border-edge bg-edge sm:grid-cols-3">
          {VALUE_PROPS.map(({ icon: Icon, title, body }) => (
            <div key={title} className="bg-canvas-raised p-5">
              <Icon className="h-4 w-4 text-trend" aria-hidden />
              <h2 className="mt-3 text-[13px] font-semibold text-ink">{title}</h2>
              <p className="mt-1.5 text-2xs leading-relaxed text-ink-faint">{body}</p>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-wrap items-center gap-3">
          <Link
            href="/dashboard"
            className="group inline-flex items-center gap-2 rounded bg-trend px-4 py-2 text-[13px] font-medium text-canvas transition-colors hover:bg-trend/90"
          >
            Open Intelligence Dashboard
            <ArrowRight
              className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5"
              aria-hidden
            />
          </Link>
          <Link
            href="/data"
            className="inline-flex items-center gap-2 rounded border border-edge-strong px-4 py-2 text-[13px] text-ink-muted transition-colors hover:bg-canvas-hover hover:text-ink"
          >
            Data sources &amp; demo dataset
          </Link>
        </div>

        <p className="mt-10 max-w-2xl text-[10px] leading-relaxed text-ink-faint">
          Runs entirely on public data. Demographics are aggregate inferences shown with
          confidence bands, never verified personal attributes. No private-message analysis.
          Accounts appear pseudonymously throughout the analytical UI.
        </p>
      </div>
    </main>
  );
}
