"""Aggregate, anonymised demographic inference.

Hard rules encoded here:

* every inferred attribute carries a confidence AND a list of the public signals
  that produced it;
* nothing is inferred from private data - only public bio text, public profile
  metadata, self-declared location strings, language of posting and observable
  posting behaviour;
* an attribute with no supporting signal resolves to "unknown" at low
  confidence rather than being guessed.

The output is intended for aggregation. Individual rows exist so aggregates are
traceable, never so a person can be profiled.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime

MODEL_NAME = "pulsegraph-demographic-rules"
MODEL_VERSION = "1.1.0"

AGE_BRACKETS = ["13-17", "18-24", "25-34", "35-44", "45-54", "55+"]

# Public bio phrases that carry a *weak* age signal. Weights are deliberately
# modest: a bio is an assertion, not a birth certificate.
AGE_SIGNALS: list[tuple[re.Pattern[str], str, float, str]] = [
    (re.compile(r"\b(1[3-7])\b\s*(y/?o|years old)?", re.I), "13-17", 0.45, "self-stated age in bio"),
    (re.compile(r"\b(1[89]|2[0-4])\b(?!\s*(gb|mp|hz|%))", re.I), "18-24", 0.4, "numeric age token in bio"),
    (re.compile(r"\b(student|undergrad|college|university|freshman|campus)\b", re.I), "18-24", 0.42, "education reference in bio"),
    (re.compile(r"\b(intern|first job|graduating|final year)\b", re.I), "18-24", 0.38, "early-career reference"),
    (re.compile(r"\b(cs|engineering) (undergrad|student)\b", re.I), "18-24", 0.5, "student self-description"),
    (re.compile(r"\b(dev|developer|engineer|designer|analyst|founder)\b", re.I), "25-34", 0.3, "professional role in bio"),
    (re.compile(r"\b(parent|mum|mom|dad|father|mother|kids|family)\b", re.I), "35-44", 0.42, "family reference in bio"),
    (re.compile(r"\b(small business|business owner|manager|director|consultant)\b", re.I), "35-44", 0.36, "senior role reference"),
    (re.compile(r"\b(since 20[0-1][0-9]|for (six|seven|eight|ten|twelve) years|long-time|veteran)\b", re.I),
     "35-44", 0.34, "long tenure reference"),
    (re.compile(r"\b(retired|grandparent|pensioner)\b", re.I), "55+", 0.5, "life-stage reference"),
]

INTEREST_SIGNALS: list[tuple[re.Pattern[str], str, float]] = [
    (re.compile(r"\b(rom|firmware|kernel|benchmark|flash|root|build|spec sheet)\b", re.I),
     "Technology / power user", 0.5),
    (re.compile(r"\b(dev|developer|engineer|programming|code|codes|cs\b|software)\b", re.I),
     "Software engineering", 0.48),
    (re.compile(r"\b(review|reviewer|teardown|analyst|hardware analyst)\b", re.I),
     "Device reviews / media", 0.52),
    (re.compile(r"\b(news|desk|reporting|coverage|journalis)\b", re.I),
     "Media / journalism", 0.5),
    (re.compile(r"\b(business owner|small business|entrepreneur|founder)\b", re.I),
     "Business / entrepreneurship", 0.46),
    (re.compile(r"\b(support|care team|helpdesk|customer)\b", re.I),
     "Customer service", 0.44),
    (re.compile(r"\b(photo|photography|camera|shot on|lens)\b", re.I),
     "Photography", 0.44),
    (re.compile(r"\b(moderator|community)\b", re.I), "Community management", 0.42),
    (re.compile(r"\b(curat|trending|roundup|share)\b", re.I), "Content curation", 0.4),
]

REGION_MAP: dict[str, str] = {
    "IN": "South Asia", "UK": "Western Europe", "DE": "Western Europe",
    "CA": "North America", "US": "North America", "AE": "Middle East",
    "BR": "South America", "ID": "Southeast Asia",
}
CITY_REGION: dict[str, str] = {
    "bengaluru": "South Asia", "mumbai": "South Asia", "delhi": "South Asia",
    "pune": "South Asia", "hyderabad": "South Asia", "chennai": "South Asia",
    "london": "Western Europe", "manchester": "Western Europe", "berlin": "Western Europe",
    "toronto": "North America", "austin": "North America", "seattle": "North America",
    "singapore": "Southeast Asia", "jakarta": "Southeast Asia",
    "dubai": "Middle East", "são paulo": "South America", "sao paulo": "South America",
}


@dataclass(slots=True)
class InferredProfile:
    author_id: str
    age_bracket: str = "unknown"
    age_confidence: float = 0.0
    region: str = "Unknown"
    region_confidence: float = 0.0
    language: str = "en"
    professional_interest: str = "General consumer"
    interest_confidence: float = 0.0
    engagement_behaviour: str = "observer"
    evidence: list[dict] = field(default_factory=list)
    model: str = MODEL_NAME
    model_version: str = MODEL_VERSION


def _behaviour(post_count: int, avg_engagement: float, reply_ratio: float,
               share_ratio: float) -> tuple[str, str]:
    """Classify observable posting behaviour (not identity)."""
    if share_ratio > 0.32 and post_count >= 3:
        return "amplifier", "high share/repost ratio"
    if reply_ratio > 0.55 and post_count >= 3:
        return "conversationalist", "majority of activity is replies"
    if post_count >= 12:
        return "high_frequency", f"{post_count} posts in window"
    if avg_engagement > 400:
        return "high_reach", "posts attract above-average engagement"
    if post_count <= 2:
        return "observer", "low posting volume"
    return "regular", "steady posting volume"


def infer_profile(
    author_id: str,
    bio: str,
    followers: int,
    account_created_at: datetime | None,
    location_raw: str,
    languages: Counter[str],
    post_count: int,
    avg_engagement: float,
    reply_ratio: float,
    share_ratio: float,
    topic_affinity: list[str],
    now: datetime | None = None,
) -> InferredProfile:
    profile = InferredProfile(author_id=author_id)
    evidence: list[dict] = []

    # --- age bracket -------------------------------------------------------
    candidates: Counter[str] = Counter()
    best_conf: dict[str, float] = {}
    for pattern, bracket, weight, label in AGE_SIGNALS:
        if bio and pattern.search(bio):
            candidates[bracket] += weight
            best_conf[bracket] = max(best_conf.get(bracket, 0.0), weight)
            evidence.append({"attribute": "age_bracket", "signal": label,
                             "basis": "public bio text", "weight": weight})

    # Account age is a genuine but weak behavioural signal.
    if account_created_at and now:
        years = (now - account_created_at).days / 365.25
        if years >= 8:
            candidates["35-44"] += 0.22
            evidence.append({"attribute": "age_bracket", "signal": f"account active ~{years:.0f} years",
                             "basis": "public profile metadata", "weight": 0.22})
        elif years <= 1.5:
            candidates["18-24"] += 0.18
            evidence.append({"attribute": "age_bracket", "signal": "recently created account",
                             "basis": "public profile metadata", "weight": 0.18})

    if "Technology / power user" in topic_affinity or "battery-drain" in topic_affinity:
        pass  # topic affinity alone is not an age signal; kept explicit on purpose

    if candidates:
        bracket, total = candidates.most_common(1)[0]
        profile.age_bracket = bracket
        # Confidence never exceeds Medium for an inferred age from public text.
        profile.age_confidence = round(min(0.42 + total * 0.42, 0.78), 3)
    else:
        profile.age_bracket = "unknown"
        profile.age_confidence = 0.28
        evidence.append({"attribute": "age_bracket", "signal": "no public age indicator found",
                         "basis": "absence of evidence", "weight": 0.0})

    # --- region ------------------------------------------------------------
    if location_raw:
        lowered = location_raw.lower()
        region = None
        for city, mapped in CITY_REGION.items():
            if city in lowered:
                region = mapped
                break
        if region is None:
            suffix = location_raw.strip().split(",")[-1].strip().upper()
            region = REGION_MAP.get(suffix)
        if region:
            profile.region = region
            profile.region_confidence = 0.74
            evidence.append({"attribute": "region", "signal": f"public location field: {location_raw}",
                             "basis": "self-declared public profile location", "weight": 0.74})
    if profile.region == "Unknown":
        # Language of posting is a weak locale hint only.
        if languages.get("hi-en"):
            profile.region = "South Asia"
            profile.region_confidence = 0.46
            evidence.append({"attribute": "region", "signal": "code-switched Hindi/English posting",
                             "basis": "language of public posts", "weight": 0.46})
        else:
            profile.region_confidence = 0.2
            evidence.append({"attribute": "region", "signal": "no public location signal",
                             "basis": "absence of evidence", "weight": 0.0})

    # --- language ----------------------------------------------------------
    if languages:
        lang, count = languages.most_common(1)[0]
        profile.language = lang
        evidence.append({
            "attribute": "language",
            "signal": f"{count}/{sum(languages.values())} posts detected as {lang}",
            "basis": "language of public posts", "weight": 0.8,
        })

    # --- professional interest --------------------------------------------
    for pattern, interest, weight in INTEREST_SIGNALS:
        if bio and pattern.search(bio):
            profile.professional_interest = interest
            profile.interest_confidence = round(weight + (0.1 if followers > 10000 else 0.0), 3)
            evidence.append({"attribute": "professional_interest", "signal": interest,
                             "basis": "public bio text", "weight": weight})
            break
    else:
        if topic_affinity:
            profile.professional_interest = "General consumer"
            profile.interest_confidence = 0.32
            evidence.append({
                "attribute": "professional_interest",
                "signal": f"topic participation: {', '.join(topic_affinity[:2])}",
                "basis": "observed topic interaction", "weight": 0.32,
            })

    # --- behaviour ---------------------------------------------------------
    behaviour, reason = _behaviour(post_count, avg_engagement, reply_ratio, share_ratio)
    profile.engagement_behaviour = behaviour
    evidence.append({"attribute": "engagement_behaviour", "signal": reason,
                     "basis": "observed public posting behaviour", "weight": 0.7})

    profile.evidence = evidence
    return profile


def confidence_band(value: float) -> str:
    if value >= 0.80:
        return "High"
    if value >= 0.60:
        return "Medium"
    return "Low"


def aggregate(profiles: list[InferredProfile], attribute: str) -> list[dict]:
    """Aggregate an attribute into shares with a pooled confidence band.

    Aggregation - not individual profiling - is the intended output of this
    module, so this is the function the API layer uses.
    """
    if not profiles:
        return []
    counts: Counter[str] = Counter()
    conf_sum: dict[str, float] = {}
    for p in profiles:
        value = getattr(p, attribute, "unknown") or "unknown"
        counts[value] += 1
        key = f"{attribute}_confidence"
        conf_sum[value] = conf_sum.get(value, 0.0) + getattr(p, key, 0.5)

    total = sum(counts.values())
    rows = []
    for value, count in counts.most_common():
        mean_conf = conf_sum[value] / count
        rows.append({
            "value": value,
            "count": count,
            "percentage": round(count * 100.0 / total, 1),
            "confidence": round(mean_conf, 3),
            "confidence_band": confidence_band(mean_conf),
        })
    return rows
