"""Topic detection and keyword extraction.

Two complementary mechanisms, both deterministic:

* **Assignment** - a weighted keyword/phrase matcher. Terms are inverse-topic-
  frequency weighted, so a word shared by many topics (e.g. "update") carries
  less evidence than a distinctive one (e.g. "screen on time"). Thread context
  contributes too: a short reply inherits signal from what it replies to, which
  is how a human reads a thread.
* **Extraction** - TF-IDF over the corpus surfaces the terms that actually
  distinguish a topic right now, which is what the UI shows as viral keywords.

No topic label is ever taken from the generator; everything here reads text.
"""

from __future__ import annotations

import math
import re
from collections import Counter, defaultdict

TOPIC_DEFINITIONS: list[dict] = [
    {
        "id": "battery-drain",
        "label": "NovaPhone X battery drain",
        "description": "Reports of accelerated battery drain following the v14.2 firmware update.",
        "keywords": [
            "battery", "drain", "draining", "drains", "screen on time", "sot", "power bank",
            "standby", "charging twice", "charge", "charged", "recharge", "percent",
            "drops from", "dies", "dead by", "overheat", "heating", "warm in my pocket",
            "battery health", "idle drain", "discharge", "wakelock", "battery graph",
            "lasts", "full day", "power management", "battery life",
        ],
        "hashtags": ["novaphonex", "batterydrain", "nova142"],
    },
    {
        "id": "update-142",
        "label": "v14.2 firmware update",
        "description": "General discussion of the NovaPhone v14.2 software release.",
        "keywords": [
            "update", "v14.2", "14.2", "firmware", "patch", "rollout", "ota", "changelog",
            "build", "rollback", "roll back", "security patch", "beta window", "installed",
            "point release", "kernel", "vendor blobs", "staged",
        ],
        "hashtags": ["nova142", "novaupdate"],
    },
    {
        "id": "camera-quality",
        "label": "Camera performance",
        "description": "Photography and low-light camera discussion.",
        "keywords": [
            "camera", "photo", "photos", "low light", "lowlight", "night mode", "portrait",
            "lens", "shot on", "zoom", "sensor", "iso", "colour science", "color science",
            "skin tones", "stabilisation", "stabilization", "4k", "edge detection",
        ],
        "hashtags": ["novacamera", "shotonnova"],
    },
    {
        "id": "nova-support",
        "label": "Customer support experience",
        "description": "Service centre and support-channel experiences.",
        "keywords": [
            "support", "service centre", "service center", "warranty", "ticket", "helpline",
            "rma", "replacement", "nova care", "agent", "escalation", "escalated",
            "engineer assigned", "raised a ticket", "ticket id", "support hours",
            "called the helpline", "claim", "customer care",
        ],
        "hashtags": ["novasupport", "novacare"],
    },
    {
        "id": "price-drop",
        "label": "Price cut and offers",
        "description": "Pricing, discounts and exchange offers.",
        "keywords": [
            "price", "discount", "offer", "deal", "sale", "cashback", "exchange offer",
            "emi", "cheaper", "price cut", "price tracker", "festive sale", "full price",
            "dropped by", "worth it at",
        ],
        "hashtags": ["novadeal", "novaoffer"],
    },
    {
        "id": "nova-launch",
        "label": "NovaPhone X launch buzz",
        "description": "Residual launch-week excitement, unboxings and first impressions.",
        "keywords": [
            "unboxed", "unboxing", "preorder", "pre-order", "first impressions", "delivery",
            "arrived", "finally got", "day one", "launch", "build quality", "in person",
            "setting it up", "switched from", "announcement",
        ],
        "hashtags": ["novaphonex", "novalaunch"],
    },
    {
        "id": "recall-rumor",
        "label": "Recall rumour",
        "description": "Unverified claims of a battery recall, plus debunking replies.",
        "keywords": [
            "recall", "recalled", "stop-sale", "stop selling", "banned", "lawsuit",
            "class action", "safety notice", "regulator", "regulators", "pulled from shelves",
            "safety issue", "safety hazard", "forwarded", "unverified", "rumour", "rumor",
            "no press release", "not a source",
        ],
        "hashtags": ["novarecall"],
    },
    {
        "id": "nova-vs-orbit",
        "label": "NovaPhone X vs Orbit 12",
        "description": "Head-to-head comparison with the competing Orbit 12.",
        "keywords": [
            "orbit 12", "orbit", "versus", " vs ", "switching to", "switch to", "compare",
            "comparison", "better than", "side by side", "moved from nova", "trade",
            "would not recommend", "both phones",
        ],
        "hashtags": ["novavsorbit", "orbit12"],
    },
]

TOPIC_BY_ID: dict[str, dict] = {t["id"]: t for t in TOPIC_DEFINITIONS}

STOPWORDS = {
    "the", "and", "for", "that", "this", "with", "have", "has", "had", "not", "you", "your",
    "but", "are", "was", "were", "from", "they", "their", "them", "there", "here", "what",
    "when", "which", "who", "will", "would", "could", "should", "been", "being", "just",
    "like", "about", "after", "before", "still", "some", "more", "most", "very", "only",
    "than", "then", "into", "over", "also", "any", "all", "can", "cannot", "did", "does",
    "doing", "how", "its", "it's", "i've", "i'm", "im", "ive", "get", "got", "one", "two",
    "now", "out", "off", "own", "same", "too", "use", "using", "used", "way", "well",
    "even", "back", "day", "days", "hours", "hour", "post", "posts", "thread", "reply",
    "yaar", "bhai", "hai", "kar", "aur", "mera", "meri", "ke", "ka", "ki", "ko", "se",
}

WORD_RE = re.compile(r"[a-z0-9][a-z0-9'\-]{2,}")


def _term_weights() -> dict[str, float]:
    """Inverse-topic-frequency weight per keyword.

    A term appearing under many topics is weak evidence; a distinctive phrase is
    strong. Multi-word phrases also earn a length bonus.
    """
    occurrences: Counter[str] = Counter()
    for topic in TOPIC_DEFINITIONS:
        for kw in set(topic["keywords"]):
            occurrences[kw.lower()] += 1

    total = len(TOPIC_DEFINITIONS)
    weights: dict[str, float] = {}
    for term, count in occurrences.items():
        idf = math.log((total + 1) / (count + 0.5)) + 0.4
        phrase_bonus = 1.0 + 0.35 * (term.count(" "))
        weights[term] = round(max(idf, 0.15) * phrase_bonus, 4)
    return weights


TERM_WEIGHTS = _term_weights()


def _stem(token: str) -> str:
    for suffix in ("ings", "ing", "ies", "ed", "es", "s"):
        if len(token) > len(suffix) + 3 and token.endswith(suffix):
            return token[: -len(suffix)]
    return token


def _contains_term(haystack: str, tokens: set[str], stems: set[str], term: str) -> bool:
    if " " in term:
        return term in haystack
    return term in tokens or _stem(term) in stems


def classify(
    text: str,
    hashtags: list[str] | None = None,
    parent_topic: str | None = None,
    min_relevance: float = 0.9,
) -> list[tuple[str, float]]:
    """Score a post against every topic. Returns [(topic_id, relevance)] sorted
    by relevance, strongest first. An empty list means 'unclassified'."""
    haystack = f" {text.lower()} "
    tokens = set(WORD_RE.findall(haystack))
    stems = {_stem(t) for t in tokens}
    tags = {h.lower().lstrip("#") for h in (hashtags or [])}

    scores: dict[str, float] = defaultdict(float)
    for topic in TOPIC_DEFINITIONS:
        tid = topic["id"]
        for kw in topic["keywords"]:
            term = kw.lower()
            if _contains_term(haystack, tokens, stems, term):
                scores[tid] += TERM_WEIGHTS.get(term, 0.5)
        for tag in topic["hashtags"]:
            if tag.lower() in tags:
                # A hashtag is a deliberate authorial signal, so it counts, but
                # generic campaign tags are shared across topics.
                scores[tid] += 1.4 if tag not in {"novaphonex"} else 0.5

    # Thread context: a short reply borrows evidence from its parent.
    if parent_topic:
        weight = 1.6 if len(tokens) < 14 else 0.7
        scores[parent_topic] += weight

    ranked = [(tid, round(score, 3)) for tid, score in scores.items() if score >= min_relevance]
    ranked.sort(key=lambda kv: kv[1], reverse=True)
    return ranked


def extract_keywords(documents: list[str], top_n: int = 8) -> list[tuple[str, float]]:
    """TF-IDF keyword extraction over a document set.

    Called per topic with that topic's posts as `documents`, using the whole
    corpus as the background - the caller supplies document frequencies via
    `corpus_df` for that. This simple form treats the supplied set as the corpus
    and is used for small, focused collections.
    """
    if not documents:
        return []

    tokenised = [
        [t for t in WORD_RE.findall(doc.lower()) if t not in STOPWORDS and not t.isdigit()]
        for doc in documents
    ]
    df: Counter[str] = Counter()
    for tokens in tokenised:
        df.update(set(tokens))

    tf: Counter[str] = Counter()
    for tokens in tokenised:
        tf.update(tokens)

    n_docs = len(tokenised)
    scores: dict[str, float] = {}
    for term, freq in tf.items():
        if freq < 2 or len(term) < 4:
            continue
        idf = math.log((n_docs + 1) / (df[term] + 1)) + 1.0
        scores[term] = round(freq * idf, 3)

    top = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)[:top_n]
    return top


def distinctive_keywords(
    topic_documents: list[str], corpus_df: Counter[str], corpus_size: int, top_n: int = 8
) -> list[dict]:
    """Terms that distinguish this topic against the whole corpus."""
    if not topic_documents:
        return []

    tf: Counter[str] = Counter()
    local_df: Counter[str] = Counter()
    for doc in topic_documents:
        tokens = [t for t in WORD_RE.findall(doc.lower()) if t not in STOPWORDS and not t.isdigit()]
        tf.update(tokens)
        local_df.update(set(tokens))

    results: list[dict] = []
    for term, freq in tf.items():
        if freq < 3 or len(term) < 4:
            continue
        idf = math.log((corpus_size + 1) / (corpus_df.get(term, 0) + 1)) + 1.0
        lift = (local_df[term] / max(len(topic_documents), 1)) / (
            max(corpus_df.get(term, 1), 1) / max(corpus_size, 1)
        )
        results.append(
            {
                "term": term,
                "score": round(freq * idf, 2),
                "mentions": freq,
                "lift": round(lift, 2),
            }
        )

    results.sort(key=lambda r: r["score"], reverse=True)
    return results[:top_n]


def corpus_document_frequencies(documents: list[str]) -> tuple[Counter[str], int]:
    df: Counter[str] = Counter()
    for doc in documents:
        tokens = {t for t in WORD_RE.findall(doc.lower()) if t not in STOPWORDS and not t.isdigit()}
        df.update(tokens)
    return df, len(documents)
