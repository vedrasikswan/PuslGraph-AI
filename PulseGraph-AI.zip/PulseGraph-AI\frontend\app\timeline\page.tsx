import { Suspense } from 'react';

import { AppShell } from '@/components/layout/AppShell';
import { FilterProvider } from '@/features/filters/FilterContext';

import { TimelineView } from './TimelineView';

export const metadata = { title: 'Timeline — PulseGraph AI' };

export default function Page() {
  return (
    <Suspense fallback={null}>
      <FilterProvider>
        <AppShell>
          <TimelineView />
        </AppShell>
      </FilterProvider>
    </Suspense>
  );
}
