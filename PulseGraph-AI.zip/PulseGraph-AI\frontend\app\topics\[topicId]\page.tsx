import { Suspense } from 'react';

import { AppShell } from '@/components/layout/AppShell';
import { FilterProvider } from '@/features/filters/FilterContext';

import { TopicView } from './TopicView';

export const metadata = { title: 'Topic deep dive — PulseGraph AI' };

export default async function TopicPage({
  params,
}: {
  params: Promise<{ topicId: string }>;
}) {
  const { topicId } = await params;
  return (
    <Suspense fallback={null}>
      <FilterProvider>
        <AppShell>
          <TopicView topicId={decodeURIComponent(topicId)} />
        </AppShell>
      </FilterProvider>
    </Suspense>
  );
}
