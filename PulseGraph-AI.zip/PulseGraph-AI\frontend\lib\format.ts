/** Presentation helpers. Formatting lives here so numbers read identically everywhere. */

import type { ConfidenceBand, Sentiment, Severity, TrendClass } from '@/types/api';

export function compactNumber(value: number): string {
  if (!Number.isFinite(value)) return '—';
  const abs = Math.abs(value);
  if (abs >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`;
  if (abs >= 10_000) return `${(value / 1_000).toFixed(0)}k`;
  if (abs >= 1_000) return `${(value / 1_000).toFixed(1)}k`;
  return value.toLocaleString(undefined, { maximumFractionDigits: 1 });
}

export function exactNumber(value: number): string {
  return Number.isFinite(value) ? value.toLocaleString() : '—';
}

export function percent(value: number, digits = 1): string {
  return `${value.toFixed(digits)}%`;
}

/** Growth values are unbounded; very large ones are shown compactly. */
export function growth(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return '—';
  const sign = value > 0 ? '+' : '';
  if (Math.abs(value) >= 1000) return `${sign}${compactNumber(value)}%`;
  return `${sign}${value.toFixed(value % 1 === 0 ? 0 : 1)}%`;
}

export function polarity(value: number): string {
  const sign = value > 0 ? '+' : '';
  return `${sign}${value.toFixed(2)}`;
}

export function timeOfDay(iso: string): string {
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export function dateTime(iso: string): string {
  return new Date(iso).toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function relativeTime(iso: string): string {
  const then = new Date(iso).getTime();
  const diffMinutes = Math.round((Date.now() - then) / 60000);
  if (diffMinutes < 1) return 'just now';
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  const hours = Math.round(diffMinutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}

export function duration(minutes: number): string {
  if (minutes < 60) return `${Math.round(minutes)} min`;
  const hours = minutes / 60;
  if (hours < 24) return `${hours.toFixed(1)} h`;
  return `${(hours / 24).toFixed(1)} d`;
}

export function tickLabel(iso: string, granularity: string): string {
  const date = new Date(iso);
  if (granularity === 'weekly' || granularity === 'daily') {
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  }
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export const PLATFORM_LABELS: Record<string, string> = {
  x: 'X',
  telegram: 'Telegram',
  instagram: 'Instagram',
  facebook: 'Facebook',
  reddit: 'Reddit',
  youtube: 'YouTube',
  demo: 'Demo dataset',
  multi: 'Multi-platform',
};

export function platformLabel(id: string): string {
  return PLATFORM_LABELS[id] ?? id;
}

export const SENTIMENT_LABELS: Record<Sentiment, string> = {
  positive: 'Positive',
  negative: 'Negative',
  neutral: 'Neutral',
};

export const SEVERITY_LABELS: Record<Severity, string> = {
  critical: 'Critical',
  high: 'High',
  medium: 'Medium',
  low: 'Low',
  info: 'Info',
};

export const TREND_LABELS: Record<TrendClass, string> = {
  stable: 'Stable',
  emerging: 'Emerging',
  growing: 'Growing',
  accelerating: 'Accelerating',
  viral: 'Viral',
};

export function confidenceLabel(band: ConfidenceBand, value: number): string {
  return `${band} (${value.toFixed(2)})`;
}

export function titleCase(value: string): string {
  return value
    .replace(/[_-]/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

export function metricLabel(metric: string): string {
  return titleCase(metric);
}

/** Format an evidence value without inventing precision. */
export function evidenceValue(value: string | number): string {
  if (typeof value === 'number') {
    if (Number.isInteger(value)) return value.toLocaleString();
    if (Math.abs(value) < 1) return value.toFixed(3);
    return value.toLocaleString(undefined, { maximumFractionDigits: 2 });
  }
  if (/^\d{4}-\d{2}-\d{2}T/.test(value)) return dateTime(value);
  return value;
}
