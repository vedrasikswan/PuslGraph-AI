'use client';

/**
 * Trend Radar.
 *
 * Each row shows the trend score, the velocity that produced it, sentiment,
 * platform spread and the momentum forecast. The score decomposition is
 * inspectable so a reader can see the arithmetic instead of trusting a number.
 */

import Link from 'next/link';
import { ArrowDown, ArrowRight, ArrowUp, Minus } from 'lucide-react';

import { WhyPanel } from '@/components/ui/Evidence';
import {
  Badge,
  Bar,
  EmptyState,
  Panel,
  PanelSkeleton,
  TrendBadge,
  cx,
} from '@/components/ui/primitives';
import { TREND_STYLES, polarityColor } from '@/lib/colors';
import { compactNumber, growth, platformLabel, polarity, titleCase } from '@/lib/format';
import type { Trend } from '@/types/api';

import { useFilters } from '../filters/FilterContext';

function DirectionIcon({ direction }: { direction: Trend['velocity']['direction'] }) {
  const Icon = direction === 'up' ? ArrowUp : direction === 'down' ? ArrowDown : Minus;
  const tone =
    direction === 'up' ? 'text-negative' : direction === 'down' ? 'text-positive' : 'text-ink-faint';
  return <Icon className={cx('h-3 w-3', tone)} aria-hidden />;
}

function componentEvidence(trend: Trend) {
  const values = trend.components.values ?? {};
  const weights = trend.components.weights ?? {};
  return Object.entries(values).map(([metric, value]) => ({
    metric,
    value,
    change: weights[metric] !== undefined ? `weight ${weights[metric]}` : undefined,
    period: 'normalised 0–1',
  }));
}

export function TrendRow({ trend, compact = false }: { trend: Trend; compact?: boolean }) {
  const { velocity, momentum } = trend;
  const style = TREND_STYLES[trend.classification];

  return (
    <div className="border-b border-edge-subtle px-4 py-3 last:border-0 hover:bg-canvas-hover/40">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <Link
            href={`/topics/${trend.topic_id}`}
            className="text-[13px] font-medium text-ink hover:underline"
          >
            {trend.label}
          </Link>
          <div className="mt-1 flex flex-wrap items-center gap-1.5">
            <TrendBadge classification={trend.classification} score={trend.trend_score} />
            <span className="inline-flex items-center gap-1 text-2xs text-ink-muted">
              <DirectionIcon direction={velocity.direction} />
              <span className="font-mono tabular-nums">{growth(velocity.growth_percentage)}</span>
              <span className="text-ink-faint">vs previous period</span>
            </span>
          </div>
        </div>

        <div className="shrink-0 text-right">
          <p className="font-mono text-lg font-semibold leading-none tabular-nums text-ink">
            {trend.trend_score.toFixed(0)}
          </p>
          <p className="mt-0.5 text-[10px] text-ink-faint">/ 100</p>
        </div>
      </div>

      <Bar
        value={trend.trend_score}
        max={100}
        color={style.bar}
        className="mt-2.5"
      />

      <dl className="mt-2.5 grid grid-cols-2 gap-x-4 gap-y-1 sm:grid-cols-4">
        <div>
          <dt className="text-[10px] text-ink-faint">Mentions</dt>
          <dd className="font-mono text-2xs tabular-nums text-ink-muted">
            {compactNumber(velocity.current_mentions)}
            <span className="text-ink-faint"> ← {compactNumber(velocity.previous_mentions)}</span>
          </dd>
        </div>
        <div>
          <dt className="text-[10px] text-ink-faint">Engagement / h</dt>
          <dd className="font-mono text-2xs tabular-nums text-ink-muted">
            {compactNumber(velocity.engagement_velocity)}
          </dd>
        </div>
        <div>
          <dt className="text-[10px] text-ink-faint">Sentiment</dt>
          <dd className="font-mono text-2xs tabular-nums" style={{ color: polarityColor(trend.sentiment.avg_polarity) }}>
            {polarity(trend.sentiment.avg_polarity)}
            <span className="text-ink-faint">
              {' '}
              ({trend.sentiment.shift >= 0 ? '+' : ''}
              {trend.sentiment.shift.toFixed(2)})
            </span>
          </dd>
        </div>
        <div>
          <dt className="text-[10px] text-ink-faint">Platforms</dt>
          <dd className="text-2xs text-ink-muted">{trend.platform_count} of 6</dd>
        </div>
      </dl>

      {!compact && (
        <>
          <div className="mt-2 flex flex-wrap items-center gap-1">
            {trend.platforms.map((platform) => (
              <Badge key={platform} tone="neutral">
                {platformLabel(platform)}
              </Badge>
            ))}
            <Badge
              tone={
                momentum.label.includes('growing')
                  ? 'negative'
                  : momentum.label.includes('decline')
                    ? 'positive'
                    : 'neutral'
              }
              title="Momentum forecast — an estimate from rolling averages and recent slope, not a guarantee."
            >
              Momentum: {titleCase(momentum.label)} · {momentum.confidence_band}
            </Badge>
          </div>

          <WhyPanel
            label="How was this scored?"
            evidence={componentEvidence(trend)}
            confidence={momentum.confidence}
            confidenceBand={momentum.confidence_band}
            method={trend.components.formula}
          />
        </>
      )}
    </div>
  );
}

export function TrendRadar({
  trends,
  loading,
  limit = 6,
}: {
  trends: Trend[] | null;
  loading?: boolean;
  limit?: number;
}) {
  const { filters, toggle } = useFilters();

  return (
    <Panel
      title="Trend Radar"
      subtitle="Composite score from volume growth, engagement velocity, author growth, cross-platform spread, influencer activity and persistence"
      dense
      actions={
        filters.topics.length > 0 ? (
          <button
            type="button"
            onClick={() => toggle('topics', filters.topics[0])}
            className="text-2xs text-ink-faint underline decoration-dotted hover:text-ink"
          >
            Clear topic filter
          </button>
        ) : null
      }
    >
      {loading && (
        <div className="p-4">
          <PanelSkeleton rows={6} height="h-12" />
        </div>
      )}

      {!loading && trends && trends.length === 0 && (
        <EmptyState
          title="No topics in this selection"
          description="No post in the current filters was classified into a tracked topic."
        />
      )}

      {!loading &&
        trends &&
        trends.slice(0, limit).map((trend) => <TrendRow key={trend.topic_id} trend={trend} />)}

      {!loading && trends && trends.length > limit && (
        <div className="border-t border-edge-subtle px-4 py-2 text-center">
          <Link
            href="/timeline"
            className="inline-flex items-center gap-1 text-2xs text-ink-muted hover:text-ink"
          >
            {trends.length - limit} more topics
            <ArrowRight className="h-3 w-3" aria-hidden />
          </Link>
        </div>
      )}
    </Panel>
  );
}
