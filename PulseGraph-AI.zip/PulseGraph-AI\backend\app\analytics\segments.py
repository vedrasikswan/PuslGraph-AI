"""Dynamic audience segmentation.

Segments are derived from an observed feature vector per author - not from any
label the data generator held. Each author is scored against a set of segment
prototypes across five behavioural dimensions, and the best-scoring prototype
wins. That makes segment membership explainable ("assigned because reach is
high and share ratio is high") and stable across runs.

This is deliberately a transparent prototype-nearest-neighbour scheme rather
than an opaque clustering: an analyst has to be able to defend why an account
sits in a segment.
"""

from __future__ import annotations

from dataclasses import dataclass, field

FEATURES = ("reach", "activity", "negativity", "amplification", "technicality")


@dataclass(slots=True)
class AuthorFeatures:
    author_id: str
    reach: float          # 0..1  normalised follower + engagement reach
    activity: float       # 0..1  posting volume
    negativity: float     # 0..1  share of that author's posts read as negative
    amplification: float  # 0..1  share/mention driven redistribution
    technicality: float   # 0..1  density of technical vocabulary
    influence: float = 0.0
    dominant_topic: str = ""
    post_count: int = 0
    avg_engagement: float = 0.0

    def vector(self) -> tuple[float, ...]:
        return (self.reach, self.activity, self.negativity,
                self.amplification, self.technicality)


@dataclass(slots=True)
class SegmentPrototype:
    id: str
    name: str
    description: str
    color: str
    centroid: tuple[float, float, float, float, float]
    weights: tuple[float, float, float, float, float] = (1.0, 1.0, 1.0, 1.0, 1.0)
    rationale: list[str] = field(default_factory=list)


# Ordered by specificity: distinctive prototypes first so that generic ones do
# not absorb accounts that clearly belong elsewhere.
PROTOTYPES: list[SegmentPrototype] = [
    SegmentPrototype(
        id="information-amplifiers",
        name="Information Amplifiers",
        description=(
            "High-reach accounts that redistribute other people's content. They rarely "
            "originate a narrative but decide how far it travels."
        ),
        color="#a855f7",
        centroid=(0.82, 0.62, 0.45, 0.88, 0.35),
        weights=(1.3, 0.9, 0.6, 1.9, 0.7),
        rationale=["high reach", "high share/mention ratio", "low origination"],
    ),
    SegmentPrototype(
        id="young-tech-enthusiasts",
        name="Young Tech Enthusiasts",
        description=(
            "Technically fluent, highly active accounts. First to notice a regression "
            "and the source of most reproducible detail."
        ),
        color="#38bdf8",
        centroid=(0.38, 0.82, 0.55, 0.35, 0.86),
        weights=(0.7, 1.4, 0.7, 0.7, 2.0),
        rationale=["high technical vocabulary density", "high posting frequency"],
    ),
    SegmentPrototype(
        id="concerned-customers",
        name="Concerned Customers",
        description=(
            "Ordinary owners posting about impact on daily use. Low reach individually, "
            "decisive in aggregate."
        ),
        color="#f97316",
        centroid=(0.18, 0.42, 0.85, 0.22, 0.22),
        weights=(0.9, 0.8, 1.9, 0.7, 1.0),
        rationale=["predominantly negative sentiment", "low individual reach"],
    ),
    SegmentPrototype(
        id="engaged-supporters",
        name="Highly Engaged Supporters",
        description=(
            "Active accounts posting positively or defending the product. Useful as an "
            "early indicator when their sentiment starts to move."
        ),
        color="#22c55e",
        centroid=(0.42, 0.72, 0.12, 0.38, 0.45),
        weights=(0.8, 1.2, 1.8, 0.7, 0.8),
        rationale=["consistently positive sentiment", "above-average activity"],
    ),
    SegmentPrototype(
        id="technical-reviewers",
        name="Technical Reviewers",
        description=(
            "Low-volume, very high-reach accounts publishing measured analysis. Their "
            "participation typically marks an inflection point."
        ),
        color="#eab308",
        centroid=(0.95, 0.3, 0.5, 0.45, 0.9),
        weights=(2.0, 1.1, 0.6, 0.7, 1.5),
        rationale=["very high reach", "high technical density", "low posting volume"],
    ),
    SegmentPrototype(
        id="occasional-observers",
        name="Occasional Observers",
        description=(
            "Low-reach, low-frequency participants. Their entry into a conversation is a "
            "signal that a topic has left its original community."
        ),
        color="#94a3b8",
        centroid=(0.1, 0.12, 0.45, 0.15, 0.15),
        weights=(1.0, 1.5, 0.5, 0.8, 0.8),
        rationale=["low posting volume", "low reach"],
    ),
]

PROTOTYPE_BY_ID = {p.id: p for p in PROTOTYPES}

TECHNICAL_TERMS = {
    "wakelock", "kernel", "firmware", "build", "logs", "log", "benchmark", "idle", "drain",
    "scheduler", "aod", "workload", "reproducible", "traces", "trace", "calibration",
    "discharge", "cycle", "diffed", "package", "module", "vendor", "blobs", "iso",
    "stabilisation", "stabilization", "regression", "brightness", "airplane", "throughput",
    "percent", "graph", "screenshot", "build number", "ota", "rollback", "units", "unit",
}


def technical_density(texts: list[str]) -> float:
    if not texts:
        return 0.0
    hits = 0
    words = 0
    for text in texts:
        tokens = text.lower().split()
        words += len(tokens)
        hits += sum(1 for t in tokens if t.strip(".,!?%") in TECHNICAL_TERMS)
    if words == 0:
        return 0.0
    return min(1.0, (hits / words) * 22.0)


def _distance(features: AuthorFeatures, prototype: SegmentPrototype) -> float:
    total = 0.0
    weight_sum = 0.0
    for value, centre, weight in zip(features.vector(), prototype.centroid, prototype.weights):
        total += weight * (value - centre) ** 2
        weight_sum += weight
    return (total / weight_sum) ** 0.5


def assign_segment(features: AuthorFeatures) -> tuple[str, float, list[str]]:
    """Return (segment_id, fit_score, rationale)."""
    scored = sorted(((_distance(features, p), p) for p in PROTOTYPES), key=lambda kv: kv[0])
    best_distance, best = scored[0]
    runner_up_distance = scored[1][0] if len(scored) > 1 else best_distance + 1.0

    # Fit is high when the nearest prototype is both close and clearly nearer
    # than the next candidate.
    closeness = max(0.0, 1.0 - best_distance)
    separation = min(1.0, (runner_up_distance - best_distance) * 2.2)
    fit = round(min(0.97, 0.45 * closeness + 0.35 * separation + 0.2), 3)

    rationale = list(best.rationale)
    if features.reach > 0.7:
        rationale.append(f"reach percentile {features.reach:.0%}")
    if features.negativity > 0.6:
        rationale.append(f"{features.negativity:.0%} of posts read as negative")
    if features.technicality > 0.6:
        rationale.append("technical vocabulary well above corpus average")
    if features.amplification > 0.6:
        rationale.append("majority of activity redistributes others' content")

    return best.id, fit, rationale[:5]


def percentile_rank(values: list[float]) -> dict[float, float]:
    """Map each distinct value to its percentile rank in 0..1."""
    if not values:
        return {}
    ordered = sorted(values)
    n = len(ordered)
    ranks: dict[float, float] = {}
    for i, value in enumerate(ordered):
        if value not in ranks:
            ranks[value] = i / max(n - 1, 1)
    return ranks
