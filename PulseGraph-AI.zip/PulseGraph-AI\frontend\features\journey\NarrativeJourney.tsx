'use client';

/**
 * Narrative Journey.
 *
 * A vertical reconstruction of how one topic evolved: where it opened, when it
 * crossed to each platform, when sentiment inflected, which high-influence
 * account joined, when volume broke out, and when a second audience segment
 * arrived. Every milestone was discovered from stored rows and carries the
 * evidence that placed it.
 */

import {
  Activity,
  ArrowDownRight,
  Flag,
  Layers,
  TrendingUp,
  Users,
  Zap,
} from 'lucide-react';

import { WhyPanel } from '@/components/ui/Evidence';
import {
  Badge,
  EmptyState,
  Panel,
  PanelSkeleton,
  cx,
} from '@/components/ui/primitives';
import { duration, platformLabel, timeOfDay } from '@/lib/format';
import type { Journey, JourneyMilestone } from '@/types/api';

const KIND_META: Record<
  string,
  { icon: typeof Flag; tone: string; ring: string; label: string }
> = {
  origin: { icon: Flag, tone: 'text-trend', ring: 'ring-trend/40 bg-trend/10', label: 'Origin' },
  cross_platform: {
    icon: Layers,
    tone: 'text-influence',
    ring: 'ring-influence/40 bg-influence/10',
    label: 'Cross-platform',
  },
  sentiment_shift: {
    icon: ArrowDownRight,
    tone: 'text-negative',
    ring: 'ring-negative/40 bg-negative/10',
    label: 'Sentiment shift',
  },
  influencer: { icon: Zap, tone: 'text-warning', ring: 'ring-warning/40 bg-warning/10', label: 'Influence' },
  acceleration: {
    icon: TrendingUp,
    tone: 'text-critical',
    ring: 'ring-critical/40 bg-critical/10',
    label: 'Acceleration',
  },
  peak: { icon: Activity, tone: 'text-critical', ring: 'ring-critical/40 bg-critical/10', label: 'Peak' },
  segment_entry: {
    icon: Users,
    tone: 'text-positive',
    ring: 'ring-positive/40 bg-positive/10',
    label: 'Audience',
  },
};

function MilestoneRow({ milestone, last }: { milestone: JourneyMilestone; last: boolean }) {
  const meta = KIND_META[milestone.kind] ?? KIND_META.origin;
  const Icon = meta.icon;

  return (
    <li className="relative flex gap-3 pb-4 last:pb-0">
      {!last && (
        <span
          className="absolute left-[11px] top-6 h-full w-px bg-edge"
          aria-hidden
        />
      )}

      <span
        className={cx(
          'relative z-10 mt-0.5 grid h-[23px] w-[23px] shrink-0 place-items-center rounded-full ring-1',
          meta.ring,
        )}
        aria-hidden
      >
        <Icon className={cx('h-3 w-3', meta.tone)} />
      </span>

      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-baseline gap-x-2 gap-y-1">
          <time
            className="font-mono text-2xs tabular-nums text-ink"
            dateTime={milestone.ts}
          >
            {timeOfDay(milestone.ts)}
          </time>
          <span className="text-[13px] font-medium text-ink">{milestone.title}</span>
          <Badge tone="neutral">{meta.label}</Badge>
          {milestone.platform && (
            <Badge tone="neutral">{platformLabel(milestone.platform)}</Badge>
          )}
        </div>

        <p className="mt-1 text-2xs leading-relaxed text-ink-muted">{milestone.detail}</p>

        {milestone.sample_text && (
          <blockquote className="mt-1.5 border-l-2 border-edge-strong bg-canvas-sunken py-1.5 pl-2.5 pr-2 text-2xs italic leading-relaxed text-ink-faint">
            “{milestone.sample_text}”
          </blockquote>
        )}

        {milestone.actors.length > 0 && (
          <div className="mt-1.5 flex flex-wrap gap-1">
            {milestone.actors.map((actor) => (
              <Badge key={actor.anon_id} tone="warning">
                {actor.anon_id}
                <span className="font-mono opacity-70">
                  {actor.influence_score.toFixed(0)}
                </span>
              </Badge>
            ))}
          </div>
        )}

        {milestone.evidence.length > 0 && (
          <WhyPanel label="Evidence" evidence={milestone.evidence} />
        )}
      </div>
    </li>
  );
}

export function NarrativeJourney({
  journey,
  loading,
}: {
  journey: Journey | null;
  loading?: boolean;
}) {
  const leadLag = journey?.lead_lag?.[0];

  return (
    <Panel
      title="Narrative Journey"
      subtitle="How this topic actually evolved — reconstructed from post ordering, sentiment inflection, influence and audience entry"
      actions={
        journey?.span ? (
          <Badge tone="neutral">{journey.span.hours.toFixed(1)}h span</Badge>
        ) : null
      }
    >
      {loading && <PanelSkeleton rows={6} height="h-10" />}

      {!loading && (!journey || journey.milestones.length === 0) && (
        <EmptyState
          title="Not enough activity to reconstruct a journey"
          description="This topic needs sustained activity across at least a few intervals before an evolution can be traced."
        />
      )}

      {!loading && journey && journey.milestones.length > 0 && (
        <>
          {leadLag && (
            <div className="mb-4 rounded border border-influence/25 bg-influence/[0.06] px-3 py-2">
              <p className="text-2xs leading-relaxed text-ink-muted">
                <span className="font-medium text-influence">
                  {platformLabel(leadLag.lead_platform)}
                </span>{' '}
                showed sustained activity{' '}
                <span className="font-mono tabular-nums text-ink">
                  {duration(leadLag.minutes)}
                </span>{' '}
                before{' '}
                <span className="font-medium text-ink-muted">
                  {platformLabel(leadLag.lag_platform)}
                </span>
                . Observed ordering only — this is not evidence of causation.
              </p>
              {journey.episode_posts !== undefined && journey.total_posts !== undefined && (
                <p className="mt-1 text-[10px] text-ink-faint">
                  Episode covers {journey.episode_posts} of {journey.total_posts} posts on this
                  topic; earlier scattered mentions are treated as background.
                </p>
              )}
            </div>
          )}

          <ol className="relative">
            {journey.milestones.map((milestone, index) => (
              <MilestoneRow
                key={`${milestone.kind}-${milestone.ts}-${index}`}
                milestone={milestone}
                last={index === journey.milestones.length - 1}
              />
            ))}
          </ol>
        </>
      )}
    </Panel>
  );
}
