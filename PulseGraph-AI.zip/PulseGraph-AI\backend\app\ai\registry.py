"""Provider selection. One place decides which AI implementation is live."""

from __future__ import annotations

import logging
from functools import lru_cache

from app.ai.local_provider import LocalNLPProvider
from app.ai.openai_provider import OpenAIProvider
from app.ai.provider import AIProvider
from app.config import settings

logger = logging.getLogger(__name__)


@lru_cache(maxsize=1)
def get_ai_provider() -> AIProvider:
    choice = (settings.ai_provider or "local").strip().lower()
    if choice in {"openai", "external", "llm"}:
        if settings.ai_api_key:
            logger.info("Using OpenAI provider (%s)", settings.ai_model)
            return OpenAIProvider(settings.ai_api_key, settings.ai_model)
        logger.warning("AI_PROVIDER=openai but AI_API_KEY is empty; using local engine.")
    return LocalNLPProvider()


def reset_provider_cache() -> None:
    get_ai_provider.cache_clear()
