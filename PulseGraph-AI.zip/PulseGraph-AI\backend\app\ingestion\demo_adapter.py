"""Adapter that serves the deterministic demo corpus.

It implements exactly the same contract as the live adapters, so the pipeline
cannot tell the difference. Per-platform views are produced by filtering the
single generated corpus, which keeps cross-platform relationships intact.
"""

from __future__ import annotations

from functools import lru_cache

from app.ingestion.base import (
    DataSourceAdapter,
    IngestionBatch,
    NormalizedAuthor,
    NormalizedPost,
    SourceStatus,
    SourceTier,
)
from app.ingestion.demo_dataset import generate_demo_corpus


@lru_cache(maxsize=4)
def _corpus(seed: int, target: int) -> tuple[tuple[NormalizedAuthor, ...], tuple[NormalizedPost, ...]]:
    authors, posts = generate_demo_corpus(seed=seed, target_posts=target)
    return tuple(authors), tuple(posts)


class DemoDataAdapter(DataSourceAdapter):
    source_id = "demo"
    platform = "multi"
    display_name = "Demo intelligence dataset"
    tier = SourceTier.SYNTHETIC
    credential_fields = ()
    capabilities = ("posts", "replies", "mentions", "engagement", "author_profile", "cross_platform")

    def __init__(self, seed: int = 20260825, target_posts: int = 1600, platform: str | None = None):
        super().__init__({})
        self.seed = seed
        self.target_posts = target_posts
        self.platform_filter = platform

    def status(self) -> SourceStatus:
        return SourceStatus.DEMO

    def fetch(self, query: str = "", limit: int = 0) -> IngestionBatch:
        authors, posts = _corpus(self.seed, self.target_posts)
        posts_list = list(posts)
        authors_list = list(authors)

        if self.platform_filter:
            posts_list = [p for p in posts_list if p.platform == self.platform_filter]
            keep = {p.author_id for p in posts_list}
            authors_list = [a for a in authors_list if a.author_id in keep]

        if query:
            needle = query.lower()
            posts_list = [p for p in posts_list if needle in p.text.lower()]

        if limit:
            posts_list = posts_list[:limit]

        return IngestionBatch(
            source_id=self.source_id,
            platform=self.platform_filter or self.platform,
            status=SourceStatus.DEMO,
            posts=posts_list,
            authors=authors_list,
            message=f"Deterministic demo corpus (seed={self.seed}).",
        )
