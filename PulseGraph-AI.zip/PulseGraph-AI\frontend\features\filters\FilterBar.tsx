'use client';

/**
 * Global filter controls.
 *
 * Options are read from the backend, so the bar only ever offers values that
 * actually exist in the loaded dataset. Every selection writes to the URL and
 * therefore re-derives every panel on every page at once.
 */

import { useMemo, useState } from 'react';
import { Check, ChevronDown, Filter, X } from 'lucide-react';

import { api } from '@/lib/api';
import { useApi } from '@/hooks/useApi';
import { dateTime, platformLabel, titleCase } from '@/lib/format';
import { SENTIMENT_COLORS } from '@/lib/colors';
import { Badge, cx } from '@/components/ui/primitives';
import type { FilterOptions, Granularity } from '@/types/api';

import { useFilters } from './FilterContext';

const RANGE_LABELS: Record<string, string> = {
  '1h': 'Last hour',
  '6h': 'Last 6 hours',
  '12h': 'Last 12 hours',
  '24h': 'Last 24 hours',
  '3d': 'Last 3 days',
  '7d': 'Last 7 days',
  all: 'All data',
  custom: 'Custom window',
};

const GRANULARITIES: Granularity[] = ['hourly', '6-hourly', 'daily', 'weekly'];

function Dropdown({
  label,
  count,
  children,
}: {
  label: string;
  count: number;
  children: (close: () => void) => React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className={cx(
          'flex items-center gap-1.5 rounded border px-2 py-1 text-2xs transition-colors',
          count > 0
            ? 'border-trend/40 bg-trend/10 text-trend'
            : 'border-edge bg-canvas-sunken text-ink-muted hover:border-edge-strong hover:text-ink',
        )}
      >
        {label}
        {count > 0 && <span className="font-mono">{count}</span>}
        <ChevronDown className={cx('h-3 w-3 transition-transform', open && 'rotate-180')} aria-hidden />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} aria-hidden />
          <div className="absolute left-0 top-full z-50 mt-1 max-h-80 w-60 overflow-y-auto rounded border border-edge-strong bg-canvas-raised py-1 shadow-2xl">
            {children(() => setOpen(false))}
          </div>
        </>
      )}
    </div>
  );
}

function Option({
  active,
  onClick,
  children,
  swatch,
  meta,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
  swatch?: string;
  meta?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      role="menuitemcheckbox"
      aria-checked={active}
      className="flex w-full items-center gap-2 px-2.5 py-1.5 text-left text-2xs text-ink-muted hover:bg-canvas-hover hover:text-ink"
    >
      <span
        className={cx(
          'grid h-3 w-3 shrink-0 place-items-center rounded-sm border',
          active ? 'border-trend bg-trend/20' : 'border-edge-strong',
        )}
        aria-hidden
      >
        {active && <Check className="h-2.5 w-2.5 text-trend" />}
      </span>
      {swatch && (
        <span
          className="h-2 w-2 shrink-0 rounded-full"
          style={{ backgroundColor: swatch }}
          aria-hidden
        />
      )}
      <span className="min-w-0 flex-1 truncate">{children}</span>
      {meta && <span className="shrink-0 font-mono text-[10px] text-ink-faint">{meta}</span>}
    </button>
  );
}

export function FilterBar() {
  const { filters, activeCount, setRange, setGranularity, toggle, clear, clearKey } = useFilters();
  const { data } = useApi<FilterOptions>('filter-options', () => api.filterOptions());

  const chips = useMemo(() => {
    const list: { key: string; label: string; onRemove: () => void }[] = [];
    for (const p of filters.platforms) {
      list.push({ key: `p-${p}`, label: platformLabel(p), onRemove: () => toggle('platforms', p) });
    }
    for (const t of filters.topics) {
      const label = data?.topics.find((x) => x.id === t)?.label ?? t;
      list.push({ key: `t-${t}`, label, onRemove: () => toggle('topics', t) });
    }
    for (const s of filters.segments) {
      const label = data?.segments.find((x) => x.id === s)?.label ?? s;
      list.push({ key: `s-${s}`, label, onRemove: () => toggle('segments', s) });
    }
    for (const s of filters.sentiments) {
      list.push({ key: `sent-${s}`, label: titleCase(s), onRemove: () => toggle('sentiments', s) });
    }
    for (const e of filters.emotions) {
      list.push({ key: `e-${e}`, label: titleCase(e), onRemove: () => toggle('emotions', e) });
    }
    if (filters.search) {
      list.push({
        key: 'search',
        label: `text: “${filters.search}”`,
        onRemove: () => clearKey('search'),
      });
    }
    if (filters.start && filters.end) {
      list.push({
        key: 'window',
        label: `${dateTime(filters.start)} → ${dateTime(filters.end)}`,
        onRemove: () => clearKey('window'),
      });
    }
    return list;
  }, [filters, data, toggle, clearKey]);

  const ranges = data?.ranges ?? ['1h', '6h', '12h', '24h', '3d', '7d', 'all'];

  return (
    <div className="flex flex-wrap items-center gap-1.5 border-t border-edge-subtle bg-canvas-sunken/60 px-4 py-2">
      <Filter className="h-3.5 w-3.5 shrink-0 text-ink-faint" aria-hidden />

      {/* Time range */}
      <Dropdown label={RANGE_LABELS[filters.range] ?? filters.range} count={0}>
        {(close) => (
          <>
            {ranges.map((range) => (
              <Option
                key={range}
                active={filters.range === range}
                onClick={() => {
                  setRange(range);
                  close();
                }}
              >
                {RANGE_LABELS[range] ?? range}
              </Option>
            ))}
            {filters.start && filters.end && (
              <div className="border-t border-edge-subtle px-2.5 py-1.5 text-[10px] text-ink-faint">
                Custom window active — selected from the sentiment timeline.
              </div>
            )}
          </>
        )}
      </Dropdown>

      {/* Granularity */}
      <Dropdown label={titleCase(filters.granularity)} count={0}>
        {(close) => (
          <>
            {(data?.granularities ?? GRANULARITIES).map((g) => (
              <Option
                key={g}
                active={filters.granularity === g}
                onClick={() => {
                  setGranularity(g);
                  close();
                }}
              >
                {titleCase(g)}
              </Option>
            ))}
          </>
        )}
      </Dropdown>

      <span className="mx-0.5 h-4 w-px bg-edge" aria-hidden />

      <Dropdown label="Platform" count={filters.platforms.length}>
        {() => (
          <>
            {(data?.platforms ?? []).map((p) => (
              <Option
                key={p.id}
                active={filters.platforms.includes(p.id)}
                onClick={() => toggle('platforms', p.id)}
                meta={String(p.posts)}
              >
                {platformLabel(p.id)}
              </Option>
            ))}
            {!data?.platforms.length && (
              <p className="px-2.5 py-2 text-[10px] text-ink-faint">No platforms in dataset.</p>
            )}
          </>
        )}
      </Dropdown>

      <Dropdown label="Topic" count={filters.topics.length}>
        {() => (
          <>
            {(data?.topics ?? []).map((t) => (
              <Option
                key={t.id}
                active={filters.topics.includes(t.id)}
                onClick={() => toggle('topics', t.id)}
                meta={String(t.posts)}
              >
                {t.label}
              </Option>
            ))}
          </>
        )}
      </Dropdown>

      <Dropdown label="Segment" count={filters.segments.length}>
        {() => (
          <>
            {(data?.segments ?? []).map((s) => (
              <Option
                key={s.id}
                active={filters.segments.includes(s.id)}
                onClick={() => toggle('segments', s.id)}
                swatch={s.color}
                meta={String(s.size)}
              >
                {s.label}
              </Option>
            ))}
          </>
        )}
      </Dropdown>

      <Dropdown label="Sentiment" count={filters.sentiments.length}>
        {() => (
          <>
            {(data?.sentiments ?? ['positive', 'neutral', 'negative']).map((s) => (
              <Option
                key={s}
                active={filters.sentiments.includes(s)}
                onClick={() => toggle('sentiments', s)}
                swatch={SENTIMENT_COLORS[s as keyof typeof SENTIMENT_COLORS]}
              >
                {titleCase(s)}
              </Option>
            ))}
          </>
        )}
      </Dropdown>

      <Dropdown label="Emotion" count={filters.emotions.length}>
        {() => (
          <>
            {(data?.emotions ?? []).map((e) => (
              <Option
                key={e}
                active={filters.emotions.includes(e)}
                onClick={() => toggle('emotions', e)}
              >
                {titleCase(e)}
              </Option>
            ))}
          </>
        )}
      </Dropdown>

      {/* Active filter chips */}
      {chips.length > 0 && (
        <div className="flex flex-wrap items-center gap-1">
          <span className="mx-0.5 h-4 w-px bg-edge" aria-hidden />
          {chips.map((chip) => (
            <button
              key={chip.key}
              type="button"
              onClick={chip.onRemove}
              className="group"
              aria-label={`Remove filter ${chip.label}`}
            >
              <Badge tone="trend" className="group-hover:border-trend/60">
                <span className="max-w-[16rem] truncate">{chip.label}</span>
                <X className="h-2.5 w-2.5 opacity-60 group-hover:opacity-100" aria-hidden />
              </Badge>
            </button>
          ))}
        </div>
      )}

      {activeCount > 0 && (
        <button
          type="button"
          onClick={clear}
          className="ml-auto text-2xs text-ink-faint underline decoration-dotted hover:text-ink"
        >
          Clear all
        </button>
      )}
    </div>
  );
}
