'use client';

/** Persistent chrome: navigation rail, top bar, global search, filter bar. */

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Activity,
  Clock,
  Database,
  LayoutDashboard,
  Network,
  Shield,
  Users,
} from 'lucide-react';

import { FilterBar } from '@/features/filters/FilterBar';
import { cx } from '@/components/ui/primitives';

import { GlobalSearch } from './GlobalSearch';
import { StatusStrip } from './StatusStrip';

const NAV = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/audience', label: 'Audience', icon: Users },
  { href: '/network', label: 'Network', icon: Network },
  { href: '/timeline', label: 'Timeline', icon: Clock },
  { href: '/data', label: 'Data sources', icon: Database },
  { href: '/privacy', label: 'Privacy', icon: Shield },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="flex min-h-screen flex-col bg-canvas">
      <header className="sticky top-0 z-40 border-b border-edge bg-canvas/95 backdrop-blur">
        <div className="flex h-14 items-center gap-4 px-4">
          <Link href="/" className="flex shrink-0 items-center gap-2.5" aria-label="PulseGraph AI home">
            <span className="grid h-7 w-7 place-items-center rounded bg-trend/15 ring-1 ring-trend/30">
              <Activity className="h-4 w-4 text-trend" aria-hidden />
            </span>
            <span className="hidden sm:block">
              <span className="block text-[13px] font-semibold leading-none tracking-tight text-ink">
                PulseGraph AI
              </span>
              <span className="mt-0.5 block text-[10px] leading-none text-ink-faint">
                Social Intelligence. Explained.
              </span>
            </span>
          </Link>

          <nav className="hidden items-center gap-0.5 md:flex" aria-label="Primary">
            {NAV.map(({ href, label, icon: Icon }) => {
              const active = pathname === href || pathname.startsWith(`${href}/`);
              return (
                <Link
                  key={href}
                  href={href}
                  aria-current={active ? 'page' : undefined}
                  className={cx(
                    'flex items-center gap-1.5 rounded px-2.5 py-1.5 text-2xs font-medium transition-colors',
                    active
                      ? 'bg-canvas-hover text-ink'
                      : 'text-ink-muted hover:bg-canvas-hover/60 hover:text-ink',
                  )}
                >
                  <Icon className="h-3.5 w-3.5" aria-hidden />
                  {label}
                </Link>
              );
            })}
          </nav>

          <div className="ml-auto flex items-center gap-2">
            <GlobalSearch />
            <StatusStrip />
          </div>
        </div>

        <FilterBar />

        {/* Compact nav for narrow viewports; analytics stays desktop-first. */}
        <nav
          className="flex items-center gap-0.5 overflow-x-auto border-t border-edge-subtle px-2 py-1.5 md:hidden"
          aria-label="Primary (compact)"
        >
          {NAV.map(({ href, label, icon: Icon }) => {
            const active = pathname === href || pathname.startsWith(`${href}/`);
            return (
              <Link
                key={href}
                href={href}
                aria-current={active ? 'page' : undefined}
                className={cx(
                  'flex shrink-0 items-center gap-1.5 rounded px-2 py-1 text-2xs',
                  active ? 'bg-canvas-hover text-ink' : 'text-ink-muted',
                )}
              >
                <Icon className="h-3.5 w-3.5" aria-hidden />
                {label}
              </Link>
            );
          })}
        </nav>
      </header>

      <main className="flex-1 px-4 py-4">{children}</main>

      <footer className="border-t border-edge px-4 py-3">
        <p className="text-[10px] leading-relaxed text-ink-faint">
          Public data only · Demographics are aggregate inferences shown with confidence,
          never verified personal attributes · No private-message analysis · Accounts are
          shown pseudonymously ·{' '}
          <Link href="/privacy" className="underline decoration-dotted hover:text-ink-muted">
            Privacy and ethics
          </Link>
        </p>
      </footer>
    </div>
  );
}
