"""Deterministic rule + lexicon NLP engine.

This is the default provider. It requires no API key, no model download and no
network, and it produces the full multi-dimensional output the product needs:
sentiment, stance, emotion, and an explicit sarcasm judgement that separates the
*literal* reading of a sentence from its *contextual* reading.

Every decision records the cues that produced it, which is what makes the
"Why?" affordance in the UI real rather than decorative.
"""

from __future__ import annotations

import math
import re

from app.ai.provider import AIProvider, Narrative, TextAnalysis

# --------------------------------------------------------------------------- #
# Lexicons. Weights are magnitudes on a -3..+3 scale.
# --------------------------------------------------------------------------- #
POSITIVE: dict[str, float] = {
    "excellent": 3.0, "superb": 3.0, "outstanding": 3.0, "stunning": 2.8, "delighted": 2.8,
    "love": 2.5, "loved": 2.4, "great": 2.0, "amazing": 2.6, "fantastic": 2.6, "brilliant": 2.5,
    "perfect": 2.6, "wonderful": 2.5, "impressed": 2.2, "impressive": 2.2, "smooth": 1.6,
    "sharp": 1.5, "good": 1.5, "nice": 1.4, "happy": 2.0, "worth": 1.4, "recommend": 1.8,
    "best": 2.2, "better": 1.2, "solid": 1.4, "premium": 1.0, "helpful": 1.8, "fixed": 1.6,
    "resolved": 1.8, "improved": 1.6, "works": 1.2, "lovely": 2.2, "tempting": 1.2,
    "excited": 2.2, "superior": 2.0, "flawless": 2.8, "reliable": 1.8, "fine": 1.0,
    "clean": 1.2, "natural": 1.0, "ahead": 1.2, "genuinely": 0.6, "welcome": 1.2,
    "appreciate": 1.8, "thanks": 1.0, "credit": 1.2, "quick": 1.0, "prioritise": 0.8,
    "acceptable": 1.8, "smoother": 1.6, "sharper": 1.6,
    # Idioms carry sentiment that no single word in them does.
    "hard to beat": 2.2, "worth the wait": 2.0, "night and day": 1.6, "zero regrets": 2.2,
    "no regrets": 2.2, "credit where due": 1.8, "no issues": 1.6,
}

NEGATIVE: dict[str, float] = {
    "terrible": -3.0, "awful": -3.0, "horrible": -3.0, "disaster": -2.8, "absurd": -2.4,
    "unacceptable": -2.8, "broken": -2.4, "broke": -2.2, "bug": -1.6, "buggy": -2.0,
    "drain": -1.8, "draining": -2.0, "drains": -1.8, "dead": -2.0, "dies": -2.0, "die": -1.8,
    "worse": -2.0, "worst": -2.8, "bad": -2.0, "poor": -2.0, "disappointed": -2.4,
    "disappointing": -2.4, "frustrating": -2.4, "frustrated": -2.4, "annoying": -2.0,
    "angry": -2.6, "furious": -3.0, "useless": -2.8, "failure": -2.6, "failed": -2.2,
    "problem": -1.4, "issue": -1.2, "issues": -1.2, "complaint": -1.4, "regression": -2.0,
    "overheat": -2.2, "overheating": -2.2, "hot": -1.0, "warm": -0.6, "stutter": -1.6,
    "crash": -2.4, "crashes": -2.4, "lag": -1.6, "slow": -1.6, "delay": -1.4, "delayed": -1.4,
    "rejected": -2.2, "ignored": -2.0, "disconnected": -1.6, "waiting": -1.2, "wait": -0.8,
    "stuck": -1.8, "refund": -1.2, "return": -1.0, "returning": -1.6, "switching": -1.6,
    "switch": -1.0, "abandon": -2.2, "regret": -2.4, "stressing": -2.2, "worried": -2.0,
    "worry": -1.8, "concerned": -1.6, "concerning": -1.8, "risk": -1.4, "danger": -2.6,
    "dangerous": -2.6, "hazard": -2.4, "recall": -1.8, "lawsuit": -2.2, "banned": -2.2,
    "not normal": -1.8, "last straw": -2.6, "blown out of proportion": -1.0,
    "cannot": -1.0, "missed": -1.4, "wobble": -1.2,
    "noise": -0.8, "circles": -1.6, "absurdly": -1.6, "panicking": -1.6, "rumour": -0.8,
    "rumor": -0.8, "unverified": -0.8, "misleading": -1.8, "killed": -2.4, "kills": -2.2,
}

# Hinglish / romanised Hindi. Included because a meaningful share of the target
# audience code-switches, and generic English lexicons silently score these zero.
HINGLISH: dict[str, float] = {
    "bahut": -0.2, "bura": -2.2, "achha": 1.8, "accha": 1.8, "acha": 1.8, "badhiya": 2.2,
    "kharab": -2.4, "khatam": -1.6, "problem": -1.4, "dikkat": -2.0, "pareshan": -2.4,
    "garam": -1.4, "jaldi": -0.4, "nahi": -0.8, "nahin": -0.8, "bekar": -2.6, "faltu": -2.2,
    "mast": 2.2, "zabardast": 2.6, "shandar": 2.6, "sahi": 1.4, "theek": 0.8,
    "ghatiya": -2.8, "serious": -1.2, "issue": -1.2,
}

INTENSIFIERS: dict[str, float] = {
    "very": 1.4, "really": 1.35, "extremely": 1.7, "absolutely": 1.6, "completely": 1.5,
    "totally": 1.45, "genuinely": 1.3, "seriously": 1.4, "incredibly": 1.6, "so": 1.2,
    "such": 1.2, "way": 1.3, "far": 1.25, "much": 1.2, "bahut": 1.4, "bilkul": 1.5,
    "poora": 1.3, "highly": 1.4, "quite": 1.15, "noticeably": 1.25,
}

DIMINISHERS: dict[str, float] = {
    "slightly": 0.6, "somewhat": 0.65, "a bit": 0.6, "barely": 0.55, "hardly": 0.55,
    "mildly": 0.6, "kind of": 0.7, "sort of": 0.7, "marginally": 0.6, "almost": 0.8,
}

NEGATIONS = {
    "not", "no", "never", "cannot", "cant", "can't", "won't", "wont", "isn't", "isnt",
    "doesn't", "doesnt", "didn't", "didnt", "wouldn't", "wouldnt", "nothing", "nobody",
    "without", "neither", "nor", "hardly", "nahi", "nahin", "none",
}

# --- emotion cue sets ------------------------------------------------------- #
EMOTION_CUES: dict[str, list[str]] = {
    "angry": ["furious", "angry", "outrageous", "unacceptable", "absurd", "last straw",
              "fed up", "enough is enough", "terrible", "disgraceful", "ghatiya"],
    "frustrated": ["frustrating", "frustrated", "annoying", "again", "still no", "going in circles",
                   "third day", "twice", "no response", "no update", "pareshan", "irritating"],
    "anxious": ["worried", "worry", "stressing", "stressed", "scared", "afraid", "nervous",
                "is it safe", "should i stop", "dangerous", "risk", "panic"],
    "concerned": ["concerned", "concerning", "not normal", "something is wrong", "serious",
                  "please fix", "needs attention", "worth noting", "flagging"],
    "confused": ["confusing", "confused", "conflicting", "not sure", "unclear", "which setting",
                 "cannot tell", "undecided", "no idea", "why does"],
    "curious": ["anyone else", "has anyone", "does anyone", "wondering", "curious", "thoughts?",
                "what matters", "is it worth", "should i", "kisi ko", "kya kisi"],
    "excited": ["cannot believe", "can't believe", "finally", "it is here", "so good",
                "been waiting", "!!", "excited", "delighted", "love this", "wow"],
    "satisfied": ["works well", "no issues", "happy with", "credit where due", "resolved",
                  "sorted", "good handling", "very happy", "worth the wait", "no notes"],
    "sarcastic": [],  # populated by the sarcasm detector
}

STANCE_SUPPORT = [
    "team nova", "still the best", "fan since", "give it time", "blown out of proportion",
    "mine is completely fine", "worth the download", "credit where due", "recommend",
    "best hardware", "zero regrets", "no regrets", "settling period", "normal after an update",
]
STANCE_AGAINST = [
    "switching to", "moving to", "returning mine", "would not recommend", "not acceptable",
    "last straw", "get the orbit", "stop selling", "boycott", "never buying", "avoid this",
    "cannot deal with", "considering rolling back",
]

# --- sarcasm signals -------------------------------------------------------- #
SARCASM_OPENERS = [
    "great,", "great!", "oh great", "wonderful.", "wonderful,", "perfect.", "perfect,",
    "brilliant.", "brilliant,", "fantastic.", "amazing.", "lovely.", "oh good", "sure,",
    "well done", "nice one", "thanks for the", "love how", "love that", "just what i needed",
]
SARCASM_PATTERNS = [
    re.compile(r"\b(another|yet another)\b.{0,40}\b(update|outage|bug|delay|issue|patch)\b", re.I),
    re.compile(r"\bbest\b.{0,24}\bever\b.{0,24}(no notes|truly|obviously)", re.I),
    re.compile(r"\bnothing says\b.{0,40}\blike\b", re.I),
    re.compile(r"\bthanks (for|to)\b.{0,60}\b(dying|dies|drain|broke|breaking|bug|outage)\b", re.I),
    re.compile(r"\b(truly|really)\b[,\s]*(amazing|wonderful|brilliant|premium|fantastic)\b", re.I),
    re.compile(r"\b(very|really|so)\s+(reassuring|premium|professional)\b", re.I),
    re.compile(r"\blove how\b.{0,60}\b(now|again|still)\b", re.I),
]
# Words that make a superficially positive sentence unlikely to be sincere.
SARCASM_CONTEXT = [
    "outage", "drain", "draining", "dies", "die", "dead", "broken", "broke", "bug",
    "charging twice", "twice a day", "crash", "delay", "price cut", "worse", "again",
    "second time", "third time", "power bank", "before dinner", "five times a day",
]

TOKEN_RE = re.compile(r"[a-z0-9'’.]+")

MODEL_NAME = "pulsegraph-rule-nlp"
MODEL_VERSION = "1.2.0"


def _tokenize(text: str) -> list[str]:
    return TOKEN_RE.findall(text.lower())


# Conservative suffix reduction. Only applied as a fallback when the surface
# form is not itself in the lexicon, so it can add matches but never change one.
_SUFFIXES = ("iest", "ier", "est", "er", "ing", "ed", "s")


def _reduce(token: str) -> str:
    for suffix in _SUFFIXES:
        if len(token) > len(suffix) + 2 and token.endswith(suffix):
            stem = token[: -len(suffix)]
            if suffix in {"ier", "iest"}:
                stem += "y"
            if len(stem) >= 3 and stem[-1] == stem[-2]:
                stem = stem[:-1]  # "dropped" -> "drop"
            return stem
    return token


def _confidence(score: float, hits: int, tokens: int) -> float:
    """Confidence rises with signal strength and evidence density, and is
    capped so the engine never claims certainty."""
    if hits == 0:
        return 0.42
    strength = min(abs(score) / 3.2, 1.0)
    density = min(hits / max(math.sqrt(max(tokens, 1)), 1.0), 1.0)
    raw = 0.46 + 0.38 * strength + 0.16 * density
    return round(min(raw, 0.97), 3)


class LocalNLPProvider(AIProvider):
    """Lexicon + rule engine. Deterministic, offline, fully explainable."""

    name = MODEL_NAME
    version = MODEL_VERSION

    # ---------------------------------------------------------------- core
    def analyze_text(self, text: str, language: str = "en") -> TextAnalysis:
        if not text or not text.strip():
            return TextAnalysis(
                status="empty", model=self.name, model_version=self.version,
                cues={"reason": "empty text"},
            )

        lowered = text.lower()
        tokens = _tokenize(text)
        lexicon = dict(POSITIVE)
        lexicon.update(NEGATIVE)
        if language.startswith("hi") or self._looks_hinglish(tokens):
            lexicon.update(HINGLISH)

        score, matches = self._score_tokens(tokens, lexicon, lowered)

        # phrase-level lexicon entries (multi-word)
        for phrase, weight in list(NEGATIVE.items()) + list(POSITIVE.items()):
            if " " in phrase and phrase in lowered:
                score += weight
                matches.append({"term": phrase, "weight": weight, "base_weight": weight,
                                "negated": False, "intensified": False})

        literal_polarity = self._normalise(score, tokens)
        literal = self._label(literal_polarity)

        sarcasm, sarcasm_conf, sarcasm_cues = self._detect_sarcasm(
            lowered, literal_polarity, matches
        )

        polarity = literal_polarity
        if sarcasm:
            # Invert and damp: sarcastic praise is negative, but the magnitude of
            # the literal reading is not a reliable measure of how negative.
            polarity = -abs(literal_polarity) * (0.55 + 0.35 * sarcasm_conf)
            polarity = max(polarity, -0.95)
            if abs(polarity) < 0.25:
                polarity = -0.35

        contextual = self._label(polarity)
        sentiment = contextual
        hits = len(matches)
        sentiment_conf = _confidence(score, hits, len(tokens))
        if sarcasm:
            # A reversed reading is inherently less certain than a plain one.
            sentiment_conf = round(min(sentiment_conf, 0.4 + 0.45 * sarcasm_conf), 3)

        stance, stance_hits = self._stance(lowered, polarity)
        emotion, emotion_conf, emotion_hits = self._emotion(
            lowered, polarity, sarcasm, sarcasm_conf
        )

        cues = {
            "matched_terms": [m["term"] for m in matches[:12]],
            "weighted_terms": matches[:12],
            "negated_terms": [m["term"] for m in matches if m.get("negated")],
            "raw_score": round(score, 3),
            "token_count": len(tokens),
            "sarcasm_signals": sarcasm_cues,
            "stance_signals": stance_hits,
            "emotion_signals": emotion_hits,
            "language_pack": "hinglish+en" if lexicon.get("bekar") else "en",
        }

        return TextAnalysis(
            sentiment=sentiment,
            sentiment_confidence=sentiment_conf,
            stance=stance,
            emotion=emotion,
            emotion_confidence=emotion_conf,
            polarity=round(polarity, 4),
            literal_sentiment=literal,
            contextual_sentiment=contextual,
            sarcasm_detected=sarcasm,
            sarcasm_confidence=round(sarcasm_conf, 3),
            cues=cues,
            model=self.name,
            model_version=self.version,
            status="ok",
        )

    # ------------------------------------------------------------- helpers
    @staticmethod
    def _looks_hinglish(tokens: list[str]) -> bool:
        markers = {"yaar", "bhai", "hai", "nahi", "ke", "ka", "ki", "kya", "mera", "bahut",
                   "jaata", "raha", "ho", "aur", "baad", "poora", "kisi", "mila"}
        return len(markers.intersection(tokens)) >= 2

    def _score_tokens(
        self, tokens: list[str], lexicon: dict[str, float], lowered: str
    ) -> tuple[float, list[dict]]:
        score = 0.0
        matches: list[dict] = []
        for i, token in enumerate(tokens):
            clean = token.strip(".'’")
            weight = lexicon.get(clean)
            matched_form = clean
            if weight is None:
                # Inflected forms ("smoother", "drained") should resolve to their
                # lexicon entry rather than scoring zero.
                stem = _reduce(clean)
                if stem != clean:
                    weight = lexicon.get(stem)
                    matched_form = stem
            if weight is None:
                continue

            multiplier = 1.0
            window = tokens[max(0, i - 3): i]
            for prior in window:
                p = prior.strip(".'’")
                if p in INTENSIFIERS:
                    multiplier *= INTENSIFIERS[p]
                elif p in DIMINISHERS:
                    multiplier *= DIMINISHERS[p]

            negated = any(t.strip(".'’") in NEGATIONS for t in window)
            # "no longer good" style phrasing
            if not negated and i >= 2 and " ".join(tokens[i - 2:i]) in {"no longer", "not really"}:
                negated = True

            effective = weight * multiplier
            if negated:
                effective *= -0.8

            score += effective
            matches.append({
                "term": matched_form,
                "surface_form": clean,
                "weight": round(effective, 3),
                "base_weight": weight,
                "negated": negated,
                "intensified": multiplier != 1.0,
            })
        _ = lowered
        return score, matches

    @staticmethod
    def _normalise(score: float, tokens: list[str]) -> float:
        """Squash the raw score into -1..1, discounting length."""
        if score == 0:
            return 0.0
        length_factor = math.sqrt(max(len(tokens), 4)) / 4.0
        adjusted = score / max(length_factor, 1.0)
        return max(-1.0, min(1.0, adjusted / 4.0))

    @staticmethod
    def _label(polarity: float) -> str:
        if polarity >= 0.12:
            return "positive"
        if polarity <= -0.12:
            return "negative"
        return "neutral"

    def _detect_sarcasm(
        self, lowered: str, literal_polarity: float, matches: list[dict]
    ) -> tuple[bool, float, list[str]]:
        """Sarcasm is treated as a *conflict* between surface praise and
        contextual meaning, not as a keyword lookup."""
        signals: list[str] = []
        score = 0.0

        for opener in SARCASM_OPENERS:
            if lowered.startswith(opener) or f" {opener}" in lowered[:60]:
                score += 0.34
                signals.append(f"praise opener: '{opener.strip(',.')}'")
                break

        for pattern in SARCASM_PATTERNS:
            found = pattern.search(lowered)
            if found:
                score += 0.3
                signals.append(f"ironic construction: '{found.group(0)[:48].strip()}'")

        context_hits = [c for c in SARCASM_CONTEXT if c in lowered]
        positive_terms = [m["term"] for m in matches if m["base_weight"] > 1.4 and not m["negated"]]
        if context_hits and positive_terms:
            score += 0.3
            signals.append(
                f"positive wording ({', '.join(positive_terms[:3])}) around negative context "
                f"({', '.join(context_hits[:3])})"
            )

        if literal_polarity > 0.2 and context_hits:
            score += 0.18
            signals.append("literal reading is positive but the described outcome is a failure")

        if re.search(r"\b(no notes|truly|obviously|clearly)\b\.?$", lowered.strip()):
            score += 0.12
            signals.append("dismissive closing tag")

        detected = score >= 0.5 and literal_polarity > -0.05
        confidence = min(score, 0.94) if detected else min(score, 0.45)
        if detected:
            signals.append("literal and contextual readings disagree")
        return detected, confidence, signals

    @staticmethod
    def _stance(lowered: str, polarity: float) -> tuple[str, list[str]]:
        support_hits = [p for p in STANCE_SUPPORT if p in lowered]
        against_hits = [p for p in STANCE_AGAINST if p in lowered]
        if against_hits and len(against_hits) >= len(support_hits):
            return "against", against_hits[:4]
        if support_hits:
            return "supportive", support_hits[:4]
        if polarity <= -0.45:
            return "against", ["strong negative polarity"]
        if polarity >= 0.45:
            return "supportive", ["strong positive polarity"]
        return "neutral", []

    @staticmethod
    def _emotion(
        lowered: str, polarity: float, sarcasm: bool, sarcasm_conf: float
    ) -> tuple[str, float, list[str]]:
        if sarcasm:
            return "sarcastic", round(min(0.94, 0.5 + sarcasm_conf * 0.45), 3), ["sarcasm detected"]

        scores: dict[str, tuple[int, list[str]]] = {}
        for emotion, cues in EMOTION_CUES.items():
            hits = [c for c in cues if c in lowered]
            if hits:
                scores[emotion] = (len(hits), hits)

        if scores:
            emotion, (count, hits) = max(scores.items(), key=lambda kv: kv[1][0])
            confidence = round(min(0.92, 0.52 + 0.13 * count + 0.1 * abs(polarity)), 3)
            return emotion, confidence, hits[:4]

        # fall back to polarity-shaped defaults
        if polarity <= -0.5:
            return "angry", round(min(0.8, 0.5 + abs(polarity) * 0.3), 3), ["strong negative polarity"]
        if polarity <= -0.15:
            return "concerned", round(0.5 + abs(polarity) * 0.3, 3), ["mild negative polarity"]
        if polarity >= 0.5:
            return "excited", round(min(0.82, 0.5 + polarity * 0.32), 3), ["strong positive polarity"]
        if polarity >= 0.15:
            return "satisfied", round(0.5 + polarity * 0.3, 3), ["mild positive polarity"]
        return "neutral", 0.45, []

    # --------------------------------------------------------- narration
    def interpret(self, brief: dict) -> Narrative:
        """Compose a narrative strictly from the supplied, already-computed
        figures. No value here is generated by the engine."""
        parts: list[str] = []
        headline = brief.get("headline")
        if headline:
            parts.append(headline)

        drivers = brief.get("drivers") or []
        if drivers:
            parts.append("Likely driver: " + "; ".join(str(d) for d in drivers[:2]) + ".")

        platforms = brief.get("platforms") or []
        if len(platforms) > 1:
            parts.append(
                "Observed across " + ", ".join(platforms[:4]) + "."
            )
        elif platforms:
            parts.append(f"Concentrated on {platforms[0]}.")

        segments = brief.get("segments") or []
        if segments:
            parts.append("Most affected audience: " + ", ".join(segments[:2]) + ".")

        lead = brief.get("lead_time_minutes")
        if lead:
            parts.append(
                f"{brief.get('lead_platform', 'One platform')} activity preceded the "
                f"{brief.get('lag_platform', 'other')} increase by about {int(lead)} minutes."
            )

        return Narrative(
            summary=" ".join(parts).strip(),
            recommended_action=brief.get("recommended_action", ""),
            source="local",
        )


# Alias kept for readers coming from the architecture brief, where this
# component is referred to as the local (non-external) provider.
LocalMockProvider = LocalNLPProvider
