"""Shared fixtures.

The pipeline fixture is session-scoped: it runs the real pipeline once against
an isolated temporary SQLite database, and the analytical tests then assert
against genuine computed output rather than mocks.
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pytest

# Point the app at a throwaway database before any app module is imported.
_TMP_DIR = Path(tempfile.mkdtemp(prefix="pulsegraph-tests-"))
os.environ["DATABASE_URL"] = f"sqlite:///{(_TMP_DIR / 'test.db').as_posix()}"
os.environ["DEMO_POST_TARGET"] = "700"
os.environ["DEMO_SEED"] = "4242"
os.environ["AI_PROVIDER"] = "local"


@pytest.fixture(scope="session")
def db_session():
    from app.db import SessionLocal, init_db

    init_db()
    session = SessionLocal()
    yield session
    session.close()


@pytest.fixture(scope="session")
def analysis_run(db_session):
    """Run the whole pipeline once for the analytical test modules."""
    from app.analytics.pipeline import Pipeline

    run = Pipeline(db_session).run(["demo"], trigger="pytest")
    db_session.commit()
    return run


@pytest.fixture(scope="session")
def service(db_session, analysis_run):
    from app.analytics.queries import AnalyticsService

    return AnalyticsService(db_session)


@pytest.fixture(scope="session")
def no_filters():
    from app.analytics.filters import AnalysisFilters

    return AnalysisFilters()


@pytest.fixture(scope="session")
def api_client(analysis_run):
    from fastapi.testclient import TestClient

    from app.main import app

    with TestClient(app) as client:
        yield client
