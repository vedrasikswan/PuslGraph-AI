'use client';

/**
 * Timeline page: a chronological event log combining detections and journey
 * milestones, over the sentiment volume chart.
 */

import { useMemo, useState } from 'react';
import Link from 'next/link';
import {
  Activity,
  ArrowUpRight,
  Flag,
  Layers,
  TrendingUp,
  Users,
  Zap,
} from 'lucide-react';

import { SentimentTimeline } from '@/components/charts/SentimentTimeline';
import {
  Badge,
  EmptyState,
  ErrorState,
  Panel,
  PanelSkeleton,
  SeverityBadge,
  cx,
} from '@/components/ui/primitives';
import { filterKey, useFilters } from '@/features/filters/FilterContext';
import { TrendRow } from '@/features/trends/TrendRadar';
import { useApi } from '@/hooks/useApi';
import { api } from '@/lib/api';
import { SEVERITY_STYLES } from '@/lib/colors';
import { dateTime, platformLabel, titleCase } from '@/lib/format';
import type { TimelineResponse, Trend } from '@/types/api';

const KIND_ICONS: Record<string, typeof Flag> = {
  origin: Flag,
  cross_platform: Layers,
  sentiment_shift: Activity,
  influencer: Zap,
  acceleration: TrendingUp,
  peak: Activity,
  segment_entry: Users,
};

export function TimelineView() {
  const { filters, setWindow } = useFilters();
  const key = filterKey(filters);
  const [kindFilter, setKindFilter] = useState<'all' | 'intelligence' | 'journey'>('all');

  const timeline = useApi<TimelineResponse>(`timeline-page:${key}`, () => api.timeline(filters));
  const trends = useApi<{ items: Trend[] }>(`trends-page:${key}`, () => api.trends(filters));

  const events = useMemo(() => {
    if (!timeline.data) return null;
    return kindFilter === 'all'
      ? timeline.data.events
      : timeline.data.events.filter((e) => e.kind === kindFilter);
  }, [timeline.data, kindFilter]);

  if (timeline.error) {
    return (
      <Panel>
        <ErrorState error={timeline.error} onRetry={timeline.reload} />
      </Panel>
    );
  }

  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-lg font-semibold tracking-tight text-ink">Event timeline</h1>
        <p className="mt-0.5 text-2xs text-ink-muted">
          Chronological view of activity, detections and topic milestones for the current
          selection
        </p>
      </div>

      <Panel
        title="Activity and sentiment"
        subtitle="Click an interval to scope every view to that window"
      >
        {timeline.loading && <PanelSkeleton rows={5} height="h-8" />}
        {timeline.data && timeline.data.buckets.length > 0 && (
          <SentimentTimeline
            points={timeline.data.buckets}
            granularity={filters.granularity}
            onSelectWindow={setWindow}
            selected={{ start: filters.start, end: filters.end }}
            height={220}
          />
        )}
        {timeline.data && timeline.data.buckets.length === 0 && (
          <EmptyState title="No activity in this window" />
        )}
      </Panel>

      <div className="grid gap-3 xl:grid-cols-[1fr_380px]">
        <Panel
          title="Event log"
          subtitle="Detections and reconstructed topic milestones, newest first"
          dense
          actions={
            <div className="flex items-center gap-0.5">
              {(['all', 'intelligence', 'journey'] as const).map((kind) => (
                <button
                  key={kind}
                  type="button"
                  onClick={() => setKindFilter(kind)}
                  className={cx(
                    'rounded px-1.5 py-0.5 text-2xs transition-colors',
                    kindFilter === kind
                      ? 'bg-canvas-hover text-ink'
                      : 'text-ink-faint hover:text-ink-muted',
                  )}
                >
                  {kind === 'all' ? 'All' : titleCase(kind)}
                </button>
              ))}
            </div>
          }
        >
          {timeline.loading && (
            <div className="p-4">
              <PanelSkeleton rows={8} height="h-10" />
            </div>
          )}

          {events && events.length === 0 && (
            <EmptyState
              title="No events in this selection"
              description="Nothing was detected and no topic milestone falls inside the current filters."
            />
          )}

          <ol>
            {events?.map((event, index) => {
              const Icon =
                event.kind === 'intelligence'
                  ? Zap
                  : KIND_ICONS[event.category] ?? Activity;
              const style = SEVERITY_STYLES[event.severity];
              return (
                <li
                  key={`${event.reference_id ?? event.category}-${event.ts}-${index}`}
                  className="flex gap-3 border-b border-edge-subtle px-4 py-2.5 last:border-0 hover:bg-canvas-hover/40"
                >
                  <div className="flex w-16 shrink-0 flex-col items-end">
                    <time className="font-mono text-2xs tabular-nums text-ink" dateTime={event.ts}>
                      {new Date(event.ts).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </time>
                    <span className="text-[10px] text-ink-faint">
                      {new Date(event.ts).toLocaleDateString([], {
                        month: 'short',
                        day: 'numeric',
                      })}
                    </span>
                  </div>

                  <span
                    className={cx('mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded', style.bg)}
                    aria-hidden
                  >
                    <Icon className={cx('h-3 w-3', style.text)} />
                  </span>

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <p className="text-2xs font-medium text-ink">{event.title}</p>
                      {event.kind === 'intelligence' && (
                        <SeverityBadge severity={event.severity} />
                      )}
                      <Badge tone="neutral">{titleCase(event.category)}</Badge>
                      {event.platform && (
                        <Badge tone="neutral">{platformLabel(event.platform)}</Badge>
                      )}
                    </div>
                    <p className="mt-1 text-2xs leading-relaxed text-ink-muted">{event.detail}</p>
                    {event.topic_id && (
                      <Link
                        href={`/topics/${event.topic_id}`}
                        className="mt-1 inline-flex items-center gap-1 text-[10px] text-ink-faint hover:text-ink"
                      >
                        Open topic
                        <ArrowUpRight className="h-2.5 w-2.5" aria-hidden />
                      </Link>
                    )}
                    <p className="mt-0.5 text-[10px] text-ink-faint">{dateTime(event.ts)}</p>
                  </div>
                </li>
              );
            })}
          </ol>
        </Panel>

        <Panel
          title="All tracked topics"
          subtitle="Every topic with activity in this selection, ranked by trend score"
          dense
        >
          {trends.loading && (
            <div className="p-4">
              <PanelSkeleton rows={6} height="h-10" />
            </div>
          )}
          {trends.data?.items.length === 0 && <EmptyState title="No topics in this selection" />}
          {trends.data?.items.map((trend) => (
            <TrendRow key={trend.topic_id} trend={trend} compact />
          ))}
        </Panel>
      </div>
    </div>
  );
}
