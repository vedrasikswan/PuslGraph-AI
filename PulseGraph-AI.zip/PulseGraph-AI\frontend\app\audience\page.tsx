import { Suspense } from 'react';

import { AppShell } from '@/components/layout/AppShell';
import { FilterProvider } from '@/features/filters/FilterContext';

import { AudienceView } from './AudienceView';

export const metadata = { title: 'Audience — PulseGraph AI' };

export default function Page() {
  return (
    <Suspense fallback={null}>
      <FilterProvider>
        <AppShell>
          <AudienceView />
        </AppShell>
      </FilterProvider>
    </Suspense>
  );
}
