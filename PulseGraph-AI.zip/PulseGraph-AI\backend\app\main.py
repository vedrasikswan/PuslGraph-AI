"""FastAPI application entrypoint.

Modular but monolithic by design: one service, one database, routers grouped by
concern. No microservices, no message broker, no orchestration layer - none of
which this workload needs.
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.exc import SQLAlchemyError

from app.api.routes import VERSION, router
from app.config import settings
from app.db import init_db

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
)
logger = logging.getLogger("pulsegraph")


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    logger.info(
        "PulseGraph AI %s ready (demo_mode=%s, ai_provider=%s)",
        VERSION, settings.demo_mode, settings.ai_provider,
    )
    yield


app = FastAPI(
    title="PulseGraph AI",
    description=(
        "Social Intelligence. Explained. — an AI-driven social media analytics "
        "framework covering ingestion, multi-dimensional sentiment, demographic "
        "aggregation, trend detection and link analysis."
    ),
    version=VERSION,
    lifespan=lifespan,
    docs_url="/docs",
    openapi_url="/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)

app.include_router(router)


# --------------------------------------------------------------------------- #
# Error handling: useful messages, never a stack trace
# --------------------------------------------------------------------------- #
@app.exception_handler(RequestValidationError)
async def validation_error(_request: Request, exc: RequestValidationError) -> JSONResponse:
    fields = [".".join(str(p) for p in err["loc"][1:]) or "body" for err in exc.errors()]
    return JSONResponse(
        status_code=422,
        content={
            "error": "invalid_request",
            "detail": f"Invalid value for: {', '.join(fields)}",
            "hint": "Check the query parameters against /docs.",
        },
    )


@app.exception_handler(SQLAlchemyError)
async def database_error(_request: Request, exc: SQLAlchemyError) -> JSONResponse:
    logger.exception("Database error")
    return JSONResponse(
        status_code=503,
        content={
            "error": "database_unavailable",
            "detail": "The analytics database could not be reached.",
            "hint": "Verify DATABASE_URL, then reload the demo dataset.",
        },
    )


@app.exception_handler(Exception)
async def unhandled_error(_request: Request, exc: Exception) -> JSONResponse:
    logger.exception("Unhandled error")
    return JSONResponse(
        status_code=500,
        content={
            "error": "internal_error",
            "detail": "Something went wrong while computing this view.",
            "hint": "The server log names the failing stage.",
        },
    )


@app.get("/", tags=["system"])
def root() -> dict:
    return {
        "name": "PulseGraph AI",
        "tagline": "See what changed. Understand why. Trace how it spread.",
        "version": VERSION,
        "demo_mode": settings.demo_mode,
        "docs": "/docs",
        "health": "/api/health",
    }
