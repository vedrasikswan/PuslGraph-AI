'use client';

/**
 * Privacy and ethics.
 *
 * These commitments constrain the implementation, so this page states them
 * plainly and points at where each one is enforced in the product rather than
 * being a generic policy statement.
 */

import { AlertTriangle, Check, Eye, Lock, ShieldCheck, X } from 'lucide-react';

import { Badge, Panel } from '@/components/ui/primitives';
import { useApi } from '@/hooks/useApi';
import { api } from '@/lib/api';
import type { HealthResponse } from '@/types/api';

const COMMITMENTS: { text: string; where: string }[] = [
  {
    text: 'Public data only',
    where:
      'Every adapter reads public timelines, public channels, public comments and public profile fields. No adapter requests private-message scopes.',
  },
  {
    text: 'No private-message analysis',
    where:
      'The Telegram adapter ingests public channel messages only; direct messages are out of scope and are never requested.',
  },
  {
    text: 'Aggregated demographic insight',
    where:
      'The audience view reports distributions. Individual inferred rows exist so an aggregate can be traced to its source, never to profile a person.',
  },
  {
    text: 'No sensitive attribute inference',
    where:
      'The engine infers age bracket, region, language, professional interest and posting behaviour. It does not infer health, religion, sexuality, politics or any special-category attribute.',
  },
  {
    text: 'No claim of demographic certainty',
    where:
      'Every inferred attribute carries a confidence band and the public signal it came from. Age inference is capped below the High band by design.',
  },
  {
    text: 'Pseudonymous identifiers in the analytical UI',
    where:
      'Accounts appear as stable pseudonyms such as A4193 throughout the dashboard, network graph and intelligence cards.',
  },
  {
    text: 'No causal claims',
    where:
      'Detections use "preceded", "likely driver", "appears to originate from" and "associated with". Cross-platform ordering is reported as observation.',
  },
  {
    text: 'Platform API terms respected',
    where:
      'Live adapters require the platform\'s own credentials and use official APIs. Without credentials an adapter reports Not connected — it never fabricates connectivity.',
  },
];

const NOT_DONE = [
  'Reading, storing or analysing private messages',
  'Inferring health, religion, sexuality, political affiliation or other special-category data',
  'Presenting an inferred attribute as a verified fact about a person',
  'Exposing personal identifiers where a pseudonym suffices',
  'Claiming a proven causal relationship from co-occurrence in time',
  'Scraping around a platform\'s access controls or rate limits',
];

export function PrivacyView() {
  const { data } = useApi<HealthResponse>('health', () => api.health());

  return (
    <div className="mx-auto max-w-4xl space-y-3">
      <div>
        <h1 className="text-lg font-semibold tracking-tight text-ink">Privacy and ethics</h1>
        <p className="mt-0.5 text-2xs text-ink-muted">
          Constraints this platform is built around, and where each one is enforced.
        </p>
      </div>

      {data?.demo_mode && (
        <Panel>
          <p className="flex items-start gap-2 text-2xs leading-relaxed text-ink-muted">
            <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-warning" aria-hidden />
            <span>
              This instance is running in <strong className="text-ink">demo mode</strong> on a
              deterministic synthetic corpus. No real accounts, no real people and no live
              platform data are involved in anything currently displayed.
            </span>
          </p>
        </Panel>
      )}

      <Panel
        title={
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="h-3.5 w-3.5 text-positive" aria-hidden />
            Commitments
          </span>
        }
        subtitle="Each is a property of the implementation, not a statement of intent"
      >
        <ul className="space-y-2.5">
          {COMMITMENTS.map((item) => (
            <li key={item.text} className="flex gap-2.5">
              <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-positive" aria-hidden />
              <div>
                <p className="text-2xs font-medium text-ink">{item.text}</p>
                <p className="mt-0.5 text-2xs leading-relaxed text-ink-faint">{item.where}</p>
              </div>
            </li>
          ))}
        </ul>
      </Panel>

      <div className="grid gap-3 md:grid-cols-2">
        <Panel
          title={
            <span className="flex items-center gap-1.5">
              <X className="h-3.5 w-3.5 text-negative" aria-hidden />
              What this platform does not do
            </span>
          }
        >
          <ul className="space-y-1.5">
            {NOT_DONE.map((item) => (
              <li key={item} className="flex gap-2 text-2xs leading-relaxed text-ink-muted">
                <span className="mt-1 h-1 w-1 shrink-0 rounded-full bg-negative" aria-hidden />
                {item}
              </li>
            ))}
          </ul>
        </Panel>

        <Panel
          title={
            <span className="flex items-center gap-1.5">
              <Eye className="h-3.5 w-3.5 text-influence" aria-hidden />
              Confidence bands
            </span>
          }
          subtitle="How to read every inferred figure in the product"
        >
          <div className="space-y-2">
            {[
              { band: 'High', range: '0.80 – 1.00', tone: 'positive' as const,
                note: 'Strong, directly observed signal.' },
              { band: 'Medium', range: '0.60 – 0.79', tone: 'warning' as const,
                note: 'Supported, but treat as an estimate.' },
              { band: 'Low', range: 'below 0.60', tone: 'neutral' as const,
                note: 'Weak signal. Never present as fact.' },
            ].map((row) => (
              <div key={row.band} className="flex items-start gap-2.5">
                <Badge tone={row.tone}>{row.band}</Badge>
                <div className="min-w-0">
                  <p className="font-mono text-2xs text-ink-muted">{row.range}</p>
                  <p className="text-[10px] leading-relaxed text-ink-faint">{row.note}</p>
                </div>
              </div>
            ))}
          </div>

          <p className="mt-3 border-t border-edge-subtle pt-2 text-[10px] leading-relaxed text-ink-faint">
            Sentiment confidence is additionally capped when a sarcasm reversal is applied,
            because a reversed reading is inherently less certain than a plain one.
          </p>
        </Panel>
      </div>

      <Panel
        title={
          <span className="flex items-center gap-1.5">
            <Lock className="h-3.5 w-3.5 text-ink-muted" aria-hidden />
            Data handling
          </span>
        }
      >
        <dl className="space-y-1.5">
          {[
            ['Storage', 'Local SQLite by default. Nothing leaves the machine in demo mode.'],
            ['AI provider', data?.ai_provider.provider ?? 'local rule engine'],
            [
              'External calls',
              data?.ai_provider.provider === 'openai'
                ? 'Post text is sent to the configured LLM for classification.'
                : 'None. The default engine is fully local and offline.',
            ],
            ['Retention', 'The dataset is cleared and regenerated on every demo reset.'],
          ].map(([label, value]) => (
            <div key={label} className="flex flex-wrap items-baseline gap-2">
              <dt className="w-32 shrink-0 text-2xs text-ink-faint">{label}</dt>
              <dd className="min-w-0 flex-1 text-2xs text-ink-muted">{value}</dd>
            </div>
          ))}
        </dl>
      </Panel>
    </div>
  );
}
