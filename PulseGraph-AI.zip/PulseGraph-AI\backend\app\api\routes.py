"""REST API.

One modular router per concern, all mounted under /api on a single service.
Every analytical endpoint accepts the same filter query parameters, which is
what keeps the dashboard synchronised.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.ai.registry import get_ai_provider
from app.analytics.filters import AnalysisFilters
from app.analytics.pipeline import Pipeline
from app.analytics.queries import AnalyticsService, invalidate_cache
from app.api.deps import get_filters, get_service, require_dataset
from app.config import settings
from app.db import get_db
from app.ingestion.registry import PLATFORM_ORDER, describe_sources
from app.models import AudienceSegment, DataSource, Post, Topic
from app.schemas import (
    AnalyzeRequest,
    AnalyzeResponse,
    AudienceResponse,
    HealthResponse,
    IngestionRequest,
    IngestionResponse,
    IntelligenceResponse,
    NetworkResponse,
    OverviewResponse,
    PostsResponse,
    SourcesResponse,
    TimelineResponse,
    TrendsResponse,
)

logger = logging.getLogger(__name__)

VERSION = "1.0.0"

router = APIRouter(prefix="/api")


# --------------------------------------------------------------------------- #
# Health & metadata
# --------------------------------------------------------------------------- #
@router.get("/health", response_model=HealthResponse, tags=["system"])
def health(db: Session = Depends(get_db)) -> HealthResponse:
    provider = get_ai_provider()
    posts = db.scalar(select(func.count(Post.id))) or 0
    service = AnalyticsService(db)
    try:
        provider_health = provider.health()
        status = "degraded" if provider_health.get("status") == "degraded" else "ok"
    except Exception as exc:
        logger.warning("Provider health check failed: %s", exc)
        provider_health = {"provider": provider.name, "status": "error"}
        status = "degraded"

    return HealthResponse(
        status=status,
        version=VERSION,
        demo_mode=settings.demo_mode,
        database=settings.database_url.split("///")[-1],
        ai_provider=provider_health,
        dataset_ready=posts > 0,
        posts=posts,
        last_run=service.latest_run(),
    )


@router.get("/meta/filters", tags=["system"])
def filter_options(db: Session = Depends(get_db)) -> dict:
    """Everything the filter bar needs, derived from what is actually stored."""
    platforms = [
        {"id": p, "posts": c}
        for p, c in db.execute(
            select(Post.platform, func.count(Post.id)).group_by(Post.platform)
        ).all()
    ]
    topics = [
        {"id": t.id, "label": t.label, "posts": t.post_count}
        for t in db.execute(select(Topic).order_by(Topic.post_count.desc())).scalars()
        if t.post_count > 0
    ]
    segments = [
        {"id": s.id, "label": s.name, "color": s.color, "size": s.size}
        for s in db.execute(select(AudienceSegment).order_by(AudienceSegment.size.desc())).scalars()
        if s.size > 0
    ]
    bounds = db.execute(select(func.min(Post.created_at), func.max(Post.created_at))).one()
    return {
        "platforms": sorted(platforms, key=lambda p: PLATFORM_ORDER.index(p["id"])
                            if p["id"] in PLATFORM_ORDER else 99),
        "topics": topics,
        "segments": segments,
        "sentiments": ["positive", "neutral", "negative"],
        "emotions": ["excited", "satisfied", "curious", "neutral", "confused",
                     "concerned", "anxious", "frustrated", "angry", "sarcastic"],
        "granularities": ["hourly", "6-hourly", "daily", "weekly"],
        "ranges": ["1h", "6h", "12h", "24h", "3d", "7d", "all"],
        "data_range": {
            "start": bounds[0].isoformat() if bounds[0] else None,
            "end": bounds[1].isoformat() if bounds[1] else None,
        },
    }


# --------------------------------------------------------------------------- #
# Overview / dashboard
# --------------------------------------------------------------------------- #
@router.get("/overview", response_model=OverviewResponse, tags=["analytics"],
            dependencies=[Depends(require_dataset)])
def overview(
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> OverviewResponse:
    data = service.overview(filters)
    return OverviewResponse(
        **data,
        filters=filters.describe(),
        recommendations=service.recommendations(filters),
    )


@router.get("/sentiment/timeline", response_model=TimelineResponse, tags=["analytics"],
            dependencies=[Depends(require_dataset)])
def sentiment_timeline(
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> TimelineResponse:
    return TimelineResponse(**service.sentiment_timeline(filters), filters=filters.describe())


# --------------------------------------------------------------------------- #
# Trends
# --------------------------------------------------------------------------- #
@router.get("/trends", response_model=TrendsResponse, tags=["trends"],
            dependencies=[Depends(require_dataset)])
def trends(
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> TrendsResponse:
    return TrendsResponse(items=service.trends(filters), filters=filters.describe())


@router.get("/trends/{topic_id}", tags=["trends"], dependencies=[Depends(require_dataset)])
def trend_detail(
    topic_id: str,
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> dict:
    item = next((t for t in service.trends(filters) if t["topic_id"] == topic_id), None)
    if item is None:
        raise HTTPException(status_code=404, detail=f"No trend data for topic '{topic_id}'")
    return item


@router.get("/topics/{topic_id}", tags=["topics"], dependencies=[Depends(require_dataset)])
def topic_detail(
    topic_id: str,
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> dict:
    detail = service.topic_detail(topic_id, filters)
    if detail is None:
        raise HTTPException(status_code=404, detail=f"Unknown topic '{topic_id}'")
    return {**detail, "filters": filters.describe()}


@router.get("/topics/{topic_id}/journey", tags=["topics"],
            dependencies=[Depends(require_dataset)])
def topic_journey(topic_id: str, db: Session = Depends(get_db)) -> dict:
    from app.analytics.journey import build_journey

    if db.get(Topic, topic_id) is None:
        raise HTTPException(status_code=404, detail=f"Unknown topic '{topic_id}'")
    return build_journey(db, topic_id)


@router.get("/topics/{topic_id}/platforms", tags=["topics"],
            dependencies=[Depends(require_dataset)])
def topic_platforms(
    topic_id: str,
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> dict:
    """Cross-platform comparison and sentiment divergence for one topic."""
    scoped = AnalysisFilters(
        start=filters.start, end=filters.end, platforms=filters.platforms,
        topics=[topic_id], segments=filters.segments, sentiments=filters.sentiments,
        emotions=filters.emotions, search=filters.search, granularity=filters.granularity,
    )
    rows = service.filtered_posts(scoped)
    breakdown = service.platform_breakdown_for(rows)
    polarities = [p["avg_polarity"] for p in breakdown if p["posts"] >= 5]
    divergence = round(max(polarities) - min(polarities), 4) if len(polarities) >= 2 else 0.0
    return {
        "topic_id": topic_id,
        "platforms": breakdown,
        "divergence": divergence,
        "interpretation": (
            "The same narrative behaves differently by community. A response written for "
            "the most positive platform will not land on the most negative one."
            if divergence >= 0.25 else
            "Sentiment is broadly consistent across platforms for this topic."
        ),
        "flow": service.influence_flow(filters, topic_id),
    }


# --------------------------------------------------------------------------- #
# Audience
# --------------------------------------------------------------------------- #
@router.get("/audience", response_model=AudienceResponse, tags=["audience"],
            dependencies=[Depends(require_dataset)])
def audience(
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> AudienceResponse:
    return AudienceResponse(**service.audience(filters), filters=filters.describe())


@router.get("/audience/compare", tags=["audience"], dependencies=[Depends(require_dataset)])
def compare_segments(
    left: str = Query(..., description="Segment id"),
    right: str = Query(..., description="Segment id"),
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> dict:
    result = service.compare_segments(filters, left, right)
    if result.get("error"):
        raise HTTPException(status_code=404, detail="One or both segments were not found")
    return result


@router.get("/audience/{segment_id}", tags=["audience"],
            dependencies=[Depends(require_dataset)])
def segment_detail(
    segment_id: str,
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> dict:
    data = service.audience(filters)
    segment = next((s for s in data["segments"] if s["id"] == segment_id), None)
    if segment is None:
        raise HTTPException(status_code=404, detail=f"Unknown segment '{segment_id}'")
    return {**segment, "privacy_notice": data["privacy_notice"]}


# --------------------------------------------------------------------------- #
# Network
# --------------------------------------------------------------------------- #
@router.get("/network", response_model=NetworkResponse, tags=["network"],
            dependencies=[Depends(require_dataset)])
def network(
    max_nodes: int = Query(140, ge=20, le=400),
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> NetworkResponse:
    return NetworkResponse(**service.network(filters, max_nodes=max_nodes),
                           filters=filters.describe())


@router.get("/network/influencers", tags=["network"], dependencies=[Depends(require_dataset)])
def influencers(
    limit: int = Query(10, ge=1, le=50),
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> dict:
    return {"items": service.influencers(filters, limit=limit), "filters": filters.describe()}


@router.get("/network/flow/{topic_id}", tags=["network"],
            dependencies=[Depends(require_dataset)])
def influence_flow(
    topic_id: str,
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> dict:
    return service.influence_flow(filters, topic_id)


# --------------------------------------------------------------------------- #
# Intelligence & timeline
# --------------------------------------------------------------------------- #
@router.get("/intelligence", response_model=IntelligenceResponse, tags=["intelligence"],
            dependencies=[Depends(require_dataset)])
def intelligence(
    topic_id: str | None = Query(None),
    limit: int = Query(40, ge=1, le=100),
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> IntelligenceResponse:
    return IntelligenceResponse(
        items=service.intelligence(filters, topic_id=topic_id, limit=limit),
        filters=filters.describe(),
    )


@router.get("/intelligence/recommendations", tags=["intelligence"],
            dependencies=[Depends(require_dataset)])
def recommendations(
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> dict:
    return {"items": service.recommendations(filters), "filters": filters.describe()}


@router.get("/timeline", tags=["timeline"], dependencies=[Depends(require_dataset)])
def timeline(
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> dict:
    return {**service.timeline_events(filters), "filters": filters.describe()}


# --------------------------------------------------------------------------- #
# Posts & search
# --------------------------------------------------------------------------- #
@router.get("/posts", response_model=PostsResponse, tags=["data"],
            dependencies=[Depends(require_dataset)])
def posts(
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=5, le=100),
    sort: str = Query("recent", pattern="^(recent|engagement|sarcasm)$"),
    filters: AnalysisFilters = Depends(get_filters),
    service: AnalyticsService = Depends(get_service),
) -> PostsResponse:
    return PostsResponse(
        **service.posts(filters, page=page, page_size=page_size, sort=sort),
        filters=filters.describe(),
    )


@router.get("/search", tags=["data"], dependencies=[Depends(require_dataset)])
def search(
    q: str = Query(..., min_length=2, max_length=80),
    service: AnalyticsService = Depends(get_service),
) -> dict:
    return service.search(q)


# --------------------------------------------------------------------------- #
# Ingestion & analysis
# --------------------------------------------------------------------------- #
@router.get("/sources", response_model=SourcesResponse, tags=["ingestion"])
def sources(db: Session = Depends(get_db)) -> SourcesResponse:
    described = describe_sources(settings)
    stored = {s.id: s for s in db.execute(select(DataSource)).scalars()}
    for info in described:
        row = stored.get(info["id"])
        info["post_count"] = row.post_count if row else 0
    return SourcesResponse(
        sources=described,
        demo_mode=settings.demo_mode,
        last_run=AnalyticsService(db).latest_run(),
    )


@router.post("/ingestion/demo", response_model=IngestionResponse, tags=["ingestion"])
def load_demo(payload: IngestionRequest, db: Session = Depends(get_db)) -> IngestionResponse:
    """Load (or reload) the deterministic demo dataset and run the full pipeline."""
    if payload.seed is not None:
        settings.demo_seed = payload.seed
    if payload.target_posts is not None:
        settings.demo_post_target = payload.target_posts

    sources_to_use = payload.sources or ["demo"]
    try:
        pipeline = Pipeline(db)
        run = pipeline.run(sources_to_use, trigger="demo_load")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("Demo ingestion failed")
        raise HTTPException(
            status_code=500,
            detail="The analysis pipeline failed. See server logs for the failing stage.",
        ) from exc

    invalidate_cache()
    return IngestionResponse(
        status=run.status,
        run={
            "id": run.id, "seed": run.seed, "posts": run.posts_ingested,
            "authors": run.authors_ingested, "stages": run.stage_log,
            "model": run.sentiment_model,
        },
        validation=run.validation,
        message=(
            f"Loaded {run.posts_ingested} posts from {run.authors_ingested} accounts "
            f"and completed {len(run.stage_log)} pipeline stages."
        ),
    )


@router.post("/ingestion/reset", response_model=IngestionResponse, tags=["ingestion"])
def reset_demo(db: Session = Depends(get_db)) -> IngestionResponse:
    """Clear everything, regenerate deterministically and recompute analytics."""
    return load_demo(IngestionRequest(sources=["demo"]), db)


@router.post("/analyze", response_model=AnalyzeResponse, tags=["ai"])
def analyze(payload: AnalyzeRequest) -> AnalyzeResponse:
    """Run the NLP engine over arbitrary text.

    Useful for demonstrating sarcasm handling live, and for verifying that the
    same engine powers the stored results.
    """
    from app.analytics.demographics import confidence_band

    provider = get_ai_provider()
    try:
        result = provider.analyze_text(payload.text, payload.language)
    except Exception as exc:
        logger.exception("Ad-hoc analysis failed")
        raise HTTPException(
            status_code=503,
            detail="The AI provider is unavailable. The local engine is used as a fallback; "
                   "check AI_PROVIDER configuration.",
        ) from exc

    return AnalyzeResponse(
        text=payload.text,
        sentiment=result.sentiment,
        sentiment_confidence=result.sentiment_confidence,
        confidence_band=confidence_band(result.sentiment_confidence),
        stance=result.stance,
        emotion=result.emotion,
        emotion_confidence=result.emotion_confidence,
        polarity=result.polarity,
        literal_sentiment=result.literal_sentiment,
        contextual_sentiment=result.contextual_sentiment,
        sarcasm_detected=result.sarcasm_detected,
        sarcasm_confidence=result.sarcasm_confidence,
        cues=result.cues,
        model=result.model,
        model_version=result.model_version,
        status=result.status,
    )


@router.get("/runs/latest", tags=["system"])
def latest_run(service: AnalyticsService = Depends(get_service)) -> dict:
    run = service.latest_run()
    if run is None:
        raise HTTPException(status_code=404, detail="No analysis run has been recorded yet.")
    return run
