"""Link analysis and network topology (NetworkX).

Computes the standard centrality family plus community structure, and derives a
composite influence score. Bridge detection is done properly: an account is a
bridge when a large share of its edges cross community boundaries AND its
betweenness sits in the top decile - not merely when it is popular.

Large graphs are aggregated before they reach the API, so the frontend never
renders thousands of nodes.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass, field

import networkx as nx

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class Edge:
    source: str
    target: str
    kind: str
    weight: float = 1.0
    topic_id: str | None = None


@dataclass(slots=True)
class NodeMetrics:
    author_id: str
    degree: int = 0
    in_degree: int = 0
    out_degree: int = 0
    degree_centrality: float = 0.0
    betweenness: float = 0.0
    pagerank: float = 0.0
    influence_score: float = 0.0
    community_id: int = 0
    is_bridge: bool = False
    reach: int = 0
    cross_community_edges: int = 0
    bridge_ratio: float = 0.0
    rationale: list[str] = field(default_factory=list)


def build_graph(edges: list[Edge]) -> nx.DiGraph:
    graph = nx.DiGraph()
    for edge in edges:
        if edge.source == edge.target:
            continue  # self-interaction carries no relational information
        if graph.has_edge(edge.source, edge.target):
            data = graph[edge.source][edge.target]
            data["weight"] += edge.weight
            data["kinds"].add(edge.kind)
        else:
            graph.add_edge(edge.source, edge.target, weight=edge.weight, kinds={edge.kind})
    return graph


def _communities(graph: nx.DiGraph) -> dict[str, int]:
    """Greedy modularity communities over the undirected projection."""
    if graph.number_of_nodes() == 0:
        return {}
    undirected = graph.to_undirected()
    try:
        found = nx.community.greedy_modularity_communities(undirected, weight="weight")
    except Exception as exc:  # pragma: no cover - degenerate graphs
        logger.warning("Community detection fell back to connected components: %s", exc)
        found = list(nx.connected_components(undirected))

    mapping: dict[str, int] = {}
    for index, group in enumerate(sorted(found, key=len, reverse=True)):
        for node in group:
            mapping[node] = index
    return mapping


def compute_metrics(
    edges: list[Edge],
    follower_counts: dict[str, int] | None = None,
    betweenness_sample: int = 220,
) -> dict[str, NodeMetrics]:
    """Full network pass. Returns metrics keyed by author id."""
    graph = build_graph(edges)
    if graph.number_of_nodes() == 0:
        return {}

    follower_counts = follower_counts or {}
    n = graph.number_of_nodes()

    degree_centrality = nx.degree_centrality(graph)
    try:
        pagerank = nx.pagerank(graph, alpha=0.85, weight="weight", max_iter=200)
    except nx.PowerIterationFailedConvergence:  # pragma: no cover
        logger.warning("PageRank did not converge; falling back to degree centrality")
        pagerank = degree_centrality

    # Betweenness is computed on the undirected projection, matching the basis
    # used for community detection. On the directed graph an account that only
    # mentions others (out-edges, no in-edges) sits on no shortest path and
    # scores zero - which would systematically hide exactly the brokering
    # accounts bridge detection exists to find.
    undirected = graph.to_undirected()
    k = min(betweenness_sample, n) if n > betweenness_sample else None
    betweenness = nx.betweenness_centrality(
        undirected, k=k, weight="weight", normalized=True, seed=7
    )

    community = _communities(graph)

    max_pagerank = max(pagerank.values()) or 1.0
    max_betweenness = max(betweenness.values()) or 1.0
    max_followers = max(follower_counts.values()) if follower_counts else 1

    # Cross-community edge counting for honest bridge detection.
    cross_counts: dict[str, int] = defaultdict(int)
    total_counts: dict[str, int] = defaultdict(int)
    for source, target in graph.edges():
        total_counts[source] += 1
        total_counts[target] += 1
        if community.get(source) != community.get(target):
            cross_counts[source] += 1
            cross_counts[target] += 1

    betweenness_values = sorted(betweenness.values(), reverse=True)
    top_decile_cut = betweenness_values[max(0, len(betweenness_values) // 10 - 1)] if betweenness_values else 0.0

    results: dict[str, NodeMetrics] = {}
    for node in graph.nodes():
        followers = follower_counts.get(node, 0)
        pr = pagerank.get(node, 0.0)
        bt = betweenness.get(node, 0.0)

        # Composite influence: structural position dominates, audience size is a
        # supporting term. Both are normalised so the score reads 0..100.
        influence = (
            0.46 * (pr / max_pagerank)
            + 0.26 * (bt / max_betweenness)
            + 0.16 * degree_centrality.get(node, 0.0)
            + 0.12 * ((followers / max_followers) ** 0.5 if max_followers else 0.0)
        )

        cross = cross_counts.get(node, 0)
        total = total_counts.get(node, 0)
        ratio = cross / total if total else 0.0
        is_bridge = bool(ratio >= 0.4 and cross >= 3 and bt >= top_decile_cut and bt > 0)

        rationale: list[str] = []
        if pr / max_pagerank > 0.5:
            rationale.append("PageRank in the top tier of the graph")
        if is_bridge:
            rationale.append(
                f"{cross} of {total} interactions cross community boundaries"
            )
        if followers > 20000:
            rationale.append(f"public follower count {followers:,}")

        results[node] = NodeMetrics(
            author_id=node,
            degree=graph.degree(node),
            in_degree=graph.in_degree(node),
            out_degree=graph.out_degree(node),
            degree_centrality=round(degree_centrality.get(node, 0.0), 6),
            betweenness=round(bt, 6),
            pagerank=round(pr, 6),
            influence_score=round(influence * 100, 3),
            community_id=community.get(node, 0),
            is_bridge=is_bridge,
            reach=followers,
            cross_community_edges=cross,
            bridge_ratio=round(ratio, 3),
            rationale=rationale,
        )
    return results


def aggregate_for_display(
    metrics: dict[str, NodeMetrics],
    edges: list[Edge],
    max_nodes: int = 140,
) -> dict:
    """Reduce the graph to a renderable size without distorting structure.

    Keeps the highest-influence nodes plus every bridge, then keeps only edges
    whose endpoints both survived. The dropped mass is reported so the UI can
    state what is being shown.
    """
    if not metrics:
        return {"nodes": [], "edges": [], "truncated": False,
                "total_nodes": 0, "total_edges": 0}

    ranked = sorted(metrics.values(), key=lambda m: m.influence_score, reverse=True)
    keep = {m.author_id for m in ranked[:max_nodes]}
    keep.update(m.author_id for m in ranked if m.is_bridge)

    kept_edges = [e for e in edges if e.source in keep and e.target in keep]
    merged: dict[tuple[str, str], dict] = {}
    for edge in kept_edges:
        key = (edge.source, edge.target)
        entry = merged.setdefault(key, {"source": edge.source, "target": edge.target,
                                        "weight": 0.0, "kinds": set()})
        entry["weight"] += edge.weight
        entry["kinds"].add(edge.kind)

    return {
        "nodes": [m for m in ranked if m.author_id in keep],
        "edges": [
            {"source": v["source"], "target": v["target"],
             "weight": round(v["weight"], 2), "kinds": sorted(v["kinds"])}
            for v in merged.values()
        ],
        "truncated": len(keep) < len(metrics),
        "total_nodes": len(metrics),
        "total_edges": len(edges),
    }


def propagation_path(
    edges: list[Edge],
    metrics: dict[str, NodeMetrics],
    topic_id: str,
    origin: str | None = None,
    max_hops: int = 4,
) -> list[dict]:
    """Observed propagation for a topic: the ordered set of communities the
    interaction wave passes through. Presented as observation, never as proof of
    causation."""
    topic_edges = [e for e in edges if e.topic_id == topic_id]
    if not topic_edges:
        return []

    graph = build_graph(topic_edges)
    if origin is None or origin not in graph:
        candidates = [n for n in graph.nodes() if n in metrics]
        if not candidates:
            return []
        origin = max(candidates, key=lambda n: metrics[n].influence_score)

    layers: list[dict] = []
    seen = {origin}
    frontier = [origin]
    for hop in range(max_hops):
        nxt: list[str] = []
        for node in frontier:
            for neighbour in graph.successors(node):
                if neighbour not in seen:
                    seen.add(neighbour)
                    nxt.append(neighbour)
        if not nxt:
            break
        communities = defaultdict(int)
        for node in nxt:
            communities[metrics[node].community_id if node in metrics else 0] += 1
        layers.append({
            "hop": hop + 1,
            "accounts": len(nxt),
            "communities": [
                {"community_id": cid, "accounts": count}
                for cid, count in sorted(communities.items(), key=lambda kv: -kv[1])
            ],
            "sample_nodes": nxt[:6],
        })
        frontier = nxt
    return layers
