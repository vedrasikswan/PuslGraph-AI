"""Source registry: builds adapters from settings and reports their real status."""

from __future__ import annotations

import logging

from app.config import Settings, settings as default_settings
from app.ingestion.adapters import (
    FacebookAdapter,
    InstagramAdapter,
    RedditAdapter,
    TelegramAdapter,
    XAdapter,
    YouTubeAdapter,
)
from app.ingestion.base import DataSourceAdapter, SourceStatus
from app.ingestion.demo_adapter import DemoDataAdapter

logger = logging.getLogger(__name__)

ADAPTER_CLASSES: dict[str, type[DataSourceAdapter]] = {
    "x": XAdapter,
    "telegram": TelegramAdapter,
    "instagram": InstagramAdapter,
    "facebook": FacebookAdapter,
    "reddit": RedditAdapter,
    "youtube": YouTubeAdapter,
}

PLATFORM_ORDER = ["x", "telegram", "instagram", "facebook", "reddit", "youtube"]


def build_adapter(source_id: str, cfg: Settings | None = None) -> DataSourceAdapter:
    cfg = cfg or default_settings
    if source_id == "demo":
        return DemoDataAdapter(seed=cfg.demo_seed, target_posts=cfg.demo_post_target)
    cls = ADAPTER_CLASSES.get(source_id)
    if cls is None:
        raise KeyError(f"Unknown data source '{source_id}'")
    creds = {field: getattr(cfg, field, "") for field in cls.credential_fields}
    return cls(creds)


def all_adapters(cfg: Settings | None = None) -> list[DataSourceAdapter]:
    cfg = cfg or default_settings
    return [build_adapter(sid, cfg) for sid in PLATFORM_ORDER]


def describe_sources(cfg: Settings | None = None) -> list[dict]:
    """Status of every configured source.

    A platform with no credentials is reported as `demo` only because demo data
    exists for it - the `live_ready` flag stays False so the UI never implies a
    real connection.
    """
    cfg = cfg or default_settings
    out: list[dict] = []
    for adapter in all_adapters(cfg):
        info = adapter.describe()
        live_ready = info["status"] == SourceStatus.CONNECTED.value
        info["live_ready"] = live_ready
        info["status"] = info["status"] if live_ready else SourceStatus.DEMO.value
        info["demo_available"] = True
        out.append(info)

    demo = DemoDataAdapter(seed=cfg.demo_seed, target_posts=cfg.demo_post_target)
    demo_info = demo.describe()
    demo_info.update({"live_ready": False, "demo_available": True, "status": "demo"})
    out.append(demo_info)
    return out
