'use client';

/** Global search across topics, segments, accounts, platforms, events and posts. */

import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2, Search } from 'lucide-react';

import { api } from '@/lib/api';
import { cx } from '@/components/ui/primitives';
import { titleCase } from '@/lib/format';
import type { SearchResult } from '@/types/api';

const TYPE_TONES: Record<SearchResult['type'], string> = {
  topic: 'text-trend',
  segment: 'text-influence',
  account: 'text-warning',
  platform: 'text-ink-muted',
  event: 'text-negative',
  post: 'text-ink-faint',
};

export function GlobalSearch() {
  const router = useRouter();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [highlight, setHighlight] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (query.trim().length < 2) {
      setResults([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    const timer = setTimeout(() => {
      let cancelled = false;
      api
        .search(query.trim())
        .then((data) => {
          if (!cancelled) {
            setResults(data.results);
            setHighlight(0);
            setOpen(true);
          }
        })
        .catch(() => {
          if (!cancelled) setResults([]);
        })
        .finally(() => {
          if (!cancelled) setLoading(false);
        });
      return () => {
        cancelled = true;
      };
    }, 220);
    return () => clearTimeout(timer);
  }, [query]);

  useEffect(() => {
    function onClickAway(event: MouseEvent) {
      if (!containerRef.current?.contains(event.target as Node)) setOpen(false);
    }
    function onHotkey(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key === 'k') {
        event.preventDefault();
        inputRef.current?.focus();
      }
    }
    document.addEventListener('mousedown', onClickAway);
    document.addEventListener('keydown', onHotkey);
    return () => {
      document.removeEventListener('mousedown', onClickAway);
      document.removeEventListener('keydown', onHotkey);
    };
  }, []);

  function go(result: SearchResult) {
    setOpen(false);
    setQuery('');
    router.push(result.href);
  }

  function onKeyDown(event: React.KeyboardEvent) {
    if (!open || !results.length) return;
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      setHighlight((h) => (h + 1) % results.length);
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      setHighlight((h) => (h - 1 + results.length) % results.length);
    } else if (event.key === 'Enter') {
      event.preventDefault();
      const target = results[highlight];
      if (target) go(target);
    } else if (event.key === 'Escape') {
      setOpen(false);
    }
  }

  return (
    <div ref={containerRef} className="relative">
      <div className="relative">
        <Search
          className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-ink-faint"
          aria-hidden
        />
        <input
          ref={inputRef}
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => results.length && setOpen(true)}
          onKeyDown={onKeyDown}
          placeholder="Search topics, accounts, events…"
          aria-label="Global search"
          className={cx(
            'w-40 rounded border border-edge bg-canvas-sunken py-1.5 pl-7 pr-7 text-2xs text-ink',
            'placeholder:text-ink-faint focus:w-64 focus:border-edge-strong',
            'transition-[width] duration-200 lg:w-56 lg:focus:w-72',
          )}
        />
        {loading && (
          <Loader2
            className="absolute right-2 top-1/2 h-3 w-3 -translate-y-1/2 animate-spin text-ink-faint"
            aria-hidden
          />
        )}
      </div>

      {open && results.length > 0 && (
        <ul
          role="listbox"
          aria-label="Search results"
          className="absolute right-0 top-full z-50 mt-1 max-h-96 w-96 overflow-y-auto rounded border border-edge-strong bg-canvas-raised py-1 shadow-2xl"
        >
          {results.map((result, index) => (
            <li key={`${result.type}-${result.id}`}>
              <button
                type="button"
                role="option"
                aria-selected={index === highlight}
                onMouseEnter={() => setHighlight(index)}
                onClick={() => go(result)}
                className={cx(
                  'flex w-full items-start gap-2 px-2.5 py-1.5 text-left',
                  index === highlight ? 'bg-canvas-hover' : 'hover:bg-canvas-hover/60',
                )}
              >
                <span
                  className={cx(
                    'mt-0.5 shrink-0 text-[9px] font-semibold uppercase tracking-wider',
                    TYPE_TONES[result.type],
                  )}
                >
                  {titleCase(result.type)}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-2xs text-ink">{result.label}</span>
                  <span className="block truncate text-[10px] text-ink-faint">{result.detail}</span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}

      {open && !loading && query.trim().length >= 2 && results.length === 0 && (
        <div className="absolute right-0 top-full z-50 mt-1 w-72 rounded border border-edge-strong bg-canvas-raised px-3 py-2.5 text-2xs text-ink-faint shadow-2xl">
          No matches for “{query.trim()}”.
        </div>
      )}
    </div>
  );
}
