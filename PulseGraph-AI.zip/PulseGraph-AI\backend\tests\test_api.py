"""HTTP contract: shapes the frontend depends on, and error handling."""

from __future__ import annotations


class TestSystemEndpoints:
    def test_health_reports_readiness(self, api_client):
        body = api_client.get("/api/health").json()
        assert body["status"] in {"ok", "degraded"}
        assert body["dataset_ready"] is True
        assert body["posts"] > 0
        assert body["ai_provider"]["provider"]
        assert body["last_run"]["status"] in {"completed", "completed_with_warnings"}

    def test_root_describes_the_product(self, api_client):
        body = api_client.get("/").json()
        assert body["name"] == "PulseGraph AI"
        assert "tagline" in body

    def test_openapi_schema_is_served(self, api_client):
        assert api_client.get("/openapi.json").status_code == 200

    def test_filter_options_come_from_stored_data(self, api_client):
        body = api_client.get("/api/meta/filters").json()
        assert body["platforms"] and body["topics"] and body["segments"]
        assert "hourly" in body["granularities"]
        assert body["data_range"]["start"] and body["data_range"]["end"]


class TestOverview:
    def test_returns_kpis_and_pulse(self, api_client):
        body = api_client.get("/api/overview").json()
        assert body["empty"] is False
        keys = {k["key"] for k in body["kpis"]}
        assert {"total_posts", "active_authors", "engagement", "positive_share",
                "negative_share", "trending_topics", "influential_nodes"} <= keys
        assert body["pulse"]["statement"]
        assert body["pulse"]["evidence"]
        assert body["recommendations"]
        assert body["filters"]["active"] is False

    def test_sentiment_distribution_sums_to_one_hundred(self, api_client):
        body = api_client.get("/api/overview").json()
        total = sum(d["percentage"] for d in body["sentiment_distribution"])
        assert 99.0 <= total <= 101.0

    def test_filters_are_echoed_back(self, api_client):
        body = api_client.get("/api/overview?platforms=x,telegram&range=24h").json()
        assert body["filters"]["platforms"] == ["x", "telegram"]
        assert body["filters"]["active"] is True

    def test_relative_range_narrows_the_window(self, api_client):
        full = api_client.get("/api/overview").json()
        recent = api_client.get("/api/overview?range=6h").json()
        full_posts = next(k["value"] for k in full["kpis"] if k["key"] == "total_posts")
        recent_posts = next(k["value"] for k in recent["kpis"] if k["key"] == "total_posts")
        assert recent_posts < full_posts


class TestAnalyticalEndpoints:
    def test_sentiment_timeline_shape(self, api_client):
        body = api_client.get("/api/sentiment/timeline?granularity=hourly").json()
        assert body["granularity"] == "hourly"
        assert body["points"]
        point = body["points"][0]
        for field in ("ts", "positive", "negative", "neutral", "total", "avg_polarity"):
            assert field in point

    def test_trends_are_ranked_and_explainable(self, api_client):
        body = api_client.get("/api/trends").json()
        items = body["items"]
        assert items
        scores = [i["trend_score"] for i in items]
        assert scores == sorted(scores, reverse=True)
        top = items[0]
        assert top["components"]["formula"]
        assert top["velocity"]["growth_percentage"] is not None
        assert top["momentum"]["confidence_band"] in {"High", "Medium", "Low"}

    def test_topic_detail_includes_journey_and_audience(self, api_client):
        body = api_client.get("/api/topics/battery-drain").json()
        assert body["topic"]["label"]
        assert body["journey"]["milestones"]
        assert body["audience"]["segments"]
        assert body["top_accounts"]
        assert body["platforms"]
        assert body["keywords"]

    def test_topic_platform_comparison_reports_divergence(self, api_client):
        body = api_client.get("/api/topics/battery-drain/platforms").json()
        assert body["platforms"]
        assert "divergence" in body
        assert body["interpretation"]
        assert body["flow"]["disclaimer"]

    def test_audience_exposes_segments_with_privacy_notice(self, api_client):
        body = api_client.get("/api/audience").json()
        assert body["segments"]
        assert body["demographics"]["age_brackets"]
        assert "not verified personal attributes" in body["privacy_notice"]
        for row in body["demographics"]["age_brackets"]:
            assert row["confidence_band"] in {"High", "Medium", "Low"}

    def test_segment_comparison(self, api_client):
        segments = api_client.get("/api/audience").json()["segments"]
        assert len(segments) >= 2
        left, right = segments[0]["id"], segments[1]["id"]
        body = api_client.get(f"/api/audience/compare?left={left}&right={right}").json()
        assert body["left"]["id"] == left and body["right"]["id"] == right
        assert "polarity_gap" in body
        assert body["metrics"]["size"]["left"] is not None

    def test_network_graph_is_aggregated_for_rendering(self, api_client):
        body = api_client.get("/api/network?max_nodes=60").json()
        assert body["nodes"]
        assert body["displayed_nodes"] <= body["total_nodes"]
        node = body["nodes"][0]
        for field in ("anon_id", "influence_score", "community_id", "is_bridge",
                      "segment_name", "segment_color"):
            assert field in node
        ids = {n["id"] for n in body["nodes"]}
        for edge in body["edges"]:
            assert edge["source"] in ids and edge["target"] in ids

    def test_network_nodes_are_pseudonymous(self, api_client):
        body = api_client.get("/api/network?max_nodes=40").json()
        for node in body["nodes"]:
            assert node["anon_id"].startswith("A")

    def test_influencer_ranking(self, api_client):
        body = api_client.get("/api/network/influencers?limit=10").json()
        items = body["items"]
        assert 1 <= len(items) <= 10
        assert [i["rank"] for i in items] == list(range(1, len(items) + 1))
        scores = [i["influence_score"] for i in items]
        assert scores == sorted(scores, reverse=True)
        for item in items:
            assert "community_id" in item and "segment" in item

    def test_intelligence_cards_carry_evidence(self, api_client):
        body = api_client.get("/api/intelligence").json()
        assert body["items"]
        for card in body["items"]:
            assert card["evidence"]
            assert card["confidence_band"] in {"High", "Medium", "Low"}
            assert card["severity"] in {"critical", "high", "medium", "low", "info"}

    def test_intelligence_can_be_scoped_to_a_topic(self, api_client):
        body = api_client.get("/api/intelligence?topic_id=battery-drain").json()
        assert body["items"]
        assert all(c["topic_id"] == "battery-drain" for c in body["items"])

    def test_timeline_merges_events_and_buckets(self, api_client):
        body = api_client.get("/api/timeline").json()
        assert body["events"] and body["buckets"]
        timestamps = [e["ts"] for e in body["events"]]
        assert timestamps == sorted(timestamps, reverse=True)

    def test_posts_are_paginated_with_analysis_attached(self, api_client):
        body = api_client.get("/api/posts?page=1&page_size=10").json()
        assert len(body["items"]) == 10
        assert body["pages"] > 1
        item = body["items"][0]
        assert item["author_anon_id"].startswith("A")
        assert item["analysis"]["sentiment"]
        assert item["analysis"]["model"]

    def test_posts_sorted_by_sarcasm_surface_flagged_items_first(self, api_client):
        body = api_client.get("/api/posts?sort=sarcasm&page_size=5").json()
        assert body["items"][0]["analysis"]["sarcasm_detected"] is True

    def test_search_returns_linkable_results(self, api_client):
        body = api_client.get("/api/search?q=battery").json()
        assert body["results"]
        for result in body["results"]:
            assert result["href"].startswith("/")
            assert result["type"] in {"topic", "segment", "account", "platform", "event", "post"}


class TestSourcesAndIngestion:
    def test_sources_lists_every_required_platform(self, api_client):
        body = api_client.get("/api/sources").json()
        platforms = {s["platform"] for s in body["sources"]}
        assert {"x", "telegram", "instagram", "facebook", "reddit", "youtube"} <= platforms

    def test_sources_never_claim_a_live_connection_without_credentials(self, api_client):
        body = api_client.get("/api/sources").json()
        for source in body["sources"]:
            if source["requires_credentials"] and source["missing_credentials"]:
                assert source["live_ready"] is False
                assert source["status"] != "connected"

    def test_analyze_endpoint_demonstrates_sarcasm_reasoning(self, api_client):
        response = api_client.post("/api/analyze", json={
            "text": "Great, another three-hour outage. Amazing service.",
        })
        body = response.json()
        assert response.status_code == 200
        assert body["literal_sentiment"] == "positive"
        assert body["contextual_sentiment"] == "negative"
        assert body["sarcasm_detected"] is True
        assert body["cues"]["sarcasm_signals"]
        assert body["model"]

    def test_analyze_rejects_empty_payload(self, api_client):
        assert api_client.post("/api/analyze", json={"text": ""}).status_code == 422

    def test_latest_run_is_exposed(self, api_client):
        body = api_client.get("/api/runs/latest").json()
        assert body["stage_log"]
        assert body["validation"]


class TestErrorHandling:
    def test_unknown_topic_returns_404(self, api_client):
        response = api_client.get("/api/topics/not-a-topic")
        assert response.status_code == 404
        assert "detail" in response.json()

    def test_unknown_segment_returns_404(self, api_client):
        assert api_client.get("/api/audience/not-a-segment").status_code == 404

    def test_invalid_granularity_is_rejected_with_guidance(self, api_client):
        response = api_client.get("/api/overview?granularity=fortnightly")
        assert response.status_code == 422
        assert "granularity" in str(response.json()).lower()

    def test_inverted_date_range_is_rejected(self, api_client):
        response = api_client.get(
            "/api/overview?start=2026-08-24T00:00:00&end=2026-08-01T00:00:00")
        assert response.status_code == 422

    def test_invalid_relative_range_is_rejected(self, api_client):
        assert api_client.get("/api/overview?range=99y").status_code == 422

    def test_out_of_bounds_pagination_returns_empty_page_not_error(self, api_client):
        body = api_client.get("/api/posts?page=9999&page_size=10").json()
        assert body["items"] == []
        assert body["total"] > 0

    def test_short_search_query_is_rejected(self, api_client):
        assert api_client.get("/api/search?q=a").status_code == 422

    def test_no_stack_trace_is_ever_returned(self, api_client):
        for path in ["/api/topics/nope", "/api/overview?granularity=bad",
                     "/api/search?q=a", "/api/audience/nope"]:
            text = api_client.get(path).text
            assert "Traceback" not in text
            assert "sqlalchemy" not in text.lower()
