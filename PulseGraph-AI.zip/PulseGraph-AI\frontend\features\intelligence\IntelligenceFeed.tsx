'use client';

/**
 * AI Intelligence Feed.
 *
 * Each card is a detection with its severity, window, affected audience,
 * involved accounts, platforms and the evidence that triggered it. Cards are
 * clickable: they open the analytical context they describe rather than just
 * dismissing.
 */

import { useMemo, useState } from 'react';
import Link from 'next/link';
import {
  ArrowUpRight,
  Layers,
  MessageSquareWarning,
  Network,
  Radio,
  Split,
  TrendingDown,
  TrendingUp,
  Users,
  Zap,
} from 'lucide-react';

import { WhyPanel } from '@/components/ui/Evidence';
import {
  Badge,
  ConfidenceBadge,
  EmptyState,
  Panel,
  PanelSkeleton,
  SeverityBadge,
  cx,
} from '@/components/ui/primitives';
import { SEVERITY_STYLES } from '@/lib/colors';
import { dateTime, platformLabel, relativeTime, titleCase } from '@/lib/format';
import type { IntelligenceCard, Severity } from '@/types/api';

import { useFilters } from '../filters/FilterContext';

const CATEGORY_ICONS: Record<string, typeof Zap> = {
  sentiment_spike: MessageSquareWarning,
  trend_acceleration: TrendingUp,
  declining_trend: TrendingDown,
  emerging_topic: Radio,
  cross_platform_spread: Layers,
  sentiment_divergence: Split,
  influencer_amplification: Zap,
  segment_shift: Users,
  bridge_discovery: Network,
  sarcasm_load: MessageSquareWarning,
};

const SEVERITY_RANK: Record<Severity, number> = {
  critical: 0,
  high: 1,
  medium: 2,
  low: 3,
  info: 4,
};

export function IntelligenceCardView({ card }: { card: IntelligenceCard }) {
  const { toggle, filters } = useFilters();
  const Icon = CATEGORY_ICONS[card.category] ?? Zap;
  const style = SEVERITY_STYLES[card.severity];

  return (
    <article
      className={cx(
        'border-b border-edge-subtle px-4 py-3 last:border-0',
        'transition-colors hover:bg-canvas-hover/40',
      )}
    >
      <div className="flex items-start gap-2.5">
        <span
          className={cx('mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded', style.bg)}
          aria-hidden
        >
          <Icon className={cx('h-3.5 w-3.5', style.text)} />
        </span>

        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <h3 className="text-[13px] font-medium leading-snug text-ink">{card.title}</h3>
            <SeverityBadge severity={card.severity} />
            <ConfidenceBadge band={card.confidence_band} value={card.confidence} />
          </div>

          <p className="mt-1.5 text-2xs leading-relaxed text-ink-muted">{card.summary}</p>

          <div className="mt-2 flex flex-wrap items-center gap-1">
            <Badge tone="neutral" title={dateTime(card.detected_at)}>
              {relativeTime(card.detected_at)}
            </Badge>

            <Badge tone="neutral">{titleCase(card.category)}</Badge>

            {card.topic_id && (
              <Link href={`/topics/${card.topic_id}`} className="group">
                <Badge tone="trend" className="group-hover:border-trend/60">
                  {card.topic_label ?? card.topic_id}
                  <ArrowUpRight className="h-2.5 w-2.5" aria-hidden />
                </Badge>
              </Link>
            )}

            {card.affected_segments.map((segment) => (
              <Badge key={segment} tone="influence">
                {segment}
              </Badge>
            ))}

            {card.affected_platforms.slice(0, 5).map((platform) => (
              <button
                key={platform}
                type="button"
                onClick={() => toggle('platforms', platform)}
                title={`Filter dashboard to ${platformLabel(platform)}`}
              >
                <Badge tone={filters.platforms.includes(platform) ? 'trend' : 'neutral'}>
                  {platformLabel(platform)}
                </Badge>
              </button>
            ))}
          </div>

          {card.related_nodes.length > 0 && (
            <div className="mt-2 rounded border border-edge-subtle bg-canvas-sunken px-2.5 py-2">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-faint">
                Accounts involved
              </p>
              <ul className="mt-1 flex flex-wrap gap-1.5">
                {card.related_nodes.slice(0, 6).map((node) => (
                  <li key={node.anon_id}>
                    <Link href={`/network?node=${encodeURIComponent(node.anon_id)}`}>
                      <Badge tone={node.is_bridge ? 'warning' : 'neutral'}>
                        {node.anon_id}
                        {node.influence_score !== undefined && (
                          <span className="font-mono opacity-70">
                            {node.influence_score.toFixed(0)}
                          </span>
                        )}
                        {node.is_bridge && <span className="opacity-70">bridge</span>}
                      </Badge>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {card.recommended_action && (
            <p className="mt-2 border-l-2 border-edge-strong pl-2.5 text-2xs leading-relaxed text-ink-muted">
              <span className="font-medium text-ink-faint">Interpretation: </span>
              {card.recommended_action}
            </p>
          )}

          <WhyPanel
            evidence={card.evidence}
            confidence={card.confidence}
            confidenceBand={card.confidence_band}
            drivers={card.drivers}
            source={card.interpretation_source}
          />
        </div>
      </div>
    </article>
  );
}

export function IntelligenceFeed({
  cards,
  loading,
  limit,
  title = 'AI Intelligence Feed',
  subtitle = 'Detections ranked by severity, each with the metrics that triggered it',
}: {
  cards: IntelligenceCard[] | null;
  loading?: boolean;
  limit?: number;
  title?: string;
  subtitle?: string;
}) {
  const [severityFilter, setSeverityFilter] = useState<Severity | 'all'>('all');

  const visible = useMemo(() => {
    if (!cards) return null;
    const filtered =
      severityFilter === 'all' ? cards : cards.filter((c) => c.severity === severityFilter);
    const sorted = [...filtered].sort(
      (a, b) =>
        SEVERITY_RANK[a.severity] - SEVERITY_RANK[b.severity] || b.confidence - a.confidence,
    );
    return limit ? sorted.slice(0, limit) : sorted;
  }, [cards, severityFilter, limit]);

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: cards?.length ?? 0 };
    for (const card of cards ?? []) {
      map[card.severity] = (map[card.severity] ?? 0) + 1;
    }
    return map;
  }, [cards]);

  return (
    <Panel
      title={title}
      subtitle={subtitle}
      dense
      actions={
        <div className="flex items-center gap-0.5">
          {(['all', 'critical', 'high', 'medium', 'info'] as const).map((level) => {
            const count = counts[level] ?? 0;
            if (level !== 'all' && count === 0) return null;
            return (
              <button
                key={level}
                type="button"
                onClick={() => setSeverityFilter(level as Severity | 'all')}
                className={cx(
                  'rounded px-1.5 py-0.5 text-2xs transition-colors',
                  severityFilter === level
                    ? 'bg-canvas-hover text-ink'
                    : 'text-ink-faint hover:text-ink-muted',
                )}
              >
                {level === 'all' ? 'All' : titleCase(level)}
                <span className="ml-1 font-mono opacity-60">{count}</span>
              </button>
            );
          })}
        </div>
      }
    >
      {loading && (
        <div className="p-4">
          <PanelSkeleton rows={5} height="h-14" />
        </div>
      )}

      {!loading && visible && visible.length === 0 && (
        <EmptyState
          title="No detections for this selection"
          description="No metric crossed a detection threshold under the current filters. Widen the range, or clear a filter to see everything the engine found."
        />
      )}

      {!loading &&
        visible?.map((card) => <IntelligenceCardView key={card.id} card={card} />)}
    </Panel>
  );
}
