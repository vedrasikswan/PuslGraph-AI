"""Relational model for PulseGraph AI.

Design rule: every analytical artefact is traceable back to the source rows it
was derived from. Sentiment rows point at a post, network rows point at an
author, trend rows point at a topic + time window, and intelligence events
carry an explicit evidence payload naming the metrics that triggered them.
"""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    JSON,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    pass


# --------------------------------------------------------------------------- #
# Sources
# --------------------------------------------------------------------------- #
class DataSource(Base):
    __tablename__ = "data_sources"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    platform: Mapped[str] = mapped_column(String(32), index=True)
    display_name: Mapped[str] = mapped_column(String(96))
    tier: Mapped[str] = mapped_column(String(24), default="essential")
    status: Mapped[str] = mapped_column(String(24), default="not_connected")
    requires_credentials: Mapped[bool] = mapped_column(Boolean, default=True)
    credential_fields: Mapped[list] = mapped_column(JSON, default=list)
    capabilities: Mapped[list] = mapped_column(JSON, default=list)
    notes: Mapped[str] = mapped_column(Text, default="")
    last_sync_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    post_count: Mapped[int] = mapped_column(Integer, default=0)


# --------------------------------------------------------------------------- #
# Core social data
# --------------------------------------------------------------------------- #
class Author(Base):
    """A public account. Stored pseudonymously for analytical display."""

    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(96), primary_key=True)
    platform: Mapped[str] = mapped_column(String(32), index=True)
    anon_id: Mapped[str] = mapped_column(String(32), index=True)
    display_name: Mapped[str] = mapped_column(String(128))
    handle: Mapped[str] = mapped_column(String(128), default="")
    bio: Mapped[str] = mapped_column(Text, default="")
    followers_count: Mapped[int] = mapped_column(Integer, default=0)
    following_count: Mapped[int] = mapped_column(Integer, default=0)
    verified: Mapped[bool] = mapped_column(Boolean, default=False)
    account_created_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    location_raw: Mapped[str] = mapped_column(String(96), default="")
    primary_language: Mapped[str] = mapped_column(String(16), default="en")
    post_count: Mapped[int] = mapped_column(Integer, default=0)

    posts: Mapped[list["Post"]] = relationship(back_populates="author")


class Post(Base):
    __tablename__ = "posts"

    id: Mapped[str] = mapped_column(String(96), primary_key=True)
    platform: Mapped[str] = mapped_column(String(32), index=True)
    source_id: Mapped[str] = mapped_column(String(64), default="")
    author_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    text: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    language: Mapped[str] = mapped_column(String(16), default="en")
    reply_to_id: Mapped[str | None] = mapped_column(String(96), nullable=True, index=True)
    parent_post_id: Mapped[str | None] = mapped_column(String(96), nullable=True, index=True)
    hashtags: Mapped[list] = mapped_column(JSON, default=list)
    mentions: Mapped[list] = mapped_column(JSON, default=list)
    likes: Mapped[int] = mapped_column(Integer, default=0)
    comments_count: Mapped[int] = mapped_column(Integer, default=0)
    shares: Mapped[int] = mapped_column(Integer, default=0)
    views: Mapped[int] = mapped_column(Integer, default=0)
    engagement_count: Mapped[int] = mapped_column(Integer, default=0, index=True)
    location: Mapped[str] = mapped_column(String(96), default="")
    ingested_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    author: Mapped["Author"] = relationship(back_populates="posts")
    sentiment: Mapped["SentimentResult | None"] = relationship(
        back_populates="post", uselist=False, cascade="all, delete-orphan"
    )

    __table_args__ = (Index("ix_posts_platform_created", "platform", "created_at"),)


class Interaction(Base):
    """Directed edge in the participation graph."""

    __tablename__ = "interactions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    source_author_id: Mapped[str] = mapped_column(String(96), index=True)
    target_author_id: Mapped[str] = mapped_column(String(96), index=True)
    interaction_type: Mapped[str] = mapped_column(String(24), index=True)
    post_id: Mapped[str] = mapped_column(String(96), index=True)
    platform: Mapped[str] = mapped_column(String(32), index=True)
    topic_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    weight: Mapped[float] = mapped_column(Float, default=1.0)


class Topic(Base):
    __tablename__ = "topics"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    label: Mapped[str] = mapped_column(String(128))
    description: Mapped[str] = mapped_column(Text, default="")
    keywords: Mapped[list] = mapped_column(JSON, default=list)
    hashtags: Mapped[list] = mapped_column(JSON, default=list)
    first_seen_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_seen_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    post_count: Mapped[int] = mapped_column(Integer, default=0)


class PostTopic(Base):
    __tablename__ = "post_topics"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    post_id: Mapped[str] = mapped_column(String(96), index=True)
    topic_id: Mapped[str] = mapped_column(String(64), index=True)
    relevance: Mapped[float] = mapped_column(Float, default=1.0)
    is_primary: Mapped[bool] = mapped_column(Boolean, default=False)

    __table_args__ = (UniqueConstraint("post_id", "topic_id", name="uq_post_topic"),)


# --------------------------------------------------------------------------- #
# Analytical results
# --------------------------------------------------------------------------- #
class SentimentResult(Base):
    __tablename__ = "sentiment_results"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    post_id: Mapped[str] = mapped_column(ForeignKey("posts.id"), unique=True, index=True)
    sentiment: Mapped[str] = mapped_column(String(24), index=True)
    sentiment_confidence: Mapped[float] = mapped_column(Float, default=0.0)
    emotion: Mapped[str] = mapped_column(String(24), index=True)
    emotion_confidence: Mapped[float] = mapped_column(Float, default=0.0)
    stance: Mapped[str] = mapped_column(String(24), default="neutral")
    polarity: Mapped[float] = mapped_column(Float, default=0.0, index=True)
    literal_sentiment: Mapped[str] = mapped_column(String(24), default="neutral")
    contextual_sentiment: Mapped[str] = mapped_column(String(24), default="neutral")
    sarcasm_detected: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    sarcasm_confidence: Mapped[float] = mapped_column(Float, default=0.0)
    cues: Mapped[dict] = mapped_column(JSON, default=dict)
    model: Mapped[str] = mapped_column(String(64), default="")
    model_version: Mapped[str] = mapped_column(String(32), default="")
    status: Mapped[str] = mapped_column(String(24), default="ok")
    analyzed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    post: Mapped["Post"] = relationship(back_populates="sentiment")


class DemographicProfile(Base):
    """Inferred, aggregate-oriented profile. Never presented as verified identity."""

    __tablename__ = "demographic_profiles"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    author_id: Mapped[str] = mapped_column(String(96), unique=True, index=True)
    age_bracket: Mapped[str] = mapped_column(String(16), index=True)
    age_confidence: Mapped[float] = mapped_column(Float, default=0.0)
    region: Mapped[str] = mapped_column(String(64), index=True)
    region_confidence: Mapped[float] = mapped_column(Float, default=0.0)
    language: Mapped[str] = mapped_column(String(16), index=True)
    professional_interest: Mapped[str] = mapped_column(String(64), index=True)
    interest_confidence: Mapped[float] = mapped_column(Float, default=0.0)
    engagement_behaviour: Mapped[str] = mapped_column(String(32), default="observer")
    evidence: Mapped[list] = mapped_column(JSON, default=list)
    model: Mapped[str] = mapped_column(String(64), default="")
    model_version: Mapped[str] = mapped_column(String(32), default="")
    computed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class AudienceSegment(Base):
    __tablename__ = "audience_segments"

    id: Mapped[str] = mapped_column(String(48), primary_key=True)
    name: Mapped[str] = mapped_column(String(96))
    description: Mapped[str] = mapped_column(Text, default="")
    color: Mapped[str] = mapped_column(String(16), default="#64748b")
    size: Mapped[int] = mapped_column(Integer, default=0)
    dominant_sentiment: Mapped[str] = mapped_column(String(24), default="neutral")
    avg_polarity: Mapped[float] = mapped_column(Float, default=0.0)
    engagement_level: Mapped[str] = mapped_column(String(24), default="medium")
    avg_engagement: Mapped[float] = mapped_column(Float, default=0.0)
    dominant_topics: Mapped[list] = mapped_column(JSON, default=list)
    languages: Mapped[list] = mapped_column(JSON, default=list)
    regions: Mapped[list] = mapped_column(JSON, default=list)
    age_distribution: Mapped[list] = mapped_column(JSON, default=list)
    platforms: Mapped[list] = mapped_column(JSON, default=list)
    influential_nodes: Mapped[list] = mapped_column(JSON, default=list)
    sentiment_trend: Mapped[list] = mapped_column(JSON, default=list)
    computed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class AuthorSegment(Base):
    __tablename__ = "author_segments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    author_id: Mapped[str] = mapped_column(String(96), unique=True, index=True)
    segment_id: Mapped[str] = mapped_column(String(48), index=True)
    score: Mapped[float] = mapped_column(Float, default=0.0)
    rationale: Mapped[list] = mapped_column(JSON, default=list)


class TrendMetric(Base):
    __tablename__ = "trend_metrics"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    topic_id: Mapped[str] = mapped_column(String(64), index=True)
    window_start: Mapped[datetime] = mapped_column(DateTime)
    window_end: Mapped[datetime] = mapped_column(DateTime)
    mentions: Mapped[int] = mapped_column(Integer, default=0)
    prev_mentions: Mapped[int] = mapped_column(Integer, default=0)
    growth_rate: Mapped[float] = mapped_column(Float, default=0.0)
    acceleration: Mapped[float] = mapped_column(Float, default=0.0)
    engagement_velocity: Mapped[float] = mapped_column(Float, default=0.0)
    unique_authors: Mapped[int] = mapped_column(Integer, default=0)
    prev_unique_authors: Mapped[int] = mapped_column(Integer, default=0)
    author_growth: Mapped[float] = mapped_column(Float, default=0.0)
    sentiment_shift: Mapped[float] = mapped_column(Float, default=0.0)
    platform_count: Mapped[int] = mapped_column(Integer, default=0)
    influencer_participation: Mapped[float] = mapped_column(Float, default=0.0)
    persistence: Mapped[float] = mapped_column(Float, default=0.0)
    trend_score: Mapped[float] = mapped_column(Float, default=0.0, index=True)
    classification: Mapped[str] = mapped_column(String(24), default="stable")
    momentum: Mapped[str] = mapped_column(String(24), default="stabilising")
    momentum_confidence: Mapped[float] = mapped_column(Float, default=0.0)
    components: Mapped[dict] = mapped_column(JSON, default=dict)
    computed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class NetworkMetric(Base):
    __tablename__ = "network_metrics"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    author_id: Mapped[str] = mapped_column(String(96), unique=True, index=True)
    degree: Mapped[int] = mapped_column(Integer, default=0)
    in_degree: Mapped[int] = mapped_column(Integer, default=0)
    out_degree: Mapped[int] = mapped_column(Integer, default=0)
    degree_centrality: Mapped[float] = mapped_column(Float, default=0.0)
    betweenness: Mapped[float] = mapped_column(Float, default=0.0)
    pagerank: Mapped[float] = mapped_column(Float, default=0.0)
    influence_score: Mapped[float] = mapped_column(Float, default=0.0, index=True)
    community_id: Mapped[int] = mapped_column(Integer, default=0, index=True)
    is_bridge: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    reach: Mapped[int] = mapped_column(Integer, default=0)
    computed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class IntelligenceEvent(Base):
    __tablename__ = "intelligence_events"

    id: Mapped[str] = mapped_column(String(96), primary_key=True)
    category: Mapped[str] = mapped_column(String(48), index=True)
    title: Mapped[str] = mapped_column(String(200))
    summary: Mapped[str] = mapped_column(Text)
    severity: Mapped[str] = mapped_column(String(16), index=True)
    confidence: Mapped[float] = mapped_column(Float, default=0.0)
    detected_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    window_start: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    window_end: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    topic_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    drivers: Mapped[list] = mapped_column(JSON, default=list)
    affected_segments: Mapped[list] = mapped_column(JSON, default=list)
    affected_platforms: Mapped[list] = mapped_column(JSON, default=list)
    related_nodes: Mapped[list] = mapped_column(JSON, default=list)
    evidence: Mapped[list] = mapped_column(JSON, default=list)
    recommended_action: Mapped[str] = mapped_column(Text, default="")
    interpretation_source: Mapped[str] = mapped_column(String(32), default="local")


class AnalysisRun(Base):
    __tablename__ = "analysis_runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String(24), default="running")
    trigger: Mapped[str] = mapped_column(String(32), default="manual")
    seed: Mapped[int] = mapped_column(Integer, default=0)
    posts_ingested: Mapped[int] = mapped_column(Integer, default=0)
    authors_ingested: Mapped[int] = mapped_column(Integer, default=0)
    sentiment_model: Mapped[str] = mapped_column(String(64), default="")
    stage_log: Mapped[list] = mapped_column(JSON, default=list)
    validation: Mapped[dict] = mapped_column(JSON, default=dict)
    error: Mapped[str] = mapped_column(Text, default="")
