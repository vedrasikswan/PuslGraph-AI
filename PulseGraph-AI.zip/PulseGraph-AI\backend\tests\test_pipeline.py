"""End-to-end pipeline behaviour against genuinely computed output."""

from __future__ import annotations

from collections import Counter

from sqlalchemy import func, select

from app.analytics.filters import AnalysisFilters
from app.analytics.journey import build_journey
from app.models import (
    AudienceSegment,
    AuthorSegment,
    DemographicProfile,
    IntelligenceEvent,
    Interaction,
    NetworkMetric,
    Post,
    PostTopic,
    SentimentResult,
    TrendMetric,
)


class TestPipelineRun:
    def test_run_completes_and_records_every_stage(self, analysis_run):
        assert analysis_run.status in {"completed", "completed_with_warnings"}
        assert analysis_run.posts_ingested > 0
        stages = [s["stage"] for s in analysis_run.stage_log]
        for expected in ("ingest", "store", "sentiment", "topics", "interactions",
                         "network", "demographics", "segments", "trends", "intelligence"):
            assert expected in stages, f"pipeline stage '{expected}' did not run"

    def test_seed_validation_passes_every_check(self, analysis_run):
        failures = {
            name: detail for name, detail in analysis_run.validation.items()
            if isinstance(detail, dict) and not detail["passed"]
        }
        assert not failures, f"seed validation failures: {failures}"

    def test_run_is_traceable(self, analysis_run):
        assert analysis_run.sentiment_model
        assert analysis_run.seed
        assert analysis_run.finished_at is not None


class TestStoredResults:
    def test_every_post_has_a_sentiment_result(self, db_session, analysis_run):
        posts = db_session.scalar(select(func.count(Post.id)))
        analysed = db_session.scalar(select(func.count(SentimentResult.id)))
        assert analysed == posts

    def test_sentiment_results_carry_model_provenance(self, db_session, analysis_run):
        rows = db_session.execute(select(SentimentResult).limit(50)).scalars().all()
        assert rows
        for row in rows:
            assert row.model and row.model_version
            assert row.status in {"ok", "local_fallback"}
            assert 0.0 <= row.sentiment_confidence <= 1.0
            assert -1.0 <= row.polarity <= 1.0

    def test_sarcasm_rows_disagree_literal_vs_contextual(self, db_session, analysis_run):
        rows = db_session.execute(
            select(SentimentResult).where(SentimentResult.sarcasm_detected.is_(True))
        ).scalars().all()
        assert rows, "demo corpus must contain detectable sarcasm"
        flipped = [r for r in rows
                   if r.literal_sentiment == "positive" and r.contextual_sentiment == "negative"]
        assert flipped, "sarcasm handling must produce at least one literal/contextual reversal"
        for row in flipped:
            assert row.polarity < 0
            assert row.cues.get("sarcasm_signals")

    def test_topic_assignments_are_traceable_to_posts(self, db_session, analysis_run):
        links = db_session.execute(select(PostTopic).limit(100)).scalars().all()
        assert links
        post_ids = {p for (p,) in db_session.execute(select(Post.id)).all()}
        for link in links:
            assert link.post_id in post_ids
            assert link.relevance > 0

    def test_each_post_has_at_most_one_primary_topic(self, db_session, analysis_run):
        rows = db_session.execute(
            select(PostTopic.post_id).where(PostTopic.is_primary.is_(True))
        ).all()
        ids = [r[0] for r in rows]
        assert len(ids) == len(set(ids))

    def test_interactions_reference_known_authors(self, db_session, analysis_run):
        from app.models import Author

        authors = {a for (a,) in db_session.execute(select(Author.id)).all()}
        edges = db_session.execute(select(Interaction).limit(200)).scalars().all()
        assert edges
        for edge in edges:
            assert edge.source_author_id in authors
            assert edge.target_author_id in authors
            assert edge.source_author_id != edge.target_author_id

    def test_network_metrics_are_bounded(self, db_session, analysis_run):
        rows = db_session.execute(select(NetworkMetric)).scalars().all()
        assert rows
        for row in rows:
            assert 0.0 <= row.pagerank <= 1.0
            assert 0.0 <= row.betweenness <= 1.0
            assert 0.0 <= row.degree_centrality <= 1.0
            assert 0.0 <= row.influence_score <= 100.0

    def test_demographic_profiles_always_carry_evidence(self, db_session, analysis_run):
        rows = db_session.execute(select(DemographicProfile).limit(60)).scalars().all()
        assert rows
        for row in rows:
            assert row.evidence, "an inferred attribute must name the signal behind it"
            assert all("basis" in e for e in row.evidence)
            assert row.age_confidence <= 0.78, "age inference must never be presented as certain"

    def test_segments_are_populated_and_assignments_valid(self, db_session, analysis_run):
        segments = db_session.execute(select(AudienceSegment)).scalars().all()
        populated = [s for s in segments if s.size > 0]
        assert len(populated) >= 3

        valid_ids = {s.id for s in segments}
        assignments = db_session.execute(select(AuthorSegment)).scalars().all()
        assert assignments
        for assignment in assignments:
            assert assignment.segment_id in valid_ids
            assert assignment.rationale, "segment membership must be explainable"

    def test_trend_metrics_span_multiple_classifications(self, db_session, analysis_run):
        rows = db_session.execute(select(TrendMetric)).scalars().all()
        assert rows
        classifications = {r.classification for r in rows}
        assert len(classifications) >= 3, (
            f"demo data should exercise several trend states, saw {classifications}")
        assert any(r.classification in {"accelerating", "viral"} for r in rows)
        for row in rows:
            assert 0 <= row.trend_score <= 100
            assert row.components.get("formula")


class TestIntelligenceOutput:
    def test_required_event_categories_are_detected(self, db_session, analysis_run):
        categories = {
            c for (c,) in db_session.execute(select(IntelligenceEvent.category)).all()
        }
        for required in ("trend_acceleration", "cross_platform_spread",
                         "influencer_amplification", "bridge_discovery",
                         "sentiment_divergence", "sarcasm_load"):
            assert required in categories, f"detector '{required}' produced nothing"

    def test_every_event_has_evidence_and_bounded_confidence(self, db_session, analysis_run):
        events = db_session.execute(select(IntelligenceEvent)).scalars().all()
        assert events
        for event in events:
            assert event.evidence, f"{event.id} has no supporting evidence"
            assert 0.0 <= event.confidence <= 1.0
            assert event.severity in {"critical", "high", "medium", "low", "info"}
            for item in event.evidence:
                assert "metric" in item and "value" in item

    def test_events_avoid_causal_claims(self, db_session, analysis_run):
        """Language must stay correlational."""
        banned = ["caused by", "because of", "proves", "proven", "guaranteed",
                  "definitely caused", "is causing"]
        events = db_session.execute(select(IntelligenceEvent)).scalars().all()
        for event in events:
            blob = f"{event.title} {event.summary} {event.recommended_action}".lower()
            for phrase in banned:
                assert phrase not in blob, f"{event.id} makes a causal claim: '{phrase}'"

    def test_recommendations_are_specific_not_generic(self, service, no_filters):
        generic = ["engage with your audience", "post more often",
                   "monitor social media", "be authentic"]
        recommendations = service.recommendations(no_filters)
        assert recommendations
        for rec in recommendations:
            assert rec["basis"], "a recommendation must name the analysis it came from"
            assert rec["text"].lower().strip() not in generic
            assert len(rec["text"]) > 40


class TestNarrativeJourney:
    def test_journey_reconstructs_ordered_milestones(self, db_session, analysis_run):
        journey = build_journey(db_session, "battery-drain")
        assert journey["milestones"]
        timestamps = [m["ts"] for m in journey["milestones"]]
        assert timestamps == sorted(timestamps), "journey must be chronological"

        kinds = {m["kind"] for m in journey["milestones"]}
        assert "origin" in kinds
        assert "cross_platform" in kinds

    def test_journey_identifies_lead_platform_and_lag(self, db_session, analysis_run):
        journey = build_journey(db_session, "battery-drain")
        assert journey["lead_lag"], "cross-platform ordering must be quantified"
        for entry in journey["lead_lag"]:
            assert entry["minutes"] >= 0
            assert entry["lead_platform"] != entry["lag_platform"]

    def test_episode_excludes_background_chatter(self, db_session, analysis_run):
        journey = build_journey(db_session, "battery-drain")
        assert journey["episode_posts"] <= journey["total_posts"]
        assert journey["episode_posts"] > 0

    def test_every_milestone_carries_evidence(self, db_session, analysis_run):
        journey = build_journey(db_session, "battery-drain")
        for milestone in journey["milestones"]:
            assert milestone["evidence"], f"{milestone['kind']} milestone lacks evidence"

    def test_unknown_topic_returns_empty_not_error(self, db_session, analysis_run):
        journey = build_journey(db_session, "does-not-exist")
        assert journey["milestones"] == []


class TestFilterSynchronisation:
    def test_platform_filter_narrows_every_view_consistently(self, service):
        unfiltered = service.overview(AnalysisFilters())
        filtered = service.overview(AnalysisFilters(platforms=["telegram"]))

        total_key = lambda data: next(  # noqa: E731
            k["value"] for k in data["kpis"] if k["key"] == "total_posts")
        assert total_key(filtered) < total_key(unfiltered)

        posts = service.filtered_posts(AnalysisFilters(platforms=["telegram"]))
        assert {p.platform for p in posts} == {"telegram"}

        network = service.network(AnalysisFilters(platforms=["telegram"]))
        graph_nodes = {n["id"] for n in network["nodes"]}
        assert graph_nodes.issubset({p.author_id for p in posts} | graph_nodes)

    def test_topic_filter_scopes_trends_to_that_topic(self, service):
        filters = AnalysisFilters(topics=["battery-drain"])
        results = service.trend_results(filters)
        assert {r.topic_id for r in results} == {"battery-drain"}

    def test_sentiment_filter_scopes_rows(self, service):
        rows = service.filtered_posts(AnalysisFilters(sentiments=["negative"]))
        assert rows
        assert {r.sentiment for r in rows} == {"negative"}

    def test_timeline_respects_granularity(self, service):
        hourly = service.sentiment_timeline(AnalysisFilters(granularity="hourly"))
        daily = service.sentiment_timeline(AnalysisFilters(granularity="daily"))
        assert len(hourly["points"]) > len(daily["points"])
        assert hourly["total"] == daily["total"]

    def test_filters_that_match_nothing_return_empty_not_error(self, service):
        overview = service.overview(AnalysisFilters(platforms=["nonexistent-platform"]))
        assert overview["empty"] is True
        assert overview["pulse"] is None
        assert all(k["value"] == 0 for k in overview["kpis"])

    def test_audience_and_network_agree_on_the_filtered_population(self, service):
        filters = AnalysisFilters(platforms=["x"])
        audience = service.audience(filters)
        posts = service.filtered_posts(filters)
        assert audience["total_authors"] == len({p.author_id for p in posts})

    def test_intelligence_is_re_derived_under_filters(self, service):
        """The feed must describe the filtered selection, not the whole corpus.

        A detection computed over every platform, displayed next to KPIs for one
        platform, would present two different datasets as one view.
        """
        unfiltered = service.intelligence(AnalysisFilters())
        scoped = service.intelligence(AnalysisFilters(platforms=["x"]))

        assert unfiltered, "expected detections over the full dataset"

        # Every scoped detection must confine itself to the selected platform.
        for event in scoped:
            if event["affected_platforms"]:
                assert set(event["affected_platforms"]) <= {"x"}, (
                    f"{event['id']} references platforms outside the filter"
                )

        # And its volume evidence must not exceed the filtered row count.
        filtered_posts = len(service.filtered_posts(AnalysisFilters(platforms=["x"])))
        for event in scoped:
            for item in event["evidence"]:
                if item["metric"] in {"mentions", "posts_analysed", "total_mentions"}:
                    assert float(item["value"]) <= filtered_posts

    def test_pulse_reflects_the_filtered_selection(self, service):
        unfiltered = service.audience_pulse(AnalysisFilters())
        scoped = service.audience_pulse(AnalysisFilters(platforms=["x"]))
        assert unfiltered is not None
        if scoped is not None:
            assert scoped["statement"] != unfiltered["statement"], (
                "the pulse must change when the dataset it describes changes"
            )

    def test_narrow_filter_yielding_no_detection_returns_empty_not_stale(self, service):
        """Below detection thresholds the answer is 'nothing found', never a
        leftover finding from a wider dataset."""
        filters = AnalysisFilters(platforms=["instagram"], topics=["camera-quality"])
        events = service.intelligence(filters)
        posts = service.filtered_posts(filters)
        for event in events:
            for item in event["evidence"]:
                if item["metric"] in {"mentions", "posts_analysed"}:
                    assert float(item["value"]) <= max(len(posts), 1)


class TestAudiencePulse:
    def test_pulse_leads_with_the_most_material_event(self, service, no_filters):
        pulse = service.audience_pulse(no_filters)
        assert pulse is not None
        assert pulse["topic_id"], "the pulse must attribute the change to a topic"
        assert pulse["evidence"], "the pulse must be evidence-backed"
        assert pulse["confidence_band"] in {"High", "Medium", "Low"}
        assert len(pulse["statement"]) > 60

    def test_pulse_prefers_high_volume_topics_over_small_ones(self, service, no_filters):
        """Materiality must beat a marginally higher confidence on a tiny topic."""
        events = service.intelligence(no_filters)
        pulse = service.audience_pulse(no_filters)
        chosen = next(e for e in events if e["title"] == pulse["headline"])
        best_rank = max(service._pulse_rank(e) for e in events)
        assert service._pulse_rank(chosen) == best_rank

    def test_pulse_answers_what_where_and_who(self, service, no_filters):
        pulse = service.audience_pulse(no_filters)
        assert pulse["affected_platforms"]
        assert pulse["recommended_action"]
        assert pulse["detected_at"]


class TestCrossPlatform:
    def test_platform_breakdown_reports_per_platform_polarity(self, service):
        rows = service.filtered_posts(AnalysisFilters(topics=["battery-drain"]))
        breakdown = service.platform_breakdown_for(rows)
        assert len(breakdown) >= 3
        for entry in breakdown:
            assert -1.0 <= entry["avg_polarity"] <= 1.0
            assert 0.0 <= entry["negative_share"] <= 1.0
            assert entry["posts"] > 0

    def test_topics_are_present_on_multiple_platforms(self, db_session, analysis_run):
        rows = db_session.execute(
            select(PostTopic.topic_id, func.count(func.distinct(Post.platform)))
            .join(Post, Post.id == PostTopic.post_id)
            .where(PostTopic.is_primary.is_(True))
            .group_by(PostTopic.topic_id)
        ).all()
        assert any(count >= 3 for _topic, count in rows)


class TestDeterminism:
    def test_same_seed_reproduces_the_same_corpus(self):
        from app.ingestion.demo_dataset import generate_demo_corpus

        _a1, p1 = generate_demo_corpus(seed=555, target_posts=500)
        _a2, p2 = generate_demo_corpus(seed=555, target_posts=500)
        assert len(p1) == len(p2)
        assert [p.text for p in p1] == [p.text for p in p2]
        assert [p.platform for p in p1] == [p.platform for p in p2]
        assert [p.engagement_count for p in p1] == [p.engagement_count for p in p2]

    def test_relative_timing_structure_is_stable(self):
        from app.ingestion.demo_dataset import generate_demo_corpus

        _a, posts = generate_demo_corpus(seed=555, target_posts=500)
        platforms = Counter(p.platform for p in posts)
        assert platforms["telegram"] > 0 and platforms["x"] > 0
