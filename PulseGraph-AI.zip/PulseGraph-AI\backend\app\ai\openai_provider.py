"""External LLM provider.

Used only when AI_PROVIDER=openai and a key is present. Two safety rules:

* the local engine always runs first, so a provider failure degrades to a
  working result rather than an error;
* the model's response is parsed into the same typed structures as everything
  else. Free text never reaches application logic - at most it replaces the
  wording of a summary that was computed elsewhere.
"""

from __future__ import annotations

import json
import logging

from app.ai.local_provider import LocalNLPProvider
from app.ai.provider import AIProvider, Narrative, TextAnalysis

logger = logging.getLogger(__name__)

VALID_SENTIMENT = {"positive", "negative", "neutral"}
VALID_STANCE = {"supportive", "against", "neutral"}
VALID_EMOTION = {
    "excited", "angry", "anxious", "confused", "sarcastic", "concerned",
    "curious", "frustrated", "satisfied", "neutral",
}

ANALYSIS_SYSTEM = (
    "You are a social media analyst. Classify the post and reply with JSON only, "
    "using this exact schema: {\"sentiment\":\"positive|negative|neutral\","
    "\"sentiment_confidence\":0-1,\"stance\":\"supportive|against|neutral\","
    "\"emotion\":\"excited|angry|anxious|confused|sarcastic|concerned|curious|"
    "frustrated|satisfied|neutral\",\"emotion_confidence\":0-1,"
    "\"sarcasm\":true|false,\"sarcasm_confidence\":0-1,\"polarity\":-1..1,"
    "\"literal_sentiment\":\"positive|negative|neutral\",\"evidence\":[\"...\"]}"
)

NARRATIVE_SYSTEM = (
    "You are an intelligence analyst writing one short paragraph for a dashboard. "
    "You will be given metrics that have ALREADY been computed. Use only those "
    "numbers - never invent, round differently, or add figures. Avoid claiming "
    "causation: prefer 'likely driver', 'appears to originate from', 'preceded', "
    "'associated with'. Reply with JSON: {\"summary\":\"...\",\"recommended_action\":\"...\"}"
)


class OpenAIProvider(AIProvider):
    name = "openai"

    def __init__(self, api_key: str, model: str = "gpt-4o-mini", timeout: float = 20.0) -> None:
        self.api_key = api_key
        self.model = model
        self.version = model
        self.timeout = timeout
        self._fallback = LocalNLPProvider()
        self._degraded = False

    # ------------------------------------------------------------------ #
    def _chat(self, system: str, user: str) -> dict | None:
        if not self.api_key:
            return None
        try:
            import httpx

            resp = httpx.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.model,
                    "temperature": 0,
                    "response_format": {"type": "json_object"},
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                },
                timeout=self.timeout,
            )
            resp.raise_for_status()
            content = resp.json()["choices"][0]["message"]["content"]
            return json.loads(content)
        except Exception as exc:
            if not self._degraded:
                logger.warning("OpenAI provider unavailable, using local engine: %s", exc)
                self._degraded = True
            return None

    # ------------------------------------------------------------------ #
    def analyze_text(self, text: str, language: str = "en") -> TextAnalysis:
        local = self._fallback.analyze_text(text, language)
        payload = self._chat(ANALYSIS_SYSTEM, text[:1500])
        if not payload:
            local.status = "local_fallback"
            return local

        try:
            sentiment = str(payload.get("sentiment", "")).lower()
            emotion = str(payload.get("emotion", "")).lower()
            stance = str(payload.get("stance", "")).lower()
            if sentiment not in VALID_SENTIMENT:
                raise ValueError(f"invalid sentiment '{sentiment}'")
            if emotion not in VALID_EMOTION:
                emotion = local.emotion
            if stance not in VALID_STANCE:
                stance = local.stance

            polarity = float(payload.get("polarity", local.polarity))
            polarity = max(-1.0, min(1.0, polarity))
            literal = str(payload.get("literal_sentiment", sentiment)).lower()
            if literal not in VALID_SENTIMENT:
                literal = sentiment

            return TextAnalysis(
                sentiment=sentiment,
                sentiment_confidence=float(payload.get("sentiment_confidence", 0.7)),
                stance=stance,
                emotion=emotion,
                emotion_confidence=float(payload.get("emotion_confidence", 0.7)),
                polarity=polarity,
                literal_sentiment=literal,
                contextual_sentiment=sentiment,
                sarcasm_detected=bool(payload.get("sarcasm", False)),
                sarcasm_confidence=float(payload.get("sarcasm_confidence", 0.0)),
                cues={
                    "evidence": [str(e) for e in (payload.get("evidence") or [])][:8],
                    "local_cross_check": {
                        "sentiment": local.sentiment,
                        "polarity": local.polarity,
                        "sarcasm": local.sarcasm_detected,
                    },
                },
                model=self.name,
                model_version=self.model,
                status="ok",
            )
        except Exception as exc:
            logger.warning("Malformed LLM analysis discarded (%s); using local result", exc)
            local.status = "local_fallback"
            return local

    def interpret(self, brief: dict) -> Narrative:
        local = self._fallback.interpret(brief)
        payload = self._chat(NARRATIVE_SYSTEM, json.dumps(brief, default=str)[:4000])
        if not payload:
            return local
        summary = str(payload.get("summary", "")).strip()
        action = str(payload.get("recommended_action", "")).strip()
        if not summary or len(summary) > 900:
            return local
        return Narrative(
            summary=summary,
            recommended_action=action or local.recommended_action,
            source="openai",
        )

    def health(self) -> dict:
        return {
            "provider": self.name,
            "version": self.model,
            "status": "degraded" if self._degraded else "ok",
            "fallback": self._fallback.name,
        }
