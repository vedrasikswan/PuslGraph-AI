'use client';

/**
 * The main dashboard.
 *
 * Every panel here reads from the same filter object, so a click on the
 * sentiment timeline, a platform chip or a segment card re-derives all of them
 * together. Section order follows the analyst's question: what changed (Pulse),
 * how much (KPIs), when (timeline), what topics (radar), who (audience map),
 * how it spread (network) and what the engine detected (feed).
 */

import { useState } from 'react';
import Link from 'next/link';
import { ArrowUpRight, Lightbulb, Network as NetworkIcon } from 'lucide-react';

import { PlatformDivergence } from '@/components/charts/PlatformDivergence';
import { SentimentTimeline } from '@/components/charts/SentimentTimeline';
import { InfluenceGraph, NodeInspector } from '@/components/network/InfluenceGraph';
import { KpiStrip } from '@/components/ui/KpiStrip';
import {
  Badge,
  ConfidenceBadge,
  EmptyState,
  ErrorState,
  Panel,
  PanelSkeleton,
  SeverityBadge,
} from '@/components/ui/primitives';
import { AudienceMap } from '@/features/audience/AudienceMap';
import { useFilters, filterKey } from '@/features/filters/FilterContext';
import { IntelligenceFeed } from '@/features/intelligence/IntelligenceFeed';
import { AudiencePulseCard } from '@/features/pulse/AudiencePulse';
import { TrendRadar } from '@/features/trends/TrendRadar';
import { useApi } from '@/hooks/useApi';
import { api } from '@/lib/api';
import { titleCase } from '@/lib/format';
import type {
  AudienceResponse,
  GraphNode,
  IntelligenceCard,
  NetworkResponse,
  Overview,
  SentimentTimeline as TimelineData,
  Trend,
} from '@/types/api';

export function DashboardView() {
  const { filters, setWindow } = useFilters();
  const key = filterKey(filters);
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);

  const overview = useApi<Overview>(`overview:${key}`, () => api.overview(filters));
  const timeline = useApi<TimelineData>(`timeline:${key}`, () => api.sentimentTimeline(filters));
  const trends = useApi<{ items: Trend[] }>(`trends:${key}`, () => api.trends(filters));
  const audience = useApi<AudienceResponse>(`audience:${key}`, () => api.audience(filters));
  const network = useApi<NetworkResponse>(`network:${key}`, () => api.network(filters, 110));
  const intelligence = useApi<{ items: IntelligenceCard[] }>(
    `intelligence:${key}`,
    () => api.intelligence(filters),
  );

  const topTopic = trends.data?.items[0];
  const topicPlatforms = useApi(
    topTopic ? `topic-platforms:${topTopic.topic_id}:${key}` : null,
    () => api.topicPlatforms(topTopic!.topic_id, filters),
  );

  // A backend that is down or has no dataset is a whole-page condition.
  if (overview.error) {
    return (
      <Panel>
        <ErrorState
          error={overview.error}
          onRetry={() => {
            overview.reload();
            timeline.reload();
            trends.reload();
          }}
        />
        {overview.error.needsDataset && (
          <div className="border-t border-edge-subtle p-4 text-center">
            <Link
              href="/data"
              className="inline-flex items-center gap-1.5 rounded bg-trend px-3 py-1.5 text-2xs font-medium text-canvas hover:bg-trend/90"
            >
              Load Demo Intelligence
              <ArrowUpRight className="h-3 w-3" aria-hidden />
            </Link>
          </div>
        )}
      </Panel>
    );
  }

  const isEmpty = overview.data?.empty;

  return (
    <div className="space-y-3">
      {/* SECTION 1 — Audience Pulse */}
      <AudiencePulseCard pulse={overview.data?.pulse ?? null} loading={overview.loading} />

      {/* SECTION 2 — KPI strip */}
      <KpiStrip kpis={overview.data?.kpis ?? null} loading={overview.loading} />

      {isEmpty && (
        <Panel>
          <EmptyState
            title="Nothing matches these filters"
            description="The dataset is loaded, but no post satisfies the current selection. Widen the time range or remove a filter."
          />
        </Panel>
      )}

      {!isEmpty && (
        <>
          {/* SECTION 3 — Sentiment timeline */}
          <Panel
            title="Sentiment timeline"
            subtitle="Click any interval to filter every panel on this page to that window"
            actions={
              <>
                <Badge tone="neutral">{titleCase(filters.granularity)}</Badge>
                {overview.data && (
                  <Badge tone={overview.data.sarcasm_rate > 0.05 ? 'warning' : 'neutral'}>
                    Sarcasm {(overview.data.sarcasm_rate * 100).toFixed(1)}%
                  </Badge>
                )}
              </>
            }
          >
            {timeline.loading && <PanelSkeleton rows={5} height="h-8" />}
            {timeline.error && <ErrorState error={timeline.error} onRetry={timeline.reload} />}
            {timeline.data && timeline.data.points.length > 0 && (
              <SentimentTimeline
                points={timeline.data.points}
                granularity={timeline.data.granularity}
                onSelectWindow={setWindow}
                selected={{ start: filters.start, end: filters.end }}
              />
            )}
            {timeline.data && timeline.data.points.length === 0 && (
              <EmptyState title="No activity in this window" />
            )}
          </Panel>

          <div className="grid gap-3 xl:grid-cols-3">
            {/* SECTION 4 — Trend radar */}
            <div className="xl:col-span-2">
              <TrendRadar trends={trends.data?.items ?? null} loading={trends.loading} limit={5} />
            </div>

            {/* Recommendations derived from the analytics */}
            <Panel
              title={
                <span className="flex items-center gap-1.5">
                  <Lightbulb className="h-3.5 w-3.5 text-warning" aria-hidden />
                  Recommendations
                </span>
              }
              subtitle="Derived from the detections above, not generic advice"
              dense
            >
              {overview.loading && (
                <div className="p-4">
                  <PanelSkeleton rows={4} height="h-10" />
                </div>
              )}
              {overview.data?.recommendations.length === 0 && (
                <EmptyState
                  title="No actions indicated"
                  description="Nothing in the current selection warrants an intervention."
                />
              )}
              {overview.data?.recommendations.map((rec) => (
                <div key={rec.id} className="border-b border-edge-subtle px-4 py-2.5 last:border-0">
                  <div className="flex items-center gap-1.5">
                    <SeverityBadge severity={rec.severity} />
                    <ConfidenceBadge band={rec.confidence_band} value={rec.confidence} />
                  </div>
                  <p className="mt-1.5 text-2xs leading-relaxed text-ink-muted">{rec.text}</p>
                  <p className="mt-1 text-[10px] text-ink-faint">Basis: {rec.basis}</p>
                </div>
              ))}
            </Panel>
          </div>

          {/* SECTION 5 — Audience map */}
          <AudienceMap segments={audience.data?.segments ?? null} loading={audience.loading} limit={6} />

          <div className="grid gap-3 xl:grid-cols-3">
            {/* SECTION 6 — Influence network */}
            <div className="xl:col-span-2">
              <Panel
                title={
                  <span className="flex items-center gap-1.5">
                    <NetworkIcon className="h-3.5 w-3.5 text-influence" aria-hidden />
                    Influence network
                  </span>
                }
                subtitle={
                  network.data && !network.data.empty
                    ? `Showing ${network.data.displayed_nodes} of ${network.data.total_nodes} accounts across ${network.data.communities.length} communities`
                    : 'Interaction graph for the current selection'
                }
                actions={
                  <Link
                    href="/network"
                    className="inline-flex items-center gap-1 text-2xs text-ink-muted hover:text-ink"
                  >
                    Full graph
                    <ArrowUpRight className="h-3 w-3" aria-hidden />
                  </Link>
                }
              >
                {network.loading && <PanelSkeleton rows={6} height="h-16" />}
                {network.error && <ErrorState error={network.error} onRetry={network.reload} />}
                {network.data && network.data.empty && (
                  <EmptyState
                    title="No interactions in this selection"
                    description="The filtered posts contain no replies, mentions or reposts to build a graph from."
                  />
                )}
                {network.data && !network.data.empty && (
                  <div className="grid gap-3 lg:grid-cols-[1fr_220px]">
                    <InfluenceGraph
                      data={network.data}
                      height={380}
                      onSelect={setSelectedNode}
                      selectedId={selectedNode?.id ?? null}
                      highlightSegment={filters.segments[0] ?? null}
                    />
                    <div className="rounded border border-edge-subtle bg-canvas-sunken">
                      <NodeInspector node={selectedNode} />
                    </div>
                  </div>
                )}
              </Panel>
            </div>

            {/* Cross-platform divergence for the leading topic */}
            <PlatformDivergence
              platforms={topicPlatforms.data?.platforms ?? null}
              divergence={topicPlatforms.data?.divergence}
              interpretation={topicPlatforms.data?.interpretation}
              loading={topicPlatforms.loading || trends.loading}
              title={
                topTopic
                  ? `Platform divergence — ${topTopic.label}`
                  : 'Cross-platform sentiment divergence'
              }
            />
          </div>

          {/* SECTION 7 — Intelligence feed */}
          <IntelligenceFeed
            cards={intelligence.data?.items ?? null}
            loading={intelligence.loading}
          />
        </>
      )}
    </div>
  );
}
