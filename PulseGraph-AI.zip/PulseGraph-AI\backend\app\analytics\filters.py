"""Global analysis filters.

One filter object is threaded through every endpoint. That is what makes the
dashboard a single system: sentiment, trends, audience, network, timeline and
the intelligence feed are all computed from the same filtered row set rather
than from separate hidden queries.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from sqlalchemy import Select, and_, func, or_, select

from app.models import AuthorSegment, Post, PostTopic, SentimentResult

GRANULARITIES = {
    "hourly": timedelta(hours=1),
    "6-hourly": timedelta(hours=6),
    "daily": timedelta(days=1),
    "weekly": timedelta(days=7),
}


@dataclass(slots=True)
class AnalysisFilters:
    start: datetime | None = None
    end: datetime | None = None
    platforms: list[str] = field(default_factory=list)
    topics: list[str] = field(default_factory=list)
    segments: list[str] = field(default_factory=list)
    sentiments: list[str] = field(default_factory=list)
    emotions: list[str] = field(default_factory=list)
    search: str = ""
    granularity: str = "hourly"

    def signature(self) -> str:
        payload = {
            "start": self.start.isoformat() if self.start else None,
            "end": self.end.isoformat() if self.end else None,
            "platforms": sorted(self.platforms),
            "topics": sorted(self.topics),
            "segments": sorted(self.segments),
            "sentiments": sorted(self.sentiments),
            "emotions": sorted(self.emotions),
            "search": self.search.lower().strip(),
            "granularity": self.granularity,
        }
        raw = json.dumps(payload, sort_keys=True)
        return hashlib.sha1(raw.encode()).hexdigest()[:16]

    @property
    def bucket(self) -> timedelta:
        return GRANULARITIES.get(self.granularity, timedelta(hours=1))

    def is_empty(self) -> bool:
        return not any([
            self.start, self.end, self.platforms, self.topics, self.segments,
            self.sentiments, self.emotions, self.search.strip(),
        ])

    def describe(self) -> dict:
        return {
            "start": self.start.isoformat() if self.start else None,
            "end": self.end.isoformat() if self.end else None,
            "platforms": self.platforms,
            "topics": self.topics,
            "segments": self.segments,
            "sentiments": self.sentiments,
            "emotions": self.emotions,
            "search": self.search,
            "granularity": self.granularity,
            "active": not self.is_empty(),
        }


def apply_filters(stmt: Select, filters: AnalysisFilters, *, joined: bool = False) -> Select:
    """Apply the filter set to a statement selecting from `posts`.

    `joined` indicates that SentimentResult / PostTopic are already joined by
    the caller, which avoids duplicate joins when the caller needs those columns.
    """
    conditions = []
    if filters.start:
        conditions.append(Post.created_at >= filters.start)
    if filters.end:
        conditions.append(Post.created_at <= filters.end)
    if filters.platforms:
        conditions.append(Post.platform.in_(filters.platforms))
    if filters.search:
        needle = f"%{filters.search.strip()}%"
        conditions.append(or_(Post.text.ilike(needle), Post.author_id.ilike(needle)))

    if conditions:
        stmt = stmt.where(and_(*conditions))

    if filters.topics:
        if joined:
            stmt = stmt.where(PostTopic.topic_id.in_(filters.topics))
        else:
            stmt = stmt.where(
                Post.id.in_(
                    select(PostTopic.post_id).where(PostTopic.topic_id.in_(filters.topics))
                )
            )

    if filters.sentiments or filters.emotions:
        sub_conditions = []
        if filters.sentiments:
            sub_conditions.append(SentimentResult.sentiment.in_(filters.sentiments))
        if filters.emotions:
            sub_conditions.append(SentimentResult.emotion.in_(filters.emotions))
        if joined:
            stmt = stmt.where(and_(*sub_conditions))
        else:
            stmt = stmt.where(
                Post.id.in_(select(SentimentResult.post_id).where(and_(*sub_conditions)))
            )

    if filters.segments:
        stmt = stmt.where(
            Post.author_id.in_(
                select(AuthorSegment.author_id).where(
                    AuthorSegment.segment_id.in_(filters.segments)
                )
            )
        )
    return stmt


def floor_to(ts: datetime, size: timedelta) -> datetime:
    seconds = int(size.total_seconds())
    epoch = int(ts.timestamp())
    return datetime.fromtimestamp(epoch - epoch % seconds)


def resolve_range(
    db, filters: AnalysisFilters
) -> tuple[datetime | None, datetime | None]:
    """Effective time bounds, falling back to the dataset extent."""
    start = filters.start
    end = filters.end
    if start is None or end is None:
        bounds = db.execute(
            select(func.min(Post.created_at), func.max(Post.created_at))
        ).one_or_none()
        if bounds:
            start = start or bounds[0]
            end = end or bounds[1]
    return start, end
