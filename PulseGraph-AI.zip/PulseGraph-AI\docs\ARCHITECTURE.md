# Architecture

## Principle order

Decisions were made in this priority order, and where they conflict the earlier
one wins:

1. **Simplicity** — a modular monolith, one database, no queue or scheduler
2. **Reliability** — no stage may break the run; providers degrade to a fallback
3. **Explainability** — every conclusion carries the metrics that produced it
4. **Demo impact** — the story must be visible in 3–5 minutes
5. **Extensibility** — real APIs plug into the adapter interface unchanged

---

## Layers

```
┌──────────────────────────────────────────────────────────────┐
│  INGESTION            DataSourceAdapter (abstract)           │
│                       LiveApiAdapter → X, Telegram, Instagram│
│                       Facebook, Reddit, YouTube              │
│                       DemoDataAdapter → deterministic corpus │
│                       ↓ NormalizedPost / NormalizedAuthor    │
├──────────────────────────────────────────────────────────────┤
│  AI                   AIProvider (abstract)                  │
│                       LocalNLPProvider  (default, offline)   │
│                       OpenAIProvider    (optional, validated)│
├──────────────────────────────────────────────────────────────┤
│  ANALYTICS            topics · demographics · segments       │
│                       network · trends · journey             │
│                       intelligence (InsightEngine)           │
│                       filters · queries (read side)          │
│                       pipeline (write side, staged)          │
├──────────────────────────────────────────────────────────────┤
│  PERSISTENCE          SQLAlchemy 2 → SQLite (PostgreSQL-ready)│
├──────────────────────────────────────────────────────────────┤
│  API                  FastAPI, one router group per concern  │
├──────────────────────────────────────────────────────────────┤
│  UI                   Next.js App Router, URL-backed filters │
└──────────────────────────────────────────────────────────────┘
```

## The write path

`Pipeline.run()` executes eleven stages in order. Each records what it produced
into `analysis_runs.stage_log`, so any dashboard number can be traced back to
the run that computed it.

| Stage | Produces |
|---|---|
| `reset` | Clears prior analytical output |
| `ingest` | Batches from each adapter, with real per-source status |
| `store` | `users`, `posts`, pseudonymous ids |
| `sentiment` | `sentiment_results` (one per post) |
| `topics` | `post_topics`, `topics` with observed first/last activity |
| `interactions` | `interactions` — the reply/mention/repost graph |
| `network` | `network_metrics` — centrality, community, influence, bridges |
| `demographics` | `demographic_profiles` with evidence and confidence |
| `segments` | `author_segments` + `audience_segments` rollups |
| `trends` | `trend_metrics` per topic with score decomposition |
| `intelligence` | `intelligence_events` from ten detectors |
| `validation` | Real queries asserting the corpus is analysable |

Ordering constraints: sentiment before segmentation (needs polarity), topics
before interactions (edges carry a topic), network before segmentation (segments
report influential members), and everything before intelligence.

## The read path

`AnalyticsService` is the only thing the API calls for analytics. Every method
takes the same `AnalysisFilters` object, and results are memoised on the filter
signature with a generation counter that is bumped whenever a pipeline run
completes.

**Why filters matter architecturally.** With a filter active, the intelligence
detectors are re-run against the filtered subset rather than reading the events
the pipeline stored. A detection computed over every platform, displayed beside
KPIs for one platform, would present two different datasets as a single view.
Stored events remain the audit record of the run.

## Extension points

| To add… | Do this | Nothing else changes |
|---|---|---|
| A platform | Subclass `LiveApiAdapter`, implement `normalize` + `_fetch_live`, register in `ingestion/registry.py` | Pipeline, analytics, UI |
| A model | Implement `AIProvider`, register in `ai/registry.py` | All call sites |
| A detector | Add a method to `InsightEngine`, list it in `run()` | Feed, Pulse, timeline render it automatically |
| A topic | Add an entry to `TOPIC_DEFINITIONS` | Classification, trends, journeys pick it up |
| PostgreSQL | Change `DATABASE_URL`, install a driver | No code change |

## Performance

The demo corpus is ~1,600 posts and ~190 accounts — small enough that
correctness beats cleverness. Where cost could grow:

- **Betweenness** is O(VE); pivot sampling kicks in above 220 nodes.
- **Graph payloads** are aggregated server-side to a node cap, keeping every
  bridge, and the response states what was truncated.
- **Repeated panels** share one memoised result per filter signature, so a
  dashboard render issues one query set rather than one per panel.
- **Pagination** on `/api/posts`; the UI never fetches the full corpus.

A full pipeline run over 1,600 posts completes in roughly 5–7 seconds, dominated
by network analysis.

## Failure behaviour

| Failure | Behaviour |
|---|---|
| LLM provider unavailable | Local engine result is used; status `local_fallback` |
| LLM returns malformed JSON | Discarded, local result kept, warning logged |
| One detector raises | Logged; the other nine still produce output |
| Sentiment fails on one post | Counted, skipped, run continues |
| No credentials for a platform | `NOT_CONNECTED` + explanation, never fake connectivity |
| No dataset loaded | API returns 409 with a pointer to the demo endpoint |
| Filters match nothing | Empty state explaining how to widen, not a blank panel |
| Any unhandled server error | Typed JSON envelope; never a stack trace |
