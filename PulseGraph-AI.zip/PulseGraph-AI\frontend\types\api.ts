/**
 * Typed mirror of the backend Pydantic contracts (backend/app/schemas.py).
 * Keeping these in one place means a backend field rename surfaces as a
 * compile error rather than an undefined at runtime.
 */

export type Sentiment = 'positive' | 'negative' | 'neutral';
export type Severity = 'critical' | 'high' | 'medium' | 'low' | 'info';
export type ConfidenceBand = 'High' | 'Medium' | 'Low';
export type Granularity = 'hourly' | '6-hourly' | 'daily' | 'weekly';
export type TrendClass = 'stable' | 'emerging' | 'growing' | 'accelerating' | 'viral';

export interface Evidence {
  metric: string;
  value: string | number;
  change?: string;
  period?: string;
  note?: string;
}

export interface FilterState {
  start: string | null;
  end: string | null;
  platforms: string[];
  topics: string[];
  segments: string[];
  sentiments: string[];
  emotions: string[];
  search: string;
  granularity: Granularity;
  active: boolean;
}

export interface KPI {
  key: string;
  label: string;
  value: number;
  change: number | null;
  format: 'number' | 'percent';
}

export interface AudiencePulse {
  headline: string;
  statement: string;
  severity: Severity;
  confidence: number;
  confidence_band: ConfidenceBand;
  detected_at: string;
  topic_id: string | null;
  topic_label: string | null;
  affected_platforms: string[];
  affected_segments: string[];
  evidence: Evidence[];
  recommended_action: string;
  supporting_events: { id: string; title: string; category: string }[];
  interpretation_source: string;
}

export interface Recommendation {
  id: string;
  text: string;
  basis: string;
  severity: Severity;
  confidence: number;
  confidence_band: ConfidenceBand;
  topic_id: string | null;
}

export interface Overview {
  empty: boolean;
  kpis: KPI[];
  avg_polarity: number;
  sarcasm_rate: number;
  sentiment_distribution: { sentiment: Sentiment; count: number; percentage: number }[];
  emotion_distribution: { emotion: string; count: number; percentage: number }[];
  platform_distribution: { platform: string; count: number; percentage: number }[];
  range: { start: string | null; end: string | null };
  pulse: AudiencePulse | null;
  filters: FilterState;
  recommendations: Recommendation[];
}

export interface TimelinePoint {
  ts: string;
  positive: number;
  negative: number;
  neutral: number;
  total: number;
  engagement: number;
  unique_authors: number;
  sarcasm: number;
  avg_polarity: number;
  negative_share: number;
}

export interface SentimentTimeline {
  granularity: Granularity;
  points: TimelinePoint[];
  total: number;
  filters: FilterState;
}

export interface Velocity {
  current_mentions: number;
  previous_mentions: number;
  growth_percentage: number;
  direction: 'up' | 'down' | 'flat';
  acceleration: number;
  engagement_velocity: number;
  previous_engagement_velocity: number;
  engagement_growth: number;
  unique_authors: number;
  author_growth: number;
}

export interface Momentum {
  label: string;
  confidence: number;
  confidence_band: ConfidenceBand;
  forecast_next_bucket: number;
}

export interface TrendComponents {
  weights: Record<string, number>;
  values: Record<string, number>;
  formula: string;
}

export interface TrendSeriesPoint {
  ts: string;
  mentions: number;
  engagement: number;
  unique_authors: number;
  avg_polarity: number;
}

export interface Trend {
  topic_id: string;
  label: string;
  description: string;
  trend_score: number;
  classification: TrendClass;
  velocity: Velocity;
  sentiment: { avg_polarity: number; previous_polarity: number; shift: number };
  platforms: string[];
  platform_count: number;
  influencer_participation: number;
  persistence: number;
  momentum: Momentum;
  components: TrendComponents;
  series: TrendSeriesPoint[];
}

export interface IntelligenceCard {
  id: string;
  category: string;
  title: string;
  summary: string;
  severity: Severity;
  confidence: number;
  confidence_band: ConfidenceBand;
  detected_at: string;
  window: { start: string | null; end: string | null };
  topic_id: string | null;
  topic_label: string | null;
  drivers: string[];
  affected_segments: string[];
  affected_platforms: string[];
  related_nodes: RelatedNode[];
  evidence: Evidence[];
  recommended_action: string;
  interpretation_source: string;
}

export interface RelatedNode {
  anon_id: string;
  influence_score?: number;
  betweenness?: number;
  community_id?: number;
  is_bridge?: boolean;
  posts?: number;
  engagement?: number;
  cross_community_edges?: number;
  bridge_ratio?: number;
}

export interface SegmentSummary {
  id: string;
  name: string;
  description: string;
  color: string;
  size: number;
  total_members: number;
  posts: number;
  engagement: number;
  avg_engagement: number;
  engagement_level: 'high' | 'medium' | 'low';
  avg_polarity: number;
  dominant_sentiment: Sentiment;
  sentiment_distribution: { sentiment: Sentiment; count: number; percentage: number }[];
  dominant_topics: { topic_id: string; posts: number }[];
  platforms: { platform: string; posts: number }[];
  languages: { language: string; posts: number }[];
  age_distribution: { bracket: string; authors: number; percentage: number }[];
  regions: { region: string; authors: number; percentage: number }[];
  interests: { interest: string; authors: number }[];
  sentiment_trend: { ts: string; avg_polarity: number; posts: number }[];
  influential_members: { anon_id: string; influence_score: number; is_bridge: boolean }[];
  assignment_rationale: string[];
}

export interface DemographicRow {
  value: string;
  count: number;
  percentage: number;
  confidence: number;
  confidence_band: ConfidenceBand;
}

export interface AudienceResponse {
  segments: SegmentSummary[];
  demographics: {
    age_brackets: DemographicRow[];
    regions: DemographicRow[];
    languages: DemographicRow[];
    interests: DemographicRow[];
    behaviours: DemographicRow[];
    evidence_basis: { basis: string; signals: number }[];
    profiles_considered: number;
  };
  total_authors: number;
  privacy_notice: string;
  filters: FilterState;
}

export interface SegmentComparison {
  left: { id: string; name: string; color: string };
  right: { id: string; name: string; color: string };
  metrics: Record<string, { left: unknown; right: unknown }>;
  sentiment_distribution: {
    left: { sentiment: Sentiment; percentage: number }[];
    right: { sentiment: Sentiment; percentage: number }[];
  };
  topics: { shared: string[]; left_only: string[]; right_only: string[] };
  platforms: { left: { platform: string; posts: number }[]; right: { platform: string; posts: number }[] };
  regions: { left: DemographicRow[]; right: DemographicRow[] };
  polarity_gap: number;
}

export interface GraphNode {
  id: string;
  anon_id: string;
  platform: string;
  verified: boolean;
  influence_score: number;
  pagerank: number;
  betweenness: number;
  degree_centrality: number;
  degree: number;
  in_degree: number;
  out_degree: number;
  community_id: number;
  is_bridge: boolean;
  cross_community_edges: number;
  reach: number;
  posts: number;
  avg_polarity: number;
  segment_id: string;
  segment_name: string;
  segment_color: string;
  rationale: string[];
}

export interface GraphEdge {
  source: string;
  target: string;
  weight: number;
  kinds: string[];
}

export interface NetworkResponse {
  nodes: GraphNode[];
  edges: GraphEdge[];
  communities: {
    community_id: number;
    accounts: number;
    total_influence: number;
    bridge_nodes: number;
    dominant_segment: string | null;
  }[];
  truncated: boolean;
  total_nodes: number;
  total_edges: number;
  displayed_nodes: number;
  empty: boolean;
  filters: FilterState;
}

export interface Influencer {
  rank: number;
  anon_id: string;
  author_id: string;
  platform: string;
  influence_score: number;
  pagerank: number;
  betweenness: number;
  degree_centrality: number;
  community_id: number;
  is_bridge: boolean;
  reach: number;
  posts: number;
  engagement: number;
  topics: string[];
  avg_polarity: number;
  sentiment: Sentiment;
  segment: string;
  rationale: string[];
}

export interface JourneyMilestone {
  ts: string;
  kind: string;
  title: string;
  detail: string;
  platform: string | null;
  evidence: Evidence[];
  sample_post_id: string | null;
  sample_text: string | null;
  actors: { anon_id: string; influence_score: number }[];
}

export interface Journey {
  topic_id: string;
  span: { start: string; end: string; hours: number } | null;
  bucket_minutes?: number;
  total_posts?: number;
  episode_posts?: number;
  lead_platform?: string;
  milestones: JourneyMilestone[];
  lead_lag: {
    lead_platform: string;
    lag_platform: string;
    minutes: number;
    lead_first_activity: string;
    lag_first_activity: string;
  }[];
}

export interface PlatformBreakdown {
  platform: string;
  posts: number;
  unique_authors: number;
  engagement: number;
  avg_polarity: number;
  negative_share: number;
  positive_share: number;
  divergence_from_mean?: number;
}

export interface TopicPlatforms {
  topic_id: string;
  platforms: PlatformBreakdown[];
  divergence: number;
  interpretation: string;
  flow: InfluenceFlow;
}

export interface InfluenceFlow {
  topic_id: string;
  layers: {
    hop: number;
    accounts: number;
    communities: { community_id: number; accounts: number }[];
    sample_nodes: string[];
  }[];
  lead_lag: Journey['lead_lag'];
  disclaimer: string;
}

export interface TopicDetail {
  topic: {
    id: string;
    label: string;
    description: string;
    keywords: string[];
    hashtags: string[];
    first_seen_at: string | null;
    last_seen_at: string | null;
  };
  post_count: number;
  trend: {
    trend_score: number;
    classification: TrendClass;
    velocity: Velocity;
    momentum: Momentum;
    components: TrendComponents;
    series: TrendSeriesPoint[];
  } | null;
  sentiment: {
    distribution: { sentiment: Sentiment; count: number; percentage: number }[];
    avg_polarity: number;
    sarcasm_rate: number;
  };
  keywords: { term: string; score: number; mentions: number; lift: number }[];
  audience: {
    segments: { segment_id: string; name: string; posts: number; percentage: number }[];
    age_brackets: { bracket: string; authors: number; percentage: number }[];
    regions: { region: string; authors: number; percentage: number }[];
  };
  platforms: PlatformBreakdown[];
  journey: Journey;
  top_accounts: {
    anon_id: string;
    posts: number;
    engagement: number;
    influence_score: number;
    community_id: number | null;
    is_bridge: boolean;
    segment: string;
  }[];
  intelligence: IntelligenceCard[];
  filters: FilterState;
}

export interface PostAnalysis {
  sentiment: Sentiment;
  sentiment_confidence: number;
  confidence_band: ConfidenceBand;
  polarity: number;
  emotion: string;
  emotion_confidence: number | null;
  stance: string;
  sarcasm_detected: boolean;
  sarcasm_confidence: number;
  literal_sentiment: string | null;
  contextual_sentiment: string | null;
  cues: {
    matched_terms?: string[];
    weighted_terms?: { term: string; weight: number; negated: boolean }[];
    sarcasm_signals?: string[];
    stance_signals?: string[];
    emotion_signals?: string[];
    raw_score?: number;
    token_count?: number;
    language_pack?: string;
  };
  model: string | null;
  model_version: string | null;
  status: string | null;
}

export interface PostItem {
  id: string;
  platform: string;
  author_anon_id: string;
  text: string;
  created_at: string;
  language: string;
  engagement: {
    total: number;
    likes: number;
    comments: number;
    shares: number;
    views: number;
  };
  topic_id: string | null;
  topic_label: string | null;
  is_reply: boolean;
  analysis: PostAnalysis | null;
}

export interface PostsResponse {
  items: PostItem[];
  page: number;
  page_size: number;
  total: number;
  pages: number;
  filters: FilterState;
}

export interface TimelineEvent {
  ts: string;
  kind: 'intelligence' | 'journey';
  category: string;
  title: string;
  detail: string;
  severity: Severity;
  topic_id: string | null;
  reference_id: string | null;
  platform?: string | null;
}

export interface TimelineResponse {
  events: TimelineEvent[];
  buckets: TimelinePoint[];
  filters: FilterState;
}

export interface SourceInfo {
  id: string;
  platform: string;
  display_name: string;
  tier: 'essential' | 'desirable' | 'appreciable' | 'synthetic';
  status: 'connected' | 'demo' | 'not_connected' | 'error';
  requires_credentials: boolean;
  credential_fields: string[];
  missing_credentials: string[];
  capabilities: string[];
  docs_url: string;
  live_ready: boolean;
  demo_available: boolean;
  post_count: number;
}

export interface AnalysisRunInfo {
  id: number;
  status: string;
  trigger: string;
  seed: number;
  started_at: string;
  finished_at: string | null;
  posts_ingested: number;
  authors_ingested: number;
  sentiment_model: string;
  stage_log: { stage: string; elapsed_ms: number; [key: string]: unknown }[];
  validation: Record<string, { passed: boolean; detail: string } | boolean>;
  error: string;
}

export interface SourcesResponse {
  sources: SourceInfo[];
  demo_mode: boolean;
  last_run: AnalysisRunInfo | null;
}

export interface HealthResponse {
  status: 'ok' | 'degraded';
  version: string;
  demo_mode: boolean;
  database: string;
  ai_provider: { provider: string; version: string; status: string; fallback?: string };
  dataset_ready: boolean;
  posts: number;
  last_run: AnalysisRunInfo | null;
}

export interface FilterOptions {
  platforms: { id: string; posts: number }[];
  topics: { id: string; label: string; posts: number }[];
  segments: { id: string; label: string; color: string; size: number }[];
  sentiments: string[];
  emotions: string[];
  granularities: Granularity[];
  ranges: string[];
  data_range: { start: string | null; end: string | null };
}

export interface SearchResult {
  type: 'topic' | 'segment' | 'account' | 'platform' | 'event' | 'post';
  id: string;
  label: string;
  detail: string;
  href: string;
}

export interface AnalyzeResult {
  text: string;
  sentiment: Sentiment;
  sentiment_confidence: number;
  confidence_band: ConfidenceBand;
  stance: string;
  emotion: string;
  emotion_confidence: number;
  polarity: number;
  literal_sentiment: string;
  contextual_sentiment: string;
  sarcasm_detected: boolean;
  sarcasm_confidence: number;
  cues: PostAnalysis['cues'];
  model: string;
  model_version: string;
  status: string;
}

export interface IngestionResponse {
  status: string;
  run: {
    id: number;
    seed: number;
    posts: number;
    authors: number;
    stages: { stage: string; elapsed_ms: number }[];
    model: string;
  };
  validation: Record<string, { passed: boolean; detail: string } | boolean>;
  message: string;
}
