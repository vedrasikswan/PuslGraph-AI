"""The data pipeline.

    INGEST -> NORMALIZE -> STORE -> ENRICH -> SENTIMENT -> TOPIC EXTRACTION
    -> DEMOGRAPHIC AGGREGATION -> NETWORK ANALYSIS -> TREND ANALYSIS
    -> INTELLIGENCE GENERATION

Each stage is a method, each stage logs what it produced, and the whole run is
recorded in `analysis_runs` so a dashboard number can always be traced back to
the run that computed it.
"""

from __future__ import annotations

import logging
import time
from collections import Counter, defaultdict
from datetime import datetime, timedelta

from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from app.ai.provider import AIProvider
from app.ai.registry import get_ai_provider
from app.analytics import demographics as demo
from app.analytics import network as net
from app.analytics import segments as seg
from app.analytics import topics as topic_mod
from app.analytics import trends as trend_mod
from app.analytics.intelligence import InsightEngine
from app.config import settings
from app.ingestion.base import IngestionBatch, NormalizedAuthor, NormalizedPost
from app.ingestion.registry import build_adapter
from app.models import (
    AnalysisRun,
    Author,
    AudienceSegment,
    AuthorSegment,
    DataSource,
    DemographicProfile,
    IntelligenceEvent,
    Interaction,
    NetworkMetric,
    Post,
    PostTopic,
    SentimentResult,
    Topic,
    TrendMetric,
    utcnow,
)

logger = logging.getLogger(__name__)

ANALYSIS_TABLES = (
    IntelligenceEvent, TrendMetric, NetworkMetric, AuthorSegment, AudienceSegment,
    DemographicProfile, PostTopic, SentimentResult, Interaction, Topic, Post, Author,
)


class Pipeline:
    def __init__(self, db: Session, provider: AIProvider | None = None) -> None:
        self.db = db
        self.provider = provider or get_ai_provider()
        self.stage_log: list[dict] = []
        self._t0 = time.perf_counter()

    # ------------------------------------------------------------------ #
    def _stage(self, name: str, detail: dict) -> None:
        elapsed = round((time.perf_counter() - self._t0) * 1000, 1)
        entry = {"stage": name, "elapsed_ms": elapsed, **detail}
        self.stage_log.append(entry)
        logger.info("pipeline stage %s: %s", name, detail)

    # ------------------------------------------------------------------ #
    def reset(self) -> None:
        for table in ANALYSIS_TABLES:
            self.db.execute(delete(table))
        self.db.commit()
        self._stage("reset", {"tables_cleared": len(ANALYSIS_TABLES)})

    # -- 1/2. INGEST + NORMALIZE --------------------------------------- #
    def ingest(self, source_ids: list[str]) -> tuple[list[NormalizedAuthor], list[NormalizedPost]]:
        authors: dict[str, NormalizedAuthor] = {}
        posts: list[NormalizedPost] = []
        batches: list[IngestionBatch] = []

        for source_id in source_ids:
            adapter = build_adapter(source_id, settings)
            batch = adapter.fetch(query="", limit=0)
            batches.append(batch)
            for author in batch.authors:
                authors.setdefault(author.author_id, author)
            posts.extend(batch.posts)

        self._stage("ingest", {
            "sources": [
                {"id": b.source_id, "status": b.status.value, "posts": len(b.posts),
                 "message": b.message}
                for b in batches
            ],
            "posts": len(posts),
            "authors": len(authors),
        })
        return list(authors.values()), posts

    # -- 3. STORE ------------------------------------------------------- #
    def store(self, authors: list[NormalizedAuthor], posts: list[NormalizedPost]) -> None:
        anon_index = {a.author_id: f"A{(abs(hash(a.author_id)) % 9000) + 1000}"
                      for a in sorted(authors, key=lambda x: x.author_id)}
        # Guarantee uniqueness of the pseudonymous label.
        seen: set[str] = set()
        for author_id, label in list(anon_index.items()):
            candidate = label
            bump = 0
            while candidate in seen:
                bump += 1
                candidate = f"A{(int(label[1:]) + bump) % 9000 + 1000}"
            seen.add(candidate)
            anon_index[author_id] = candidate

        counts = Counter(p.author_id for p in posts)
        self.db.add_all([
            Author(
                id=a.author_id,
                platform=a.platform,
                anon_id=anon_index[a.author_id],
                display_name=a.display_name,
                handle=a.handle,
                bio=a.bio,
                followers_count=a.followers_count,
                following_count=a.following_count,
                verified=a.verified,
                account_created_at=a.account_created_at,
                location_raw=a.location,
                primary_language=a.language,
                post_count=counts.get(a.author_id, 0),
            )
            for a in authors
        ])

        self.db.add_all([
            Post(
                id=p.id,
                platform=p.platform,
                source_id=p.source_id,
                author_id=p.author_id,
                text=p.text,
                created_at=p.timestamp,
                language=p.language,
                reply_to_id=p.reply_to_id,
                parent_post_id=p.parent_post_id,
                hashtags=p.hashtags,
                mentions=p.mentions,
                likes=p.likes,
                comments_count=p.comments,
                shares=p.shares,
                views=p.views,
                engagement_count=p.engagement_count,
                location=p.location,
            )
            for p in posts
        ])
        self.db.commit()
        self._stage("store", {"authors": len(authors), "posts": len(posts)})

    # -- 4. SENTIMENT --------------------------------------------------- #
    def analyse_sentiment(self) -> None:
        posts = self.db.execute(select(Post.id, Post.text, Post.language)).all()
        rows: list[SentimentResult] = []
        failures = 0
        for post_id, text, language in posts:
            try:
                result = self.provider.analyze_text(text, language)
            except Exception as exc:  # a provider must never break the pipeline
                logger.warning("Sentiment analysis failed for %s: %s", post_id, exc)
                failures += 1
                continue
            rows.append(SentimentResult(
                post_id=post_id,
                sentiment=result.sentiment,
                sentiment_confidence=result.sentiment_confidence,
                emotion=result.emotion,
                emotion_confidence=result.emotion_confidence,
                stance=result.stance,
                polarity=result.polarity,
                literal_sentiment=result.literal_sentiment,
                contextual_sentiment=result.contextual_sentiment,
                sarcasm_detected=result.sarcasm_detected,
                sarcasm_confidence=result.sarcasm_confidence,
                cues=result.cues,
                model=result.model,
                model_version=result.model_version,
                status=result.status,
            ))
        self.db.add_all(rows)
        self.db.commit()

        distribution = Counter(r.sentiment for r in rows)
        self._stage("sentiment", {
            "analysed": len(rows),
            "failed": failures,
            "model": self.provider.name,
            "distribution": dict(distribution),
            "sarcasm_flagged": sum(1 for r in rows if r.sarcasm_detected),
        })

    # -- 5. TOPIC EXTRACTION -------------------------------------------- #
    def extract_topics(self) -> None:
        posts = self.db.execute(
            select(Post.id, Post.text, Post.hashtags, Post.reply_to_id, Post.created_at)
            .order_by(Post.created_at)
        ).all()

        primary_of: dict[str, str] = {}
        links: list[PostTopic] = []
        seen_pairs: set[tuple[str, str]] = set()

        for post_id, text, hashtags, reply_to, _created in posts:
            parent_topic = primary_of.get(reply_to) if reply_to else None
            ranked = topic_mod.classify(text, hashtags or [], parent_topic)
            if not ranked:
                continue
            primary_of[post_id] = ranked[0][0]
            for index, (topic_id, relevance) in enumerate(ranked[:3]):
                if (post_id, topic_id) in seen_pairs:
                    continue
                seen_pairs.add((post_id, topic_id))
                links.append(PostTopic(post_id=post_id, topic_id=topic_id,
                                       relevance=relevance, is_primary=index == 0))
        self.db.add_all(links)

        # Topic registry rows with observed first/last activity.
        stats: dict[str, dict] = defaultdict(lambda: {"count": 0, "first": None, "last": None})
        post_times = {pid: created for pid, _t, _h, _r, created in posts}
        for link in links:
            if not link.is_primary:
                continue
            entry = stats[link.topic_id]
            entry["count"] += 1
            ts = post_times[link.post_id]
            entry["first"] = ts if entry["first"] is None else min(entry["first"], ts)
            entry["last"] = ts if entry["last"] is None else max(entry["last"], ts)

        for definition in topic_mod.TOPIC_DEFINITIONS:
            entry = stats.get(definition["id"], {"count": 0, "first": None, "last": None})
            self.db.add(Topic(
                id=definition["id"],
                label=definition["label"],
                description=definition["description"],
                keywords=definition["keywords"],
                hashtags=definition["hashtags"],
                first_seen_at=entry["first"],
                last_seen_at=entry["last"],
                post_count=entry["count"],
            ))
        self.db.commit()

        classified = len(primary_of)
        self._stage("topics", {
            "classified_posts": classified,
            "unclassified_posts": len(posts) - classified,
            "topics_with_activity": sum(1 for s in stats.values() if s["count"] > 0),
            "assignments": len(links),
        })

    # -- 6. ENRICH: interaction graph ----------------------------------- #
    def build_interactions(self) -> None:
        posts = self.db.execute(
            select(Post.id, Post.author_id, Post.platform, Post.reply_to_id,
                   Post.parent_post_id, Post.mentions, Post.created_at, Post.shares)
        ).all()
        author_of = {p.id: p.author_id for p in posts}
        primary_topic = dict(self.db.execute(
            select(PostTopic.post_id, PostTopic.topic_id).where(PostTopic.is_primary.is_(True))
        ).all())

        handle_rows = self.db.execute(select(Author.id, Author.handle, Author.platform)).all()
        by_handle: dict[tuple[str, str], str] = {}
        by_handle_any: dict[str, str] = {}
        for author_id, handle, platform in handle_rows:
            if handle:
                by_handle[(platform, handle.lower())] = author_id
                by_handle_any.setdefault(handle.lower(), author_id)

        rows: list[Interaction] = []
        for post in posts:
            topic_id = primary_topic.get(post.id)

            if post.reply_to_id and post.reply_to_id in author_of:
                target = author_of[post.reply_to_id]
                if target != post.author_id:
                    rows.append(Interaction(
                        source_author_id=post.author_id, target_author_id=target,
                        interaction_type="reply", post_id=post.id, platform=post.platform,
                        topic_id=topic_id, created_at=post.created_at, weight=1.0,
                    ))

            if post.parent_post_id and post.parent_post_id != post.reply_to_id:
                target = author_of.get(post.parent_post_id)
                if target and target != post.author_id:
                    rows.append(Interaction(
                        source_author_id=post.author_id, target_author_id=target,
                        interaction_type="repost", post_id=post.id, platform=post.platform,
                        topic_id=topic_id, created_at=post.created_at, weight=1.4,
                    ))

            for handle in post.mentions or []:
                target = by_handle.get((post.platform, handle.lower())) or by_handle_any.get(
                    handle.lower()
                )
                if target and target != post.author_id:
                    rows.append(Interaction(
                        source_author_id=post.author_id, target_author_id=target,
                        interaction_type="mention", post_id=post.id, platform=post.platform,
                        topic_id=topic_id, created_at=post.created_at, weight=0.8,
                    ))

        self.db.add_all(rows)
        self.db.commit()
        kinds = Counter(r.interaction_type for r in rows)
        self._stage("interactions", {"edges": len(rows), "by_type": dict(kinds)})

    # -- 7. NETWORK ANALYSIS -------------------------------------------- #
    def analyse_network(self) -> dict[str, net.NodeMetrics]:
        edges = [
            net.Edge(source=r.source_author_id, target=r.target_author_id,
                     kind=r.interaction_type, weight=r.weight, topic_id=r.topic_id)
            for r in self.db.execute(select(Interaction)).scalars()
        ]
        followers = dict(self.db.execute(select(Author.id, Author.followers_count)).all())
        metrics = net.compute_metrics(edges, followers)

        self.db.add_all([
            NetworkMetric(
                author_id=m.author_id, degree=m.degree, in_degree=m.in_degree,
                out_degree=m.out_degree, degree_centrality=m.degree_centrality,
                betweenness=m.betweenness, pagerank=m.pagerank,
                influence_score=m.influence_score, community_id=m.community_id,
                is_bridge=m.is_bridge, reach=m.reach,
            )
            for m in metrics.values()
        ])
        self.db.commit()

        communities = len({m.community_id for m in metrics.values()})
        self._stage("network", {
            "nodes": len(metrics),
            "edges": len(edges),
            "communities": communities,
            "bridge_nodes": sum(1 for m in metrics.values() if m.is_bridge),
        })
        return metrics

    # -- 8. DEMOGRAPHICS ------------------------------------------------- #
    def infer_demographics(self) -> list[demo.InferredProfile]:
        authors = self.db.execute(select(Author)).scalars().all()
        posts = self.db.execute(
            select(Post.author_id, Post.language, Post.engagement_count, Post.reply_to_id,
                   Post.shares, Post.id)
        ).all()
        topic_links = self.db.execute(
            select(PostTopic.post_id, PostTopic.topic_id).where(PostTopic.is_primary.is_(True))
        ).all()
        topic_of = dict(topic_links)

        by_author: dict[str, dict] = defaultdict(
            lambda: {"languages": Counter(), "engagement": 0, "replies": 0,
                     "shares": 0, "count": 0, "topics": Counter()}
        )
        for author_id, language, engagement, reply_to, shares, post_id in posts:
            entry = by_author[author_id]
            entry["languages"][language] += 1
            entry["engagement"] += engagement
            entry["count"] += 1
            entry["replies"] += 1 if reply_to else 0
            entry["shares"] += shares
            topic = topic_of.get(post_id)
            if topic:
                entry["topics"][topic] += 1

        now = utcnow()
        profiles: list[demo.InferredProfile] = []
        for author in authors:
            stats = by_author.get(author.id)
            if not stats or stats["count"] == 0:
                continue
            total_engagement = stats["engagement"]
            profile = demo.infer_profile(
                author_id=author.id,
                bio=author.bio or "",
                followers=author.followers_count,
                account_created_at=author.account_created_at,
                location_raw=author.location_raw or "",
                languages=stats["languages"],
                post_count=stats["count"],
                avg_engagement=total_engagement / stats["count"],
                reply_ratio=stats["replies"] / stats["count"],
                share_ratio=min(1.0, stats["shares"] / max(total_engagement, 1)),
                topic_affinity=[t for t, _ in stats["topics"].most_common(3)],
                now=now,
            )
            profiles.append(profile)

        self.db.add_all([
            DemographicProfile(
                author_id=p.author_id, age_bracket=p.age_bracket,
                age_confidence=p.age_confidence, region=p.region,
                region_confidence=p.region_confidence, language=p.language,
                professional_interest=p.professional_interest,
                interest_confidence=p.interest_confidence,
                engagement_behaviour=p.engagement_behaviour, evidence=p.evidence,
                model=p.model, model_version=p.model_version,
            )
            for p in profiles
        ])
        self.db.commit()

        self._stage("demographics", {
            "profiles": len(profiles),
            "age_distribution": {r["value"]: r["percentage"]
                                 for r in demo.aggregate(profiles, "age_bracket")},
            "regions": len({p.region for p in profiles}),
        })
        return profiles

    # -- 9. SEGMENTATION ------------------------------------------------- #
    def build_segments(self, metrics: dict[str, net.NodeMetrics]) -> None:
        rows = self.db.execute(
            select(Post.author_id, Post.text, Post.engagement_count, Post.shares,
                   Post.reply_to_id, Post.parent_post_id, Post.platform, Post.language,
                   SentimentResult.polarity, SentimentResult.sentiment, PostTopic.topic_id)
            .join(SentimentResult, SentimentResult.post_id == Post.id, isouter=True)
            .join(PostTopic,
                  (PostTopic.post_id == Post.id) & (PostTopic.is_primary.is_(True)),
                  isouter=True)
        ).all()

        agg: dict[str, dict] = defaultdict(
            lambda: {"texts": [], "engagement": 0, "count": 0, "negative": 0,
                     "amplified": 0, "topics": Counter(), "platforms": Counter(),
                     "languages": Counter(), "polarity": 0.0}
        )
        for r in rows:
            entry = agg[r.author_id]
            entry["texts"].append(r.text)
            entry["engagement"] += r.engagement_count
            entry["count"] += 1
            entry["polarity"] += r.polarity or 0.0
            if r.sentiment == "negative":
                entry["negative"] += 1
            if r.parent_post_id or r.shares > 0:
                entry["amplified"] += 1
            if r.topic_id:
                entry["topics"][r.topic_id] += 1
            entry["platforms"][r.platform] += 1
            entry["languages"][r.language] += 1

        followers = dict(self.db.execute(select(Author.id, Author.followers_count)).all())
        reach_values = sorted(
            (followers.get(a, 0) + agg[a]["engagement"]) for a in agg
        )
        activity_values = sorted(agg[a]["count"] for a in agg)

        def pct(sorted_values: list[float], value: float) -> float:
            if not sorted_values:
                return 0.0
            below = sum(1 for v in sorted_values if v < value)
            return below / len(sorted_values)

        assignments: list[AuthorSegment] = []
        features_by_author: dict[str, seg.AuthorFeatures] = {}
        for author_id, entry in agg.items():
            reach_raw = followers.get(author_id, 0) + entry["engagement"]
            features = seg.AuthorFeatures(
                author_id=author_id,
                reach=round(pct(reach_values, reach_raw), 4),
                activity=round(pct(activity_values, entry["count"]), 4),
                negativity=round(entry["negative"] / entry["count"], 4),
                amplification=round(entry["amplified"] / entry["count"], 4),
                technicality=round(seg.technical_density(entry["texts"]), 4),
                influence=metrics[author_id].influence_score if author_id in metrics else 0.0,
                dominant_topic=entry["topics"].most_common(1)[0][0] if entry["topics"] else "",
                post_count=entry["count"],
                avg_engagement=entry["engagement"] / entry["count"],
            )
            features_by_author[author_id] = features
            segment_id, fit, rationale = seg.assign_segment(features)
            assignments.append(AuthorSegment(author_id=author_id, segment_id=segment_id,
                                             score=fit, rationale=rationale))
        self.db.add_all(assignments)
        self.db.commit()

        self._persist_segment_rollups(assignments, agg, metrics)
        self._stage("segments", {
            "assigned_authors": len(assignments),
            "segments": dict(Counter(a.segment_id for a in assignments)),
        })

    def _persist_segment_rollups(
        self,
        assignments: list[AuthorSegment],
        agg: dict[str, dict],
        metrics: dict[str, net.NodeMetrics],
    ) -> None:
        profiles = {
            p.author_id: p for p in self.db.execute(select(DemographicProfile)).scalars()
        }
        anon = dict(self.db.execute(select(Author.id, Author.anon_id)).all())
        members: dict[str, list[str]] = defaultdict(list)
        for assignment in assignments:
            members[assignment.segment_id].append(assignment.author_id)

        sentiment_rows = self.db.execute(
            select(Post.author_id, Post.created_at, SentimentResult.polarity)
            .join(SentimentResult, SentimentResult.post_id == Post.id)
        ).all()
        by_author_series: dict[str, list[tuple[datetime, float]]] = defaultdict(list)
        for author_id, created_at, polarity in sentiment_rows:
            by_author_series[author_id].append((created_at, polarity))

        for prototype in seg.PROTOTYPES:
            author_ids = members.get(prototype.id, [])
            if not author_ids:
                self.db.add(AudienceSegment(
                    id=prototype.id, name=prototype.name, description=prototype.description,
                    color=prototype.color, size=0,
                ))
                continue

            topics: Counter[str] = Counter()
            platforms: Counter[str] = Counter()
            languages: Counter[str] = Counter()
            regions: Counter[str] = Counter()
            ages: Counter[str] = Counter()
            polarity_sum = 0.0
            post_total = 0
            engagement_total = 0

            for author_id in author_ids:
                entry = agg.get(author_id)
                if entry:
                    topics.update(entry["topics"])
                    platforms.update(entry["platforms"])
                    languages.update(entry["languages"])
                    polarity_sum += entry["polarity"]
                    post_total += entry["count"]
                    engagement_total += entry["engagement"]
                profile = profiles.get(author_id)
                if profile:
                    regions[profile.region] += 1
                    ages[profile.age_bracket] += 1

            avg_polarity = polarity_sum / post_total if post_total else 0.0
            dominant = ("negative" if avg_polarity <= -0.12
                        else "positive" if avg_polarity >= 0.12 else "neutral")
            avg_engagement = engagement_total / post_total if post_total else 0.0
            level = ("high" if avg_engagement > 260 else
                     "medium" if avg_engagement > 60 else "low")

            top_nodes = sorted(
                (metrics[a] for a in author_ids if a in metrics),
                key=lambda m: m.influence_score, reverse=True,
            )[:5]

            series = self._segment_sentiment_series(author_ids, by_author_series)

            self.db.add(AudienceSegment(
                id=prototype.id,
                name=prototype.name,
                description=prototype.description,
                color=prototype.color,
                size=len(author_ids),
                dominant_sentiment=dominant,
                avg_polarity=round(avg_polarity, 4),
                engagement_level=level,
                avg_engagement=round(avg_engagement, 2),
                dominant_topics=[{"topic_id": t, "posts": c} for t, c in topics.most_common(5)],
                languages=[{"language": lg, "posts": c} for lg, c in languages.most_common(5)],
                regions=[{"region": r, "authors": c} for r, c in regions.most_common(6)],
                age_distribution=[{"bracket": b, "authors": c} for b, c in ages.most_common()],
                platforms=[{"platform": p, "posts": c} for p, c in platforms.most_common()],
                influential_nodes=[
                    {"author_id": m.author_id, "anon_id": anon.get(m.author_id, "A?"),
                     "influence_score": m.influence_score, "is_bridge": m.is_bridge}
                    for m in top_nodes
                ],
                sentiment_trend=series,
            ))
        self.db.commit()

    @staticmethod
    def _segment_sentiment_series(
        author_ids: list[str], by_author: dict[str, list[tuple[datetime, float]]]
    ) -> list[dict]:
        points: list[tuple[datetime, float]] = []
        for author_id in author_ids:
            points.extend(by_author.get(author_id, []))
        if not points:
            return []
        points.sort(key=lambda kv: kv[0])
        start, end = points[0][0], points[-1][0]
        size = trend_mod.bucket_size_for((end - start).total_seconds() / 3600.0)
        buckets: dict[datetime, list[float]] = defaultdict(list)
        for ts, polarity in points:
            seconds = int(size.total_seconds())
            epoch = int(ts.timestamp())
            key = datetime.fromtimestamp(epoch - epoch % seconds)
            buckets[key].append(polarity)
        return [
            {"ts": key.isoformat(), "avg_polarity": round(sum(v) / len(v), 4), "posts": len(v)}
            for key, v in sorted(buckets.items())
        ]

    # -- 10. TREND ANALYSIS ---------------------------------------------- #
    def analyse_trends(self, metrics: dict[str, net.NodeMetrics]) -> list[trend_mod.TrendResult]:
        rows = self.db.execute(
            select(Post.created_at, Post.author_id, Post.platform, Post.engagement_count,
                   SentimentResult.polarity, PostTopic.topic_id)
            .join(PostTopic, (PostTopic.post_id == Post.id) & (PostTopic.is_primary.is_(True)))
            .join(SentimentResult, SentimentResult.post_id == Post.id, isouter=True)
        ).all()
        if not rows:
            self._stage("trends", {"topics": 0})
            return []

        by_topic: dict[str, list[trend_mod.TopicObservation]] = defaultdict(list)
        for created_at, author_id, platform, engagement, polarity, topic_id in rows:
            by_topic[topic_id].append(trend_mod.TopicObservation(
                timestamp=created_at, author_id=author_id, platform=platform,
                engagement=engagement, polarity=polarity or 0.0,
                influence_score=metrics[author_id].influence_score if author_id in metrics else 0.0,
            ))

        influence_values = sorted((m.influence_score for m in metrics.values()), reverse=True)
        cut = influence_values[max(0, len(influence_values) // 20 - 1)] if influence_values else 0.0
        influencer_ids = {a for a, m in metrics.items() if m.influence_score >= cut and cut > 0}

        latest = max(r[0] for r in rows)
        window_start = latest - timedelta(hours=24)

        results: list[trend_mod.TrendResult] = []
        for topic_id, observations in by_topic.items():
            result = trend_mod.analyse_topic(
                topic_id, observations, window_start, latest, influencer_ids
            )
            results.append(result)
            self.db.add(TrendMetric(
                topic_id=topic_id, window_start=result.window_start, window_end=result.window_end,
                mentions=result.mentions, prev_mentions=result.prev_mentions,
                growth_rate=result.growth_rate, acceleration=result.acceleration,
                engagement_velocity=result.engagement_velocity,
                unique_authors=result.unique_authors,
                prev_unique_authors=result.prev_unique_authors,
                author_growth=result.author_growth, sentiment_shift=result.sentiment_shift,
                platform_count=result.platform_count,
                influencer_participation=result.influencer_participation,
                persistence=result.persistence, trend_score=result.trend_score,
                classification=result.classification, momentum=result.momentum,
                momentum_confidence=result.momentum_confidence, components=result.components,
            ))
        self.db.commit()

        self._stage("trends", {
            "topics": len(results),
            "classifications": dict(Counter(r.classification for r in results)),
            "top": sorted(((r.topic_id, r.trend_score) for r in results),
                          key=lambda kv: kv[1], reverse=True)[:3],
        })
        return results

    # -- 11. INTELLIGENCE ------------------------------------------------ #
    def generate_intelligence(
        self, trend_results: list[trend_mod.TrendResult], metrics: dict[str, net.NodeMetrics]
    ) -> list[IntelligenceEvent]:
        engine = InsightEngine(self.db, self.provider)
        events = engine.run(trend_results, metrics)
        self.db.add_all(events)
        self.db.commit()
        self._stage("intelligence", {
            "events": len(events),
            "by_category": dict(Counter(e.category for e in events)),
            "by_severity": dict(Counter(e.severity for e in events)),
        })
        return events

    # -- source bookkeeping ---------------------------------------------- #
    def refresh_sources(self, descriptions: list[dict]) -> None:
        self.db.execute(delete(DataSource))
        counts = dict(self.db.execute(
            select(Post.platform, func.count(Post.id)).group_by(Post.platform)
        ).all())
        for info in descriptions:
            self.db.add(DataSource(
                id=info["id"], platform=info["platform"], display_name=info["display_name"],
                tier=info["tier"], status=info["status"],
                requires_credentials=info["requires_credentials"],
                credential_fields=info["credential_fields"],
                capabilities=info["capabilities"],
                notes=(
                    "Live credentials present." if info.get("live_ready")
                    else "Running on demo data. Add credentials to enable live ingestion."
                ),
                last_sync_at=utcnow(),
                post_count=counts.get(info["platform"], 0),
            ))
        self.db.commit()

    # -- validation ------------------------------------------------------- #
    def validate(self) -> dict:
        """Seed-data validation. Every check is a real query against what was
        actually stored."""
        post_count = self.db.scalar(select(func.count(Post.id))) or 0
        platforms = [p for (p,) in self.db.execute(
            select(Post.platform).group_by(Post.platform)).all()]
        topics_active = self.db.scalar(
            select(func.count(func.distinct(PostTopic.topic_id)))) or 0
        sentiments = dict(self.db.execute(
            select(SentimentResult.sentiment, func.count(SentimentResult.id))
            .group_by(SentimentResult.sentiment)).all())
        interactions = self.db.scalar(select(func.count(Interaction.id))) or 0
        segments = self.db.scalar(
            select(func.count(AudienceSegment.id)).where(AudienceSegment.size > 0)) or 0
        accelerating = self.db.scalar(
            select(func.count(TrendMetric.id))
            .where(TrendMetric.classification.in_(["accelerating", "viral", "growing"]))) or 0
        influencers = self.db.scalar(
            select(func.count(NetworkMetric.id)).where(NetworkMetric.influence_score > 0)) or 0
        bridges = self.db.scalar(
            select(func.count(NetworkMetric.id)).where(NetworkMetric.is_bridge.is_(True))) or 0
        sarcasm = self.db.scalar(
            select(func.count(SentimentResult.id))
            .where(SentimentResult.sarcasm_detected.is_(True))) or 0

        cross_platform = self.db.execute(
            select(PostTopic.topic_id, func.count(func.distinct(Post.platform)).label("n"))
            .join(Post, Post.id == PostTopic.post_id)
            .where(PostTopic.is_primary.is_(True))
            .group_by(PostTopic.topic_id)
        ).all()
        multi_platform_topics = sum(1 for _t, n in cross_platform if n >= 3)

        checks = {
            "minimum_posts": (post_count >= 500, f"{post_count} posts"),
            "multiple_platforms": (len(platforms) >= 4, f"{len(platforms)} platforms"),
            "multiple_topics": (topics_active >= 4, f"{topics_active} topics with activity"),
            "sentiment_distribution": (len(sentiments) >= 3, f"{sentiments}"),
            "interaction_graph": (interactions >= 200, f"{interactions} edges"),
            "audience_segments": (segments >= 3, f"{segments} populated segments"),
            "trend_acceleration": (accelerating >= 1, f"{accelerating} growing/accelerating topics"),
            "influencers_present": (influencers >= 1, f"{influencers} scored nodes"),
            "bridge_nodes_present": (bridges >= 1, f"{bridges} bridge nodes"),
            "cross_platform_topic": (multi_platform_topics >= 1,
                                     f"{multi_platform_topics} topics on 3+ platforms"),
            "sarcasm_detected": (sarcasm >= 1, f"{sarcasm} posts flagged sarcastic"),
        }
        report = {
            name: {"passed": bool(passed), "detail": detail}
            for name, (passed, detail) in checks.items()
        }
        report["all_passed"] = all(v["passed"] for v in report.values() if isinstance(v, dict))
        self._stage("validation", {"all_passed": report["all_passed"]})
        return report

    # -- orchestration ---------------------------------------------------- #
    def run(self, source_ids: list[str], trigger: str = "manual") -> AnalysisRun:
        from app.ingestion.registry import describe_sources

        run = AnalysisRun(trigger=trigger, seed=settings.demo_seed,
                          sentiment_model=self.provider.name, status="running")
        self.db.add(run)
        self.db.commit()

        try:
            self.reset()
            authors, posts = self.ingest(source_ids)
            if not posts:
                raise ValueError("No posts were ingested from the selected sources.")
            self.store(authors, posts)
            self.analyse_sentiment()
            self.extract_topics()
            self.build_interactions()
            metrics = self.analyse_network()
            self.infer_demographics()
            self.build_segments(metrics)
            trend_results = self.analyse_trends(metrics)
            self.generate_intelligence(trend_results, metrics)
            self.refresh_sources(describe_sources(settings))
            validation = self.validate()

            run.posts_ingested = len(posts)
            run.authors_ingested = len(authors)
            run.status = "completed" if validation["all_passed"] else "completed_with_warnings"
            run.validation = validation
        except Exception as exc:
            logger.exception("Pipeline failed")
            run.status = "failed"
            run.error = str(exc)
            self.db.rollback()
            raise
        finally:
            run.stage_log = self.stage_log
            run.finished_at = utcnow()
            self.db.add(run)
            self.db.commit()

        return run
