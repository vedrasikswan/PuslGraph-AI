"""Concrete platform adapters.

Each adapter declares the credentials it needs and how it maps a platform
payload onto `NormalizedPost`. The mapping functions are real and unit-testable
even though the demo never calls the network: `normalize_*` takes a raw API
payload and returns the internal schema, so wiring a live key later is a
configuration change rather than a rewrite.
"""

from __future__ import annotations

from datetime import datetime, timezone

from app.ingestion.base import (
    IngestionBatch,
    LiveApiAdapter,
    NormalizedAuthor,
    NormalizedPost,
    SourceTier,
)


def _parse_iso(value: str | None) -> datetime:
    if not value:
        return datetime.now(timezone.utc).replace(tzinfo=None)
    cleaned = value.replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(cleaned)
    except ValueError:
        return datetime.now(timezone.utc).replace(tzinfo=None)
    if parsed.tzinfo is not None:
        parsed = parsed.astimezone(timezone.utc).replace(tzinfo=None)
    return parsed


def _parse_epoch(value: float | int | None) -> datetime:
    if value is None:
        return datetime.now(timezone.utc).replace(tzinfo=None)
    return datetime.fromtimestamp(float(value), tz=timezone.utc).replace(tzinfo=None)


# --------------------------------------------------------------------------- #
# X / Twitter  (Essential)
# --------------------------------------------------------------------------- #
class XAdapter(LiveApiAdapter):
    source_id = "x"
    platform = "x"
    display_name = "X (Twitter)"
    tier = SourceTier.ESSENTIAL
    credential_fields = ("x_bearer_token",)
    capabilities = ("posts", "replies", "reposts", "public_metrics", "author_profile")
    docs_url = "https://developer.x.com/en/docs/x-api"

    @staticmethod
    def normalize(payload: dict, includes: dict | None = None) -> NormalizedPost:
        """Map an X API v2 tweet object onto the internal schema."""
        includes = includes or {}
        metrics = payload.get("public_metrics", {}) or {}
        entities = payload.get("entities", {}) or {}
        author_id = str(payload.get("author_id", ""))
        users = {str(u.get("id")): u for u in includes.get("users", [])}
        author = users.get(author_id, {})

        reply_to = None
        parent = None
        for ref in payload.get("referenced_tweets", []) or []:
            if ref.get("type") == "replied_to":
                reply_to = str(ref.get("id"))
            elif ref.get("type") in {"retweeted", "quoted"}:
                parent = str(ref.get("id"))

        geo = payload.get("geo", {}) or {}
        place_id = geo.get("place_id", "")
        places = {str(p.get("id")): p for p in includes.get("places", [])}
        location = places.get(str(place_id), {}).get("full_name", "") if place_id else ""

        return NormalizedPost(
            id=f"x:{payload.get('id')}",
            platform="x",
            author_id=f"x:{author_id}",
            author_name=author.get("username", author_id),
            text=payload.get("text", ""),
            timestamp=_parse_iso(payload.get("created_at")),
            language=payload.get("lang", "en"),
            reply_to_id=f"x:{reply_to}" if reply_to else None,
            parent_post_id=f"x:{parent}" if parent else None,
            hashtags=[h["tag"].lower() for h in entities.get("hashtags", []) or []],
            mentions=[m["username"] for m in entities.get("mentions", []) or []],
            likes=int(metrics.get("like_count", 0)),
            comments=int(metrics.get("reply_count", 0)),
            shares=int(metrics.get("retweet_count", 0)),
            views=int(metrics.get("impression_count", 0)),
            location=location,
            source_id="x",
        )

    def _fetch_live(self, query: str, limit: int) -> IngestionBatch:  # pragma: no cover
        import httpx

        params = {
            "query": query,
            "max_results": min(max(limit, 10), 100),
            "tweet.fields": "created_at,lang,public_metrics,entities,referenced_tweets,geo,author_id",
            "expansions": "author_id,geo.place_id",
            "user.fields": "username,description,public_metrics,verified,created_at,location",
        }
        headers = {"Authorization": f"Bearer {self.credentials['x_bearer_token']}"}
        with httpx.Client(timeout=20) as client:
            resp = client.get(
                "https://api.x.com/2/tweets/search/recent", params=params, headers=headers
            )
            resp.raise_for_status()
            body = resp.json()

        includes = body.get("includes", {})
        posts = [self.normalize(item, includes) for item in body.get("data", [])]
        authors = [
            NormalizedAuthor(
                author_id=f"x:{u.get('id')}",
                platform="x",
                display_name=u.get("name", u.get("username", "")),
                handle=u.get("username", ""),
                bio=u.get("description", ""),
                followers_count=int((u.get("public_metrics") or {}).get("followers_count", 0)),
                following_count=int((u.get("public_metrics") or {}).get("following_count", 0)),
                verified=bool(u.get("verified")),
                account_created_at=_parse_iso(u.get("created_at")),
                location=u.get("location", ""),
            )
            for u in includes.get("users", [])
        ]
        return IngestionBatch(self.source_id, self.platform, self.status(), posts, authors)


# --------------------------------------------------------------------------- #
# Telegram  (Essential)
# --------------------------------------------------------------------------- #
class TelegramAdapter(LiveApiAdapter):
    source_id = "telegram"
    platform = "telegram"
    display_name = "Telegram (public channels)"
    tier = SourceTier.ESSENTIAL
    credential_fields = ("telegram_api_id", "telegram_api_hash")
    capabilities = ("channel_messages", "replies", "forwards", "views")
    docs_url = "https://core.telegram.org/api"

    @staticmethod
    def normalize(message: dict, channel: dict | None = None) -> NormalizedPost:
        """Map a Telegram (MTProto/Telethon) message dict onto the internal schema.

        Only public channel content is in scope - private messages are never
        ingested by this platform.
        """
        channel = channel or {}
        channel_name = channel.get("username") or channel.get("title", "channel")
        sender = message.get("sender_id") or channel.get("id") or channel_name
        reply_to = message.get("reply_to_msg_id")
        return NormalizedPost(
            id=f"tg:{channel.get('id', 'c')}:{message.get('id')}",
            platform="telegram",
            author_id=f"tg:{sender}",
            author_name=str(channel_name),
            text=message.get("message", "") or "",
            timestamp=_parse_iso(message.get("date")),
            language=message.get("lang", "en"),
            reply_to_id=f"tg:{channel.get('id', 'c')}:{reply_to}" if reply_to else None,
            likes=int(message.get("reactions_count", 0)),
            comments=int(message.get("replies_count", 0)),
            shares=int(message.get("forwards", 0)),
            views=int(message.get("views", 0)),
            source_id="telegram",
        )

    def _fetch_live(self, query: str, limit: int) -> IngestionBatch:  # pragma: no cover
        raise NotImplementedError(
            "Telegram live ingestion requires an MTProto session (Telethon). "
            "Install telethon, authorise a session, and map messages through "
            "TelegramAdapter.normalize()."
        )


# --------------------------------------------------------------------------- #
# Instagram / Facebook  (Desirable)
# --------------------------------------------------------------------------- #
class InstagramAdapter(LiveApiAdapter):
    source_id = "instagram"
    platform = "instagram"
    display_name = "Instagram (Graph API)"
    tier = SourceTier.DESIRABLE
    credential_fields = ("instagram_access_token",)
    capabilities = ("media_comments", "captions", "like_count")
    docs_url = "https://developers.facebook.com/docs/instagram-api"

    @staticmethod
    def normalize(comment: dict, media: dict | None = None) -> NormalizedPost:
        media = media or {}
        user = comment.get("from", {}) or {}
        return NormalizedPost(
            id=f"ig:{comment.get('id')}",
            platform="instagram",
            author_id=f"ig:{user.get('id', 'anon')}",
            author_name=user.get("username", "instagram_user"),
            text=comment.get("text", ""),
            timestamp=_parse_iso(comment.get("timestamp")),
            parent_post_id=f"ig:{media.get('id')}" if media.get("id") else None,
            likes=int(comment.get("like_count", 0)),
            comments=len(comment.get("replies", {}).get("data", []) or []),
            source_id="instagram",
        )

    def _fetch_live(self, query: str, limit: int) -> IngestionBatch:  # pragma: no cover
        raise NotImplementedError(
            "Instagram ingestion requires a Business account and an approved "
            "Graph API app with instagram_basic + instagram_manage_comments."
        )


class FacebookAdapter(LiveApiAdapter):
    source_id = "facebook"
    platform = "facebook"
    display_name = "Facebook (Pages Graph API)"
    tier = SourceTier.DESIRABLE
    credential_fields = ("facebook_access_token",)
    capabilities = ("page_posts", "comments", "reactions", "shares")
    docs_url = "https://developers.facebook.com/docs/graph-api"

    @staticmethod
    def normalize(item: dict, page: dict | None = None) -> NormalizedPost:
        page = page or {}
        user = item.get("from", {}) or {}
        return NormalizedPost(
            id=f"fb:{item.get('id')}",
            platform="facebook",
            author_id=f"fb:{user.get('id', 'anon')}",
            author_name=user.get("name", "facebook_user"),
            text=item.get("message", "") or item.get("story", ""),
            timestamp=_parse_iso(item.get("created_time")),
            parent_post_id=f"fb:{page.get('id')}" if page.get("id") else None,
            likes=int((item.get("reactions", {}) or {}).get("summary", {}).get("total_count", 0)),
            comments=int((item.get("comments", {}) or {}).get("summary", {}).get("total_count", 0)),
            shares=int((item.get("shares", {}) or {}).get("count", 0)),
            source_id="facebook",
        )

    def _fetch_live(self, query: str, limit: int) -> IngestionBatch:  # pragma: no cover
        raise NotImplementedError(
            "Facebook ingestion requires a Page access token with pages_read_engagement."
        )


# --------------------------------------------------------------------------- #
# Reddit / YouTube  (Appreciable)
# --------------------------------------------------------------------------- #
class RedditAdapter(LiveApiAdapter):
    source_id = "reddit"
    platform = "reddit"
    display_name = "Reddit (PRAW)"
    tier = SourceTier.APPRECIABLE
    credential_fields = ("reddit_client_id", "reddit_client_secret")
    capabilities = ("submissions", "comments", "score", "subreddit_context")
    docs_url = "https://praw.readthedocs.io"

    @staticmethod
    def normalize(item: dict) -> NormalizedPost:
        """Map a Reddit submission or comment onto the internal schema."""
        is_comment = "body" in item
        text = item.get("body") if is_comment else (
            f"{item.get('title', '')} {item.get('selftext', '')}".strip()
        )
        parent = item.get("link_id") or item.get("parent_id")
        return NormalizedPost(
            id=f"rd:{item.get('id')}",
            platform="reddit",
            author_id=f"rd:{item.get('author', 'deleted')}",
            author_name=str(item.get("author", "[deleted]")),
            text=text or "",
            timestamp=_parse_epoch(item.get("created_utc")),
            reply_to_id=f"rd:{str(parent).split('_')[-1]}" if is_comment and parent else None,
            parent_post_id=f"rd:{str(parent).split('_')[-1]}" if parent else None,
            likes=int(item.get("score", 0)),
            comments=int(item.get("num_comments", 0)),
            location="",
            source_id="reddit",
        )

    def _fetch_live(self, query: str, limit: int) -> IngestionBatch:  # pragma: no cover
        raise NotImplementedError(
            "Reddit ingestion requires praw with a registered script app."
        )


class YouTubeAdapter(LiveApiAdapter):
    source_id = "youtube"
    platform = "youtube"
    display_name = "YouTube (Data API v3)"
    tier = SourceTier.APPRECIABLE
    credential_fields = ("youtube_api_key",)
    capabilities = ("video_comments", "replies", "like_count")
    docs_url = "https://developers.google.com/youtube/v3"

    @staticmethod
    def normalize(item: dict) -> NormalizedPost:
        """Map a commentThread / comment resource onto the internal schema."""
        top = item.get("snippet", {})
        if "topLevelComment" in top:
            comment = top["topLevelComment"]["snippet"]
            comment_id = item.get("id")
            reply_to = None
        else:
            comment = top
            comment_id = item.get("id")
            reply_to = top.get("parentId")
        return NormalizedPost(
            id=f"yt:{comment_id}",
            platform="youtube",
            author_id=f"yt:{comment.get('authorChannelId', {}).get('value', 'anon')}",
            author_name=comment.get("authorDisplayName", "viewer"),
            text=comment.get("textOriginal", comment.get("textDisplay", "")),
            timestamp=_parse_iso(comment.get("publishedAt")),
            reply_to_id=f"yt:{reply_to}" if reply_to else None,
            parent_post_id=f"yt:{comment.get('videoId')}" if comment.get("videoId") else None,
            likes=int(comment.get("likeCount", 0)),
            comments=int(top.get("totalReplyCount", 0)),
            source_id="youtube",
        )

    def _fetch_live(self, query: str, limit: int) -> IngestionBatch:  # pragma: no cover
        import httpx

        params = {
            "part": "snippet",
            "searchTerms": query,
            "maxResults": min(limit, 100),
            "key": self.credentials["youtube_api_key"],
        }
        with httpx.Client(timeout=20) as client:
            resp = client.get(
                "https://www.googleapis.com/youtube/v3/commentThreads", params=params
            )
            resp.raise_for_status()
            body = resp.json()
        posts = [self.normalize(item) for item in body.get("items", [])]
        return IngestionBatch(self.source_id, self.platform, self.status(), posts, [])


LIVE_ADAPTERS: tuple[type[LiveApiAdapter], ...] = (
    XAdapter,
    TelegramAdapter,
    InstagramAdapter,
    FacebookAdapter,
    RedditAdapter,
    YouTubeAdapter,
)
