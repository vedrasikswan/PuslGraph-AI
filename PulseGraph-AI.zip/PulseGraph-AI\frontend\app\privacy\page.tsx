import { Suspense } from 'react';

import { AppShell } from '@/components/layout/AppShell';
import { FilterProvider } from '@/features/filters/FilterContext';

import { PrivacyView } from './PrivacyView';

export const metadata = { title: 'Privacy and ethics — PulseGraph AI' };

export default function Page() {
  return (
    <Suspense fallback={null}>
      <FilterProvider>
        <AppShell>
          <PrivacyView />
        </AppShell>
      </FilterProvider>
    </Suspense>
  );
}
