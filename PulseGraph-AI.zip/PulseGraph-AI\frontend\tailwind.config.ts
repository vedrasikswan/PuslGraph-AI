import type { Config } from 'tailwindcss';

/**
 * Analyst-workstation palette.
 *
 * Semantic colours are defined once here and referenced everywhere, so a
 * sentiment never renders green in one chart and teal in another. Colour is
 * always paired with a label, icon or number in the UI - never used alone to
 * carry meaning.
 */
const config: Config = {
  content: [
    './app/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './features/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        canvas: {
          DEFAULT: '#0b0f16',
          raised: '#111722',
          sunken: '#080b11',
          hover: '#161e2c',
        },
        edge: {
          DEFAULT: '#1e2836',
          strong: '#2c3849',
          subtle: '#161d29',
        },
        ink: {
          DEFAULT: '#e6ebf3',
          muted: '#94a3b8',
          faint: '#64748b',
          inverse: '#0b0f16',
        },
        positive: { DEFAULT: '#22c55e', dim: '#14532d', soft: '#16281d' },
        negative: { DEFAULT: '#ef4444', dim: '#7f1d1d', soft: '#2a1618' },
        neutral: { DEFAULT: '#94a3b8', dim: '#475569', soft: '#1b2230' },
        warning: { DEFAULT: '#f59e0b', dim: '#78350f', soft: '#2a2013' },
        trend: { DEFAULT: '#818cf8', dim: '#3730a3', soft: '#1b1d33' },
        influence: { DEFAULT: '#22d3ee', dim: '#155e75', soft: '#122630' },
        critical: { DEFAULT: '#f43f5e', dim: '#881337' },
      },
      fontFamily: {
        sans: ['var(--font-sans)', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['var(--font-mono)', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      fontSize: {
        '2xs': ['0.6875rem', { lineHeight: '1rem' }],
      },
      spacing: {
        18: '4.5rem',
        112: '28rem',
      },
      borderRadius: {
        card: '6px',
      },
      keyframes: {
        'fade-in': {
          from: { opacity: '0', transform: 'translateY(4px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '100%': { transform: 'translateX(100%)' },
        },
      },
      animation: {
        'fade-in': 'fade-in 160ms ease-out',
        shimmer: 'shimmer 1.4s infinite',
      },
    },
  },
  plugins: [],
};

export default config;
