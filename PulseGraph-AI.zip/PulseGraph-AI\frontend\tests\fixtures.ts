/** Fixtures shaped exactly like real API responses. */

import type {
  AudiencePulse,
  IntelligenceCard,
  Journey,
  KPI,
  Overview,
  SegmentSummary,
  Trend,
} from '@/types/api';

export const pulse: AudiencePulse = {
  headline: 'Topic accelerating: NovaPhone X battery drain',
  statement:
    'NovaPhone X battery drain is viral: 545 mentions in the last 12 hours versus 11 in the 12 before (+4855%), trend score 87/100. Telegram activity preceded the increase elsewhere by about 54 minutes.',
  severity: 'high',
  confidence: 0.88,
  confidence_band: 'High',
  detected_at: '2026-08-25T06:00:00',
  topic_id: 'battery-drain',
  topic_label: 'NovaPhone X battery drain',
  affected_platforms: ['telegram', 'x', 'reddit'],
  affected_segments: ['Concerned Customers'],
  evidence: [
    { metric: 'mentions', value: 545, change: '+4855%', period: 'last 12h vs previous 12h' },
    { metric: 'engagement_velocity', value: 1719, period: 'interactions per hour' },
    {
      metric: 'lead_time_minutes',
      value: 54,
      period: 'telegram -> x',
      note: 'Temporal ordering of first sustained activity; not causal.',
    },
  ],
  recommended_action: 'Track NovaPhone X battery drain on telegram and x over the next few hours.',
  supporting_events: [
    { id: 'cross-platform:battery-drain', title: 'Cross-platform spread', category: 'cross_platform_spread' },
  ],
  interpretation_source: 'local',
};

export const kpis: KPI[] = [
  { key: 'total_posts', label: 'Total posts', value: 973, change: 472.4, format: 'number' },
  { key: 'active_authors', label: 'Active authors', value: 179, change: 79, format: 'number' },
  { key: 'engagement', label: 'Engagement', value: 45153, change: 242.8, format: 'number' },
  { key: 'positive_share', label: 'Positive', value: 16.3, change: -26, format: 'percent' },
  { key: 'negative_share', label: 'Negative', value: 60.1, change: 43.7, format: 'percent' },
  { key: 'trending_topics', label: 'Trending topics', value: 5, change: null, format: 'number' },
  { key: 'influential_nodes', label: 'Influential nodes', value: 29, change: null, format: 'number' },
];

export const trend: Trend = {
  topic_id: 'battery-drain',
  label: 'NovaPhone X battery drain',
  description: 'Reports of accelerated battery drain after v14.2.',
  trend_score: 87.03,
  classification: 'viral',
  velocity: {
    current_mentions: 539,
    previous_mentions: 11,
    growth_percentage: 4800,
    direction: 'up',
    acceleration: -2.61,
    engagement_velocity: 1719,
    previous_engagement_velocity: 71,
    engagement_growth: 2320,
    unique_authors: 158,
    author_growth: 1500,
  },
  sentiment: { avg_polarity: -0.39, previous_polarity: -0.21, shift: -0.18 },
  platforms: ['telegram', 'x', 'reddit', 'facebook', 'youtube'],
  platform_count: 5,
  influencer_participation: 0.11,
  persistence: 1,
  momentum: {
    label: 'likely to stabilise',
    confidence: 0.86,
    confidence_band: 'High',
    forecast_next_bucket: 66,
  },
  components: {
    weights: { volume_growth: 0.26, engagement_velocity: 0.2 },
    values: { volume_growth: 0.94, engagement_velocity: 1, small_sample_discount: 1 },
    formula: 'trend_score = 100 x small_sample_discount x (0.26*volume_growth + ...)',
  },
  series: [],
};

export const stableTrend: Trend = {
  ...trend,
  topic_id: 'camera-quality',
  label: 'Camera performance',
  trend_score: 12.3,
  classification: 'stable',
  velocity: { ...trend.velocity, current_mentions: 8, previous_mentions: 44, growth_percentage: -81.8, direction: 'down' },
  platforms: ['x', 'instagram'],
  platform_count: 2,
};

export const intelligenceCard: IntelligenceCard = {
  id: 'sentiment-spike:battery-drain',
  category: 'sentiment_spike',
  title: 'Negative sentiment spike: NovaPhone X battery drain',
  summary: 'Negative sentiment rose 31% in the last 6 hours, from 48% to 63% of posts.',
  severity: 'critical',
  confidence: 0.93,
  confidence_band: 'High',
  detected_at: '2026-08-25T06:00:00',
  window: { start: '2026-08-25T00:00:00', end: '2026-08-25T06:00:00' },
  topic_id: 'battery-drain',
  topic_label: 'NovaPhone X battery drain',
  drivers: ['battery-drain discussion volume (218 posts)'],
  affected_segments: ['Concerned Customers'],
  affected_platforms: ['x', 'telegram'],
  related_nodes: [{ anon_id: 'A2218', influence_score: 20.2, is_bridge: true }],
  evidence: [
    { metric: 'negative_sentiment_share', value: 0.634, change: '+30.1%', period: 'last 6 hours' },
    { metric: 'posts_analysed', value: 218, period: 'last 6 hours' },
  ],
  recommended_action: 'Review complaints from the last 6 hours.',
  interpretation_source: 'local',
};

export const infoCard: IntelligenceCard = {
  ...intelligenceCard,
  id: 'declining-topic:camera-quality',
  category: 'declining_trend',
  title: 'Topic declining: Camera performance',
  severity: 'info',
  confidence: 0.71,
  confidence_band: 'Medium',
  topic_id: 'camera-quality',
  topic_label: 'Camera performance',
};

export const segment: SegmentSummary = {
  id: 'concerned-customers',
  name: 'Concerned Customers',
  description: 'Ordinary owners posting about impact on daily use.',
  color: '#f97316',
  size: 27,
  total_members: 27,
  posts: 160,
  engagement: 1232,
  avg_engagement: 7.7,
  engagement_level: 'low',
  avg_polarity: -0.44,
  dominant_sentiment: 'negative',
  sentiment_distribution: [
    { sentiment: 'positive', count: 8, percentage: 5 },
    { sentiment: 'neutral', count: 32, percentage: 20 },
    { sentiment: 'negative', count: 120, percentage: 75 },
  ],
  dominant_topics: [{ topic_id: 'battery-drain', posts: 110 }],
  platforms: [{ platform: 'x', posts: 95 }],
  languages: [{ language: 'en', posts: 150 }],
  age_distribution: [{ bracket: '35-44', authors: 14, percentage: 52 }],
  regions: [{ region: 'South Asia', authors: 9, percentage: 33 }],
  interests: [{ interest: 'General consumer', authors: 18 }],
  sentiment_trend: [
    { ts: '2026-08-25T01:00:00', avg_polarity: -0.2, posts: 10 },
    { ts: '2026-08-25T02:00:00', avg_polarity: -0.44, posts: 24 },
  ],
  influential_members: [{ anon_id: 'A5567', influence_score: 54, is_bridge: false }],
  assignment_rationale: ['predominantly negative sentiment', 'low individual reach'],
};

export const journey: Journey = {
  topic_id: 'battery-drain',
  span: { start: '2026-08-24T23:01:00', end: '2026-08-25T07:55:00', hours: 8.9 },
  bucket_minutes: 30,
  total_posts: 615,
  episode_posts: 537,
  lead_platform: 'telegram',
  milestones: [
    {
      ts: '2026-08-24T23:01:00',
      kind: 'origin',
      title: 'Episode opens on telegram',
      detail: 'Volume breaks away from its own baseline here.',
      platform: 'telegram',
      evidence: [{ metric: 'episode_start', value: '2026-08-24T23:01:00', period: 'onset' }],
      sample_post_id: 'tg:1',
      sample_text: 'Not a calibration issue.',
      actors: [],
    },
    {
      ts: '2026-08-24T23:59:00',
      kind: 'cross_platform',
      title: 'Discussion reaches x',
      detail: 'x shows sustained activity about 51 minutes after telegram.',
      platform: 'x',
      evidence: [{ metric: 'lead_time_minutes', value: 51, period: 'telegram -> x' }],
      sample_post_id: null,
      sample_text: null,
      actors: [],
    },
  ],
  lead_lag: [
    {
      lead_platform: 'telegram',
      lag_platform: 'x',
      minutes: 51,
      lead_first_activity: '2026-08-24T23:01:00',
      lag_first_activity: '2026-08-24T23:59:00',
    },
  ],
};

export const overview: Overview = {
  empty: false,
  kpis,
  avg_polarity: -0.31,
  sarcasm_rate: 0.081,
  sentiment_distribution: [
    { sentiment: 'positive', count: 158, percentage: 16.3 },
    { sentiment: 'neutral', count: 230, percentage: 23.6 },
    { sentiment: 'negative', count: 585, percentage: 60.1 },
  ],
  emotion_distribution: [{ emotion: 'frustrated', count: 200, percentage: 20.6 }],
  platform_distribution: [{ platform: 'x', count: 540, percentage: 55.5 }],
  range: { start: '2026-08-24T08:00:00', end: '2026-08-25T08:00:00' },
  pulse,
  filters: {
    start: null,
    end: null,
    platforms: [],
    topics: [],
    segments: [],
    sentiments: [],
    emotions: [],
    search: '',
    granularity: 'hourly',
    active: false,
  },
  recommendations: [
    {
      id: 'rec:1',
      text: 'Treat telegram as an early-warning surface for this narrative.',
      basis: 'Cross-platform spread',
      severity: 'high',
      confidence: 0.9,
      confidence_band: 'High',
      topic_id: 'battery-drain',
    },
  ],
};

export const emptyOverview: Overview = {
  ...overview,
  empty: true,
  kpis: kpis.map((k) => ({ ...k, value: 0, change: null })),
  sentiment_distribution: [],
  emotion_distribution: [],
  platform_distribution: [],
  pulse: null,
  recommendations: [],
};
