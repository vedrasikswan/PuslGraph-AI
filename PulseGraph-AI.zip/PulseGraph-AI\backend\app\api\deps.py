"""Shared FastAPI dependencies: filter parsing and the analytics service."""

from __future__ import annotations

from datetime import datetime, timedelta

from fastapi import Depends, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.analytics.filters import GRANULARITIES, AnalysisFilters
from app.analytics.queries import AnalyticsService
from app.db import get_db
from app.models import Post

RELATIVE_RANGES: dict[str, timedelta] = {
    "1h": timedelta(hours=1),
    "6h": timedelta(hours=6),
    "12h": timedelta(hours=12),
    "24h": timedelta(hours=24),
    "3d": timedelta(days=3),
    "7d": timedelta(days=7),
}


def _split(value: str | None) -> list[str]:
    if not value:
        return []
    return [v.strip() for v in value.split(",") if v.strip()]


def get_filters(
    db: Session = Depends(get_db),
    start: datetime | None = Query(None, description="ISO start timestamp"),
    end: datetime | None = Query(None, description="ISO end timestamp"),
    range: str | None = Query(
        None, description="Relative window: 1h, 6h, 12h, 24h, 3d, 7d, all"),
    platforms: str | None = Query(None, description="Comma-separated platform ids"),
    topics: str | None = Query(None, description="Comma-separated topic ids"),
    segments: str | None = Query(None, description="Comma-separated segment ids"),
    sentiments: str | None = Query(None, description="positive,negative,neutral"),
    emotions: str | None = Query(None, description="Comma-separated emotion labels"),
    search: str = Query("", max_length=160),
    granularity: str = Query("hourly"),
) -> AnalysisFilters:
    if granularity not in GRANULARITIES:
        raise HTTPException(
            status_code=422,
            detail=f"granularity must be one of {sorted(GRANULARITIES)}",
        )

    if range and range != "all" and start is None and end is None:
        delta = RELATIVE_RANGES.get(range)
        if delta is None:
            raise HTTPException(
                status_code=422,
                detail=f"range must be one of {sorted(RELATIVE_RANGES)} or 'all'",
            )
        latest = db.scalar(select(func.max(Post.created_at)))
        if latest is not None:
            end = latest
            start = latest - delta

    if start and end and start > end:
        raise HTTPException(status_code=422, detail="start must be before end")

    return AnalysisFilters(
        start=start,
        end=end,
        platforms=_split(platforms),
        topics=_split(topics),
        segments=_split(segments),
        sentiments=_split(sentiments),
        emotions=_split(emotions),
        search=search,
        granularity=granularity,
    )


def get_service(db: Session = Depends(get_db)) -> AnalyticsService:
    return AnalyticsService(db)


def require_dataset(db: Session = Depends(get_db)) -> None:
    """Guard endpoints that are meaningless before any data is loaded."""
    count = db.scalar(select(func.count(Post.id))) or 0
    if count == 0:
        raise HTTPException(
            status_code=409,
            detail=(
                "No dataset loaded. Call POST /api/ingestion/demo (or use "
                "'Load Demo Intelligence' in the UI) to populate the platform."
            ),
        )
