'use client';

/** Shared building blocks. Dense, restrained, consistent spacing. */

import type { ReactNode } from 'react';
import { AlertTriangle, Database, Inbox, RefreshCw, ServerCrash } from 'lucide-react';

import { SEVERITY_STYLES, TREND_STYLES } from '@/lib/colors';
import { SEVERITY_LABELS, TREND_LABELS, confidenceLabel } from '@/lib/format';
import type { ConfidenceBand, Sentiment, Severity, TrendClass } from '@/types/api';

export function cx(...parts: (string | false | null | undefined)[]): string {
  return parts.filter(Boolean).join(' ');
}

/* ------------------------------------------------------------------ Panel */
export function Panel({
  title,
  subtitle,
  actions,
  children,
  className,
  bodyClassName,
  dense,
}: {
  title?: ReactNode;
  subtitle?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
  bodyClassName?: string;
  dense?: boolean;
}) {
  return (
    <section
      className={cx(
        'rounded-card border border-edge bg-canvas-raised',
        'shadow-[0_1px_0_0_rgba(255,255,255,0.02)_inset]',
        className,
      )}
    >
      {(title || actions) && (
        <header className="flex items-start justify-between gap-3 border-b border-edge-subtle px-4 py-3">
          <div className="min-w-0">
            {title && (
              <h2 className="truncate text-[13px] font-semibold tracking-wide text-ink">
                {title}
              </h2>
            )}
            {subtitle && (
              <p className="mt-0.5 text-2xs leading-relaxed text-ink-faint">{subtitle}</p>
            )}
          </div>
          {actions && <div className="flex shrink-0 items-center gap-1.5">{actions}</div>}
        </header>
      )}
      <div className={cx(dense ? 'p-0' : 'p-4', bodyClassName)}>{children}</div>
    </section>
  );
}

/* ------------------------------------------------------------------ Badges */
export function Badge({
  children,
  tone = 'neutral',
  className,
  title,
}: {
  children: ReactNode;
  tone?: 'neutral' | 'positive' | 'negative' | 'warning' | 'trend' | 'influence' | 'critical';
  className?: string;
  title?: string;
}) {
  const tones: Record<string, string> = {
    neutral: 'border-edge-strong bg-neutral/10 text-ink-muted',
    positive: 'border-positive/35 bg-positive/10 text-positive',
    negative: 'border-negative/35 bg-negative/10 text-negative',
    warning: 'border-warning/35 bg-warning/10 text-warning',
    trend: 'border-trend/35 bg-trend/10 text-trend',
    influence: 'border-influence/35 bg-influence/10 text-influence',
    critical: 'border-critical/40 bg-critical/10 text-critical',
  };
  return (
    <span
      title={title}
      className={cx(
        'inline-flex items-center gap-1 whitespace-nowrap rounded border px-1.5 py-0.5',
        'text-2xs font-medium leading-none',
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

export function SeverityBadge({ severity }: { severity: Severity }) {
  const style = SEVERITY_STYLES[severity];
  return (
    <span
      className={cx(
        'inline-flex items-center gap-1.5 rounded border px-1.5 py-0.5 text-2xs font-medium',
        style.bg,
        style.border,
        style.text,
      )}
    >
      <span className={cx('h-1.5 w-1.5 rounded-full', style.dot)} aria-hidden />
      {SEVERITY_LABELS[severity]}
    </span>
  );
}

export function TrendBadge({ classification, score }: { classification: TrendClass; score?: number }) {
  const style = TREND_STYLES[classification];
  return (
    <span
      className={cx(
        'inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-2xs font-semibold',
        style.bg,
        style.text,
      )}
    >
      {TREND_LABELS[classification]}
      {score !== undefined && <span className="font-mono opacity-70">{score.toFixed(0)}</span>}
    </span>
  );
}

export function SentimentBadge({
  sentiment,
  value,
}: {
  sentiment: Sentiment;
  value?: string;
}) {
  const tone = sentiment === 'positive' ? 'positive' : sentiment === 'negative' ? 'negative' : 'neutral';
  const glyph = sentiment === 'positive' ? '▲' : sentiment === 'negative' ? '▼' : '■';
  return (
    <Badge tone={tone}>
      <span aria-hidden className="text-[9px]">{glyph}</span>
      <span className="capitalize">{sentiment}</span>
      {value && <span className="font-mono opacity-70">{value}</span>}
    </Badge>
  );
}

/**
 * Confidence is always shown as band + number so a low-confidence inference can
 * never read as a fact.
 */
export function ConfidenceBadge({
  band,
  value,
  label = 'Confidence',
}: {
  band: ConfidenceBand;
  value: number;
  label?: string;
}) {
  const tone = band === 'High' ? 'positive' : band === 'Medium' ? 'warning' : 'neutral';
  return (
    <Badge tone={tone} title={`${label}: ${confidenceLabel(band, value)}`}>
      {label} {band}
      <span className="font-mono opacity-70">{value.toFixed(2)}</span>
    </Badge>
  );
}

/* ------------------------------------------------------------------ States */
export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      className={cx(
        'relative overflow-hidden rounded bg-canvas-hover',
        'after:absolute after:inset-0 after:-translate-x-full after:animate-shimmer',
        'after:bg-gradient-to-r after:from-transparent after:via-white/[0.04] after:to-transparent',
        className,
      )}
      aria-hidden
    />
  );
}

export function PanelSkeleton({ rows = 4, height = 'h-4' }: { rows?: number; height?: string }) {
  return (
    <div className="space-y-2" role="status" aria-label="Loading">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className={cx(height, i % 3 === 2 ? 'w-2/3' : 'w-full')} />
      ))}
    </div>
  );
}

export function EmptyState({
  title = 'No data for these filters',
  description = 'Nothing in the dataset matches the current selection. Widen the time range or clear a filter.',
  action,
  icon: Icon = Inbox,
}: {
  title?: string;
  description?: string;
  action?: ReactNode;
  icon?: typeof Inbox;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 px-6 py-10 text-center">
      <Icon className="h-5 w-5 text-ink-faint" aria-hidden />
      <p className="text-[13px] font-medium text-ink">{title}</p>
      <p className="max-w-sm text-2xs leading-relaxed text-ink-faint">{description}</p>
      {action && <div className="mt-1.5">{action}</div>}
    </div>
  );
}

export function ErrorState({
  error,
  onRetry,
}: {
  error: { message: string; hint?: string; status?: number; needsDataset?: boolean };
  onRetry?: () => void;
}) {
  const offline = error.status === 0;
  const Icon = offline ? ServerCrash : error.needsDataset ? Database : AlertTriangle;
  return (
    <div className="flex flex-col items-center justify-center gap-2 px-6 py-10 text-center">
      <Icon className="h-5 w-5 text-warning" aria-hidden />
      <p className="text-[13px] font-medium text-ink">
        {offline ? 'Backend unreachable' : error.needsDataset ? 'No dataset loaded' : 'Could not load this view'}
      </p>
      <p className="max-w-md text-2xs leading-relaxed text-ink-muted">{error.message}</p>
      {error.hint && (
        <p className="max-w-md font-mono text-2xs leading-relaxed text-ink-faint">{error.hint}</p>
      )}
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="mt-1.5 inline-flex items-center gap-1.5 rounded border border-edge-strong px-2 py-1 text-2xs text-ink-muted transition-colors hover:bg-canvas-hover hover:text-ink"
        >
          <RefreshCw className="h-3 w-3" aria-hidden />
          Retry
        </button>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ Misc */
export function Delta({ value, invert = false }: { value: number | null; invert?: boolean }) {
  if (value === null || !Number.isFinite(value)) {
    return <span className="text-2xs text-ink-faint">no prior window</span>;
  }
  const rising = value > 0;
  const good = invert ? !rising : rising;
  const tone =
    Math.abs(value) < 0.05
      ? 'text-ink-faint'
      : good
        ? 'text-positive'
        : 'text-negative';
  const glyph = Math.abs(value) < 0.05 ? '→' : rising ? '↑' : '↓';
  return (
    <span className={cx('inline-flex items-center gap-0.5 text-2xs font-medium tabular-nums', tone)}>
      <span aria-hidden>{glyph}</span>
      {Math.abs(value) >= 1000
        ? `${(Math.abs(value) / 1000).toFixed(1)}k%`
        : `${Math.abs(value).toFixed(1)}%`}
    </span>
  );
}

export function MetaRow({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-3 py-1">
      <dt className="shrink-0 text-2xs text-ink-faint">{label}</dt>
      <dd className="min-w-0 text-right text-2xs text-ink-muted">{children}</dd>
    </div>
  );
}

export function Bar({
  value,
  max,
  color,
  className,
}: {
  value: number;
  max: number;
  color: string;
  className?: string;
}) {
  const width = max > 0 ? Math.max(2, (value / max) * 100) : 0;
  return (
    <div className={cx('h-1.5 w-full overflow-hidden rounded-full bg-canvas-sunken', className)}>
      <div
        className="h-full rounded-full transition-[width] duration-300"
        style={{ width: `${width}%`, backgroundColor: color }}
      />
    </div>
  );
}
