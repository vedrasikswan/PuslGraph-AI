'use client';

/**
 * Global filter state, stored in the URL.
 *
 * Every analytical view reads from this one object, so selecting a platform or
 * clicking a timeline bucket re-derives sentiment, trends, audience, network and
 * the intelligence feed together. Holding it in the URL also makes any dashboard
 * state shareable and survives a reload.
 */

import { createContext, useCallback, useContext, useMemo } from 'react';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';

import type { QueryFilters } from '@/lib/api';
import type { Granularity } from '@/types/api';

export interface Filters extends QueryFilters {
  range: string;
  granularity: Granularity;
  platforms: string[];
  topics: string[];
  segments: string[];
  sentiments: string[];
  emotions: string[];
  search: string;
  start?: string;
  end?: string;
}

export const DEFAULT_FILTERS: Filters = {
  range: '24h',
  granularity: 'hourly',
  platforms: [],
  topics: [],
  segments: [],
  sentiments: [],
  emotions: [],
  search: '',
};

type ListKey = 'platforms' | 'topics' | 'segments' | 'sentiments' | 'emotions';

interface FilterContextValue {
  filters: Filters;
  activeCount: number;
  setRange: (range: string) => void;
  setWindow: (start: string, end: string) => void;
  setGranularity: (granularity: Granularity) => void;
  setSearch: (search: string) => void;
  toggle: (key: ListKey, value: string) => void;
  setList: (key: ListKey, values: string[]) => void;
  clear: () => void;
  clearKey: (key: ListKey | 'window' | 'search') => void;
}

const FilterContext = createContext<FilterContextValue | null>(null);

function parseList(value: string | null): string[] {
  return value ? value.split(',').filter(Boolean) : [];
}

export function FilterProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const filters = useMemo<Filters>(() => {
    const start = searchParams.get('start') ?? undefined;
    const end = searchParams.get('end') ?? undefined;
    return {
      // An explicit window takes precedence over a relative range.
      range: start && end ? 'custom' : searchParams.get('range') ?? DEFAULT_FILTERS.range,
      granularity: (searchParams.get('granularity') as Granularity) ?? DEFAULT_FILTERS.granularity,
      platforms: parseList(searchParams.get('platforms')),
      topics: parseList(searchParams.get('topics')),
      segments: parseList(searchParams.get('segments')),
      sentiments: parseList(searchParams.get('sentiments')),
      emotions: parseList(searchParams.get('emotions')),
      search: searchParams.get('search') ?? '',
      start,
      end,
    };
  }, [searchParams]);

  const activeCount = useMemo(
    () =>
      filters.platforms.length +
      filters.topics.length +
      filters.segments.length +
      filters.sentiments.length +
      filters.emotions.length +
      (filters.search ? 1 : 0) +
      (filters.start && filters.end ? 1 : 0),
    [filters],
  );

  const push = useCallback(
    (mutate: (params: URLSearchParams) => void) => {
      const params = new URLSearchParams(searchParams.toString());
      mutate(params);
      const query = params.toString();
      router.replace(query ? `${pathname}?${query}` : pathname, { scroll: false });
    },
    [pathname, router, searchParams],
  );

  const setRange = useCallback(
    (range: string) =>
      push((params) => {
        params.delete('start');
        params.delete('end');
        if (range === DEFAULT_FILTERS.range) params.delete('range');
        else params.set('range', range);
      }),
    [push],
  );

  const setWindow = useCallback(
    (start: string, end: string) =>
      push((params) => {
        params.delete('range');
        params.set('start', start);
        params.set('end', end);
      }),
    [push],
  );

  const setGranularity = useCallback(
    (granularity: Granularity) =>
      push((params) => {
        if (granularity === DEFAULT_FILTERS.granularity) params.delete('granularity');
        else params.set('granularity', granularity);
      }),
    [push],
  );

  const setSearch = useCallback(
    (search: string) =>
      push((params) => {
        if (search) params.set('search', search);
        else params.delete('search');
      }),
    [push],
  );

  const setList = useCallback(
    (key: ListKey, values: string[]) =>
      push((params) => {
        if (values.length) params.set(key, values.join(','));
        else params.delete(key);
      }),
    [push],
  );

  const toggle = useCallback(
    (key: ListKey, value: string) => {
      const current = filters[key];
      const next = current.includes(value)
        ? current.filter((v) => v !== value)
        : [...current, value];
      setList(key, next);
    },
    [filters, setList],
  );

  const clear = useCallback(
    () =>
      push((params) => {
        for (const key of ['platforms', 'topics', 'segments', 'sentiments', 'emotions',
                           'search', 'start', 'end', 'range', 'granularity']) {
          params.delete(key);
        }
      }),
    [push],
  );

  const clearKey = useCallback(
    (key: ListKey | 'window' | 'search') =>
      push((params) => {
        if (key === 'window') {
          params.delete('start');
          params.delete('end');
        } else {
          params.delete(key);
        }
      }),
    [push],
  );

  const value = useMemo(
    () => ({
      filters, activeCount, setRange, setWindow, setGranularity,
      setSearch, toggle, setList, clear, clearKey,
    }),
    [filters, activeCount, setRange, setWindow, setGranularity,
     setSearch, toggle, setList, clear, clearKey],
  );

  return <FilterContext.Provider value={value}>{children}</FilterContext.Provider>;
}

export function useFilters(): FilterContextValue {
  const context = useContext(FilterContext);
  if (!context) {
    throw new Error('useFilters must be used inside a FilterProvider');
  }
  return context;
}

/** Stable key for memoising requests derived from the current filters. */
export function filterKey(filters: Filters): string {
  return JSON.stringify([
    filters.range, filters.start, filters.end, filters.granularity,
    filters.platforms, filters.topics, filters.segments,
    filters.sentiments, filters.emotions, filters.search,
  ]);
}
