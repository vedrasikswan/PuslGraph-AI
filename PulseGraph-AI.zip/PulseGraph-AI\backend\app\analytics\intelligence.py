"""InsightEngine - detection, evidence and interpretation.

The division of labour is strict:

* **Detectors** compute. They are deterministic statistics over stored rows and
  they emit `Evidence` objects with a metric name, value, change and period.
* **The provider** phrases. It receives the already-computed brief and returns
  a sentence. It never sees raw posts and never produces a number.

Language rules: correlation and ordering only. "preceded", "likely driver",
"appears to originate from", "associated with". Nothing here asserts causation.
"""

from __future__ import annotations

import logging
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.ai.provider import AIProvider
from app.analytics import network as net
from app.analytics.filters import AnalysisFilters, apply_filters
from app.analytics import trends as trend_mod
from app.analytics.journey import build_journey
from app.models import (
    Author,
    AudienceSegment,
    AuthorSegment,
    IntelligenceEvent,
    NetworkMetric,
    Post,
    PostTopic,
    SentimentResult,
    Topic,
)

logger = logging.getLogger(__name__)

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}


@dataclass(slots=True)
class Evidence:
    metric: str
    value: float | int | str
    change: str | None = None
    period: str = ""
    note: str = ""

    def to_dict(self) -> dict:
        return {k: v for k, v in asdict(self).items() if v not in (None, "")}


@dataclass(slots=True)
class Insight:
    id: str
    category: str
    title: str
    summary: str
    severity: str
    confidence: float
    detected_at: datetime
    topic_id: str | None = None
    window_start: datetime | None = None
    window_end: datetime | None = None
    drivers: list[str] = field(default_factory=list)
    affected_segments: list[str] = field(default_factory=list)
    affected_platforms: list[str] = field(default_factory=list)
    related_nodes: list[dict] = field(default_factory=list)
    evidence: list[Evidence] = field(default_factory=list)
    recommended_action: str = ""
    interpretation_source: str = "local"


def confidence_band(value: float) -> str:
    if value >= 0.80:
        return "High"
    if value >= 0.60:
        return "Medium"
    return "Low"


class InsightEngine:
    """Runs every detector and returns persistable events."""

    def __init__(
        self,
        db: Session,
        provider: AIProvider,
        filters: AnalysisFilters | None = None,
    ) -> None:
        self.db = db
        self.provider = provider
        # Detectors run against the same filtered row set as every other view.
        # Without this the intelligence feed would describe the whole corpus
        # while the KPIs beside it described a filtered subset.
        self.filters = filters or AnalysisFilters()
        self._topic_labels = dict(self.db.execute(select(Topic.id, Topic.label)).all())
        self._segment_names = dict(self.db.execute(
            select(AudienceSegment.id, AudienceSegment.name)).all())
        self._anon = dict(self.db.execute(select(Author.id, Author.anon_id)).all())

    # ------------------------------------------------------------------ #
    def _scoped(self, stmt):
        """Apply the active filters to a statement selecting from `posts`."""
        return apply_filters(stmt, self.filters, joined=True)

    def _latest_post_time(self) -> datetime | None:
        stmt = (
            select(func.max(Post.created_at))
            .select_from(Post)
            .join(
                PostTopic,
                (PostTopic.post_id == Post.id) & (PostTopic.is_primary.is_(True)),
                isouter=True,
            )
            .join(SentimentResult, SentimentResult.post_id == Post.id, isouter=True)
        )
        return self.db.scalar(self._scoped(stmt))

    # ------------------------------------------------------------------ #
    def run(
        self,
        trend_results: list[trend_mod.TrendResult],
        metrics: dict[str, net.NodeMetrics],
    ) -> list[IntelligenceEvent]:
        latest = self._latest_post_time()
        if latest is None:
            return []

        insights: list[Insight] = []
        detectors = (
            (self.detect_sentiment_spike, (latest,)),
            (self.detect_trend_acceleration, (trend_results,)),
            (self.detect_emerging_topics, (trend_results,)),
            (self.detect_declining_topics, (trend_results,)),
            (self.detect_cross_platform_spread, (trend_results,)),
            (self.detect_platform_divergence, (trend_results,)),
            (self.detect_influencer_amplification, (trend_results, metrics)),
            (self.detect_segment_shift, (latest,)),
            (self.detect_bridge_nodes, (metrics,)),
            (self.detect_sarcasm_load, (latest,)),
        )
        for detector, args in detectors:
            try:
                insights.extend(detector(*args))
            except Exception:
                logger.exception("Detector %s failed; continuing", detector.__name__)

        insights.sort(key=lambda i: (SEVERITY_ORDER.get(i.severity, 5), -i.confidence))
        return [self._to_row(i) for i in insights]

    # ------------------------------------------------------------------ #
    def _to_row(self, insight: Insight) -> IntelligenceEvent:
        return IntelligenceEvent(
            id=insight.id,
            category=insight.category,
            title=insight.title,
            summary=insight.summary,
            severity=insight.severity,
            confidence=round(insight.confidence, 3),
            detected_at=insight.detected_at,
            window_start=insight.window_start,
            window_end=insight.window_end,
            topic_id=insight.topic_id,
            drivers=insight.drivers,
            affected_segments=insight.affected_segments,
            affected_platforms=insight.affected_platforms,
            related_nodes=insight.related_nodes,
            evidence=[e.to_dict() for e in insight.evidence],
            recommended_action=insight.recommended_action,
            interpretation_source=insight.interpretation_source,
        )

    def _phrase(self, insight: Insight, brief: dict) -> None:
        """Ask the provider to phrase the computed brief, then keep the result
        only if it came back usable."""
        try:
            narrative = self.provider.interpret(brief)
        except Exception:
            logger.exception("Interpretation failed; keeping computed summary")
            return
        if narrative.summary:
            insight.summary = narrative.summary
        if narrative.recommended_action:
            insight.recommended_action = narrative.recommended_action
        insight.interpretation_source = narrative.source

    def _label(self, topic_id: str | None) -> str:
        return self._topic_labels.get(topic_id or "", topic_id or "unknown topic")

    # -- detector 1: sentiment spike ------------------------------------ #
    def detect_sentiment_spike(self, latest: datetime) -> list[Insight]:
        """Compare the last 6 hours against the preceding 6 for each topic."""
        window = timedelta(hours=6)
        rows = self.db.execute(self._scoped(
            select(Post.created_at, Post.platform, Post.author_id, PostTopic.topic_id,
                   SentimentResult.polarity, SentimentResult.sentiment)
            .join(PostTopic, (PostTopic.post_id == Post.id) & (PostTopic.is_primary.is_(True)))
            .join(SentimentResult, SentimentResult.post_id == Post.id)
            .where(Post.created_at >= latest - window * 2)
        )).all()

        current: dict[str, list] = defaultdict(list)
        prior: dict[str, list] = defaultdict(list)
        for created_at, platform, author_id, topic_id, polarity, sentiment in rows:
            bucket = current if created_at >= latest - window else prior
            bucket[topic_id].append((platform, author_id, polarity, sentiment))

        segment_of = dict(self.db.execute(
            select(AuthorSegment.author_id, AuthorSegment.segment_id)).all())

        insights: list[Insight] = []
        for topic_id, entries in current.items():
            before = prior.get(topic_id, [])
            if len(entries) < 12 or len(before) < 6:
                continue

            now_negative = sum(1 for _p, _a, _pol, s in entries if s == "negative") / len(entries)
            was_negative = sum(1 for _p, _a, _pol, s in before if s == "negative") / len(before)
            delta = now_negative - was_negative
            if delta < 0.10:
                continue

            relative = (delta / was_negative * 100) if was_negative > 0 else 100.0
            now_polarity = sum(e[2] for e in entries) / len(entries)
            was_polarity = sum(e[2] for e in before) / len(before)

            platforms = [p for p, _ in Counter(e[0] for e in entries).most_common()]
            segments = Counter(
                segment_of[e[1]] for e in entries if e[1] in segment_of
            )
            top_segments = [self._segment_names.get(s, s) for s, _ in segments.most_common(2)]

            severity = ("critical" if delta >= 0.28 and now_negative >= 0.6
                        else "high" if delta >= 0.18
                        else "medium")
            confidence = min(0.93, 0.52 + min(len(entries), 120) / 260 + delta)

            evidence = [
                Evidence("negative_sentiment_share", round(now_negative, 3),
                         f"{delta:+.1%}", "last 6 hours vs previous 6 hours"),
                Evidence("avg_polarity", round(now_polarity, 3),
                         f"{now_polarity - was_polarity:+.3f}", "last 6 hours"),
                Evidence("posts_analysed", len(entries), f"vs {len(before)} prior",
                         "last 6 hours"),
                Evidence("platforms_involved", len(set(e[0] for e in entries)),
                         period="last 6 hours"),
            ]
            if top_segments:
                evidence.append(Evidence("dominant_segment", top_segments[0],
                                         period="last 6 hours"))

            headline = (
                f"Negative sentiment around {self._label(topic_id)} rose "
                f"{relative:.0f}% in the last 6 hours, from {was_negative:.0%} to "
                f"{now_negative:.0%} of posts."
            )
            insight = Insight(
                id=f"sentiment-spike:{topic_id}",
                category="sentiment_spike",
                title=f"Negative sentiment spike: {self._label(topic_id)}",
                summary=headline,
                severity=severity,
                confidence=confidence,
                detected_at=latest,
                topic_id=topic_id,
                window_start=latest - window,
                window_end=latest,
                drivers=[f"{self._label(topic_id)} discussion volume ({len(entries)} posts)"],
                affected_segments=top_segments,
                affected_platforms=platforms[:5],
                evidence=evidence,
                recommended_action=(
                    f"Review {self._label(topic_id)} complaints from the last 6 hours before "
                    f"the next {('2-4 hour' if severity in {'critical', 'high'} else '12 hour')} "
                    f"window; the shift is concentrated in "
                    f"{top_segments[0] if top_segments else 'the general audience'}."
                ),
            )
            self._phrase(insight, {
                "headline": headline,
                "drivers": insight.drivers,
                "platforms": platforms[:4],
                "segments": top_segments,
                "recommended_action": insight.recommended_action,
            })
            insights.append(insight)
        return insights

    # -- detector 2: trend acceleration --------------------------------- #
    def detect_trend_acceleration(self, results: list[trend_mod.TrendResult]) -> list[Insight]:
        insights: list[Insight] = []
        for result in results:
            if result.classification not in {"accelerating", "viral"}:
                continue
            severity = "high" if result.classification == "viral" else "medium"
            headline = (
                f"{self._label(result.topic_id)} is {result.classification}: "
                f"{result.mentions} mentions in the last 12 hours versus "
                f"{result.prev_mentions} in the 12 before ({result.growth_rate:+.0f}%), "
                f"trend score {result.trend_score:.0f}/100."
            )
            insight = Insight(
                id=f"trend-acceleration:{result.topic_id}",
                category="trend_acceleration",
                title=f"Topic accelerating: {self._label(result.topic_id)}",
                summary=headline,
                severity=severity,
                confidence=min(0.92, 0.5 + result.trend_score / 240 + result.momentum_confidence / 4),
                detected_at=result.window_end,
                topic_id=result.topic_id,
                window_start=result.window_start,
                window_end=result.window_end,
                drivers=[
                    f"volume growth {result.growth_rate:+.0f}%",
                    f"engagement velocity {result.engagement_velocity:,.0f} interactions/hour",
                ],
                affected_platforms=result.platforms,
                evidence=[
                    Evidence("mentions", result.mentions,
                             f"{result.growth_rate:+.0f}%", "last 12h vs previous 12h"),
                    Evidence("unique_authors", result.unique_authors,
                             f"{result.author_growth:+.0f}%", "last 12h vs previous 12h"),
                    Evidence("engagement_velocity", result.engagement_velocity,
                             period="interactions per hour"),
                    Evidence("trend_score", result.trend_score,
                             period="0-100 composite", note=result.components.get("formula", "")),
                    Evidence("momentum_forecast", result.momentum,
                             f"confidence {result.momentum_confidence:.2f}", "next intervals"),
                    Evidence("cross_platform_spread", result.platform_count,
                             period="platforms with activity"),
                ],
                recommended_action=(
                    f"Momentum forecast is '{result.momentum}' at "
                    f"{confidence_band(result.momentum_confidence).lower()} confidence. "
                    f"Track {self._label(result.topic_id)} on "
                    f"{', '.join(result.platforms[:3])} over the next few hours."
                ),
            )
            self._phrase(insight, {
                "headline": headline,
                "drivers": insight.drivers,
                "platforms": result.platforms,
                "recommended_action": insight.recommended_action,
            })
            insights.append(insight)
        return insights

    # -- detector 3: emerging topics ------------------------------------ #
    def detect_emerging_topics(self, results: list[trend_mod.TrendResult]) -> list[Insight]:
        """A topic is emerging only if it is genuinely new.

        Growth alone is not enough: a long-running topic that spikes is an
        acceleration, not an emergence. The distinguishing test is whether the
        topic's first observed mention anywhere in the dataset falls inside the
        analysis window.
        """
        first_seen = dict(self.db.execute(select(Topic.id, Topic.first_seen_at)).all())

        insights: list[Insight] = []
        for result in results:
            origin = first_seen.get(result.topic_id)
            is_new = origin is not None and origin >= result.window_start
            is_emerging = (
                is_new
                and result.mentions >= 8
                and result.classification in {"emerging", "growing", "accelerating", "viral"}
            )
            if not is_emerging:
                continue
            headline = (
                f"{self._label(result.topic_id)} appeared with {result.mentions} mentions from "
                f"{result.unique_authors} accounts in the last 12 hours, against "
                f"{result.prev_mentions} in the previous 12."
            )
            insight = Insight(
                id=f"emerging-topic:{result.topic_id}",
                category="emerging_topic",
                title=f"New topic emerging: {self._label(result.topic_id)}",
                summary=headline,
                severity="medium",
                confidence=min(0.88, 0.5 + result.unique_authors / 60),
                detected_at=result.window_end,
                topic_id=result.topic_id,
                window_start=result.window_start,
                window_end=result.window_end,
                drivers=[f"{result.unique_authors} distinct accounts participating"],
                affected_platforms=result.platforms,
                evidence=[
                    Evidence("mentions", result.mentions,
                             f"from {result.prev_mentions}", "last 12h vs previous 12h"),
                    Evidence("unique_authors", result.unique_authors, period="last 12 hours"),
                    Evidence("avg_polarity", round(result.current_polarity, 3),
                             f"{result.sentiment_shift:+.3f}", "last 12 hours"),
                    Evidence("platforms", result.platform_count, period="with activity"),
                ],
                recommended_action=(
                    f"Read the earliest {self._label(result.topic_id)} posts on "
                    f"{result.platforms[0] if result.platforms else 'the leading platform'} "
                    f"to establish what the topic actually claims before it grows further."
                ),
            )
            self._phrase(insight, {
                "headline": headline, "drivers": insight.drivers,
                "platforms": result.platforms,
                "recommended_action": insight.recommended_action,
            })
            insights.append(insight)
        return insights

    # -- detector 4: declining topics ----------------------------------- #
    def detect_declining_topics(self, results: list[trend_mod.TrendResult]) -> list[Insight]:
        insights: list[Insight] = []
        for result in results:
            if result.growth_rate > -30 or result.prev_mentions < 10:
                continue
            headline = (
                f"{self._label(result.topic_id)} fell {abs(result.growth_rate):.0f}% to "
                f"{result.mentions} mentions in the last 12 hours, from "
                f"{result.prev_mentions}. Momentum forecast: {result.momentum}."
            )
            insight = Insight(
                id=f"declining-topic:{result.topic_id}",
                category="declining_trend",
                title=f"Topic declining: {self._label(result.topic_id)}",
                summary=headline,
                severity="info",
                confidence=min(0.85, 0.5 + result.momentum_confidence / 3),
                detected_at=result.window_end,
                topic_id=result.topic_id,
                window_start=result.window_start,
                window_end=result.window_end,
                drivers=[f"mention volume {result.growth_rate:+.0f}%"],
                affected_platforms=result.platforms,
                evidence=[
                    Evidence("mentions", result.mentions,
                             f"{result.growth_rate:+.0f}%", "last 12h vs previous 12h"),
                    Evidence("engagement_velocity", result.engagement_velocity,
                             period="interactions per hour"),
                    Evidence("momentum_forecast", result.momentum,
                             f"confidence {result.momentum_confidence:.2f}", "next intervals"),
                ],
                recommended_action=(
                    f"Attention is moving away from {self._label(result.topic_id)}; "
                    f"reallocate monitoring toward the accelerating topics."
                ),
            )
            insights.append(insight)
        return insights

    # -- detector 5: cross-platform spread ------------------------------ #
    def detect_cross_platform_spread(self, results: list[trend_mod.TrendResult]) -> list[Insight]:
        insights: list[Insight] = []
        for result in results:
            if result.platform_count < 3 or result.mentions < 15:
                continue
            journey = build_journey(self.db, result.topic_id)
            lead_lag = journey.get("lead_lag") or []
            if not lead_lag:
                continue
            primary = lead_lag[0]

            headline = (
                f"The same {self._label(result.topic_id)} narrative is present on "
                f"{result.platform_count} platforms. {primary['lead_platform'].title()} activity "
                f"preceded {primary['lag_platform']} by about "
                f"{primary['minutes']:.0f} minutes."
            )
            insight = Insight(
                id=f"cross-platform:{result.topic_id}",
                category="cross_platform_spread",
                title=f"Cross-platform spread: {self._label(result.topic_id)}",
                summary=headline,
                severity="high" if result.platform_count >= 4 else "medium",
                confidence=min(0.9, 0.55 + result.platform_count / 12),
                detected_at=result.window_end,
                topic_id=result.topic_id,
                window_start=result.window_start,
                window_end=result.window_end,
                drivers=[
                    f"{primary['lead_platform']} activity preceded {primary['lag_platform']}"
                ],
                affected_platforms=result.platforms,
                evidence=[
                    Evidence("platforms_with_activity", result.platform_count,
                             period="last 12 hours"),
                    Evidence("lead_time_minutes", primary["minutes"],
                             period=f"{primary['lead_platform']} -> {primary['lag_platform']}",
                             note="Temporal ordering of first sustained activity; not causal."),
                    Evidence("total_mentions", result.mentions, period="last 12 hours"),
                ],
                recommended_action=(
                    f"Treat {primary['lead_platform']} as an early-warning surface for this "
                    f"narrative; it showed sustained activity first in this dataset."
                ),
            )
            self._phrase(insight, {
                "headline": headline,
                "drivers": insight.drivers,
                "platforms": result.platforms,
                "lead_time_minutes": primary["minutes"],
                "lead_platform": primary["lead_platform"],
                "lag_platform": primary["lag_platform"],
                "recommended_action": insight.recommended_action,
            })
            insights.append(insight)
        return insights

    # -- detector 6: platform sentiment divergence ---------------------- #
    def detect_platform_divergence(self, results: list[trend_mod.TrendResult]) -> list[Insight]:
        rows = self.db.execute(self._scoped(
            select(PostTopic.topic_id, Post.platform,
                   func.avg(SentimentResult.polarity), func.count(Post.id))
            .select_from(Post)
            .join(PostTopic, (PostTopic.post_id == Post.id) & (PostTopic.is_primary.is_(True)))
            .join(SentimentResult, SentimentResult.post_id == Post.id)
            .group_by(PostTopic.topic_id, Post.platform)
        )).all()

        by_topic: dict[str, list[tuple[str, float, int]]] = defaultdict(list)
        for topic_id, platform, avg_polarity, count in rows:
            if count >= 8:
                by_topic[topic_id].append((platform, float(avg_polarity or 0.0), count))

        insights: list[Insight] = []
        for topic_id, entries in by_topic.items():
            if len(entries) < 3:
                continue
            entries.sort(key=lambda kv: kv[1])
            lowest, highest = entries[0], entries[-1]
            divergence = highest[1] - lowest[1]
            if divergence < 0.25:
                continue

            headline = (
                f"The same {self._label(topic_id)} narrative reads differently by platform: "
                f"{lowest[0]} averages {lowest[1]:+.2f} polarity while {highest[0]} averages "
                f"{highest[1]:+.2f}, a spread of {divergence:.2f}."
            )
            insight = Insight(
                id=f"divergence:{topic_id}",
                category="sentiment_divergence",
                title=f"Cross-platform sentiment divergence: {self._label(topic_id)}",
                summary=headline,
                severity="medium",
                confidence=min(0.9, 0.55 + divergence / 2),
                detected_at=self._latest_post_time(),
                topic_id=topic_id,
                drivers=[f"{lowest[0]} community is markedly more negative"],
                affected_platforms=[p for p, _v, _c in entries],
                evidence=[
                    Evidence(f"avg_polarity_{platform}", round(value, 3),
                             period=f"{count} posts")
                    for platform, value, count in entries
                ] + [Evidence("divergence", round(divergence, 3),
                              period="max - min platform polarity")],
                recommended_action=(
                    f"Do not treat this audience as homogeneous: a response written for "
                    f"{highest[0]} will read very differently to the {lowest[0]} community."
                ),
            )
            insights.append(insight)
        _ = results
        return insights

    # -- detector 7: influencer amplification --------------------------- #
    def detect_influencer_amplification(
        self, results: list[trend_mod.TrendResult], metrics: dict[str, net.NodeMetrics]
    ) -> list[Insight]:
        if not metrics:
            return []
        ranked = sorted(metrics.values(), key=lambda m: m.influence_score, reverse=True)
        cut = ranked[max(0, len(ranked) // 20 - 1)].influence_score

        insights: list[Insight] = []
        for result in results:
            if result.influencer_participation < 0.06 or result.mentions < 12:
                continue

            rows = self.db.execute(self._scoped(
                select(Post.author_id, func.count(Post.id), func.sum(Post.engagement_count))
                .join(PostTopic, (PostTopic.post_id == Post.id) & (PostTopic.is_primary.is_(True)))
                .join(SentimentResult, SentimentResult.post_id == Post.id, isouter=True)
                .where(PostTopic.topic_id == result.topic_id,
                       Post.created_at >= result.window_start)
                .group_by(Post.author_id)
            )).all()
            participants = [
                (author_id, count, engagement or 0)
                for author_id, count, engagement in rows
                if author_id in metrics and metrics[author_id].influence_score >= cut
            ]
            if not participants:
                continue
            participants.sort(key=lambda kv: metrics[kv[0]].influence_score, reverse=True)
            top = participants[:5]
            amplified_engagement = sum(e for _a, _c, e in top)
            total_engagement = sum(e or 0 for _a, _c, e in rows) or 1

            headline = (
                f"{len(participants)} high-influence accounts posted about "
                f"{self._label(result.topic_id)} during its growth phase. The top "
                f"{len(top)} account for {amplified_engagement / total_engagement:.0%} of the "
                f"topic's engagement in the window."
            )
            insight = Insight(
                id=f"influencer-amplification:{result.topic_id}",
                category="influencer_amplification",
                title=f"Influence concentration: {self._label(result.topic_id)}",
                summary=headline,
                severity="high" if amplified_engagement / total_engagement > 0.45 else "medium",
                confidence=min(0.9, 0.55 + len(participants) / 30),
                detected_at=result.window_end,
                topic_id=result.topic_id,
                window_start=result.window_start,
                window_end=result.window_end,
                drivers=[f"{len(participants)} top-tier accounts active on this topic"],
                affected_platforms=result.platforms,
                related_nodes=[
                    {
                        "anon_id": self._anon.get(author_id, "A?"),
                        "influence_score": round(metrics[author_id].influence_score, 2),
                        "posts": count,
                        "engagement": engagement,
                        "community_id": metrics[author_id].community_id,
                        "is_bridge": metrics[author_id].is_bridge,
                    }
                    for author_id, count, engagement in top
                ],
                evidence=[
                    Evidence("high_influence_participants", len(participants),
                             period="growth window"),
                    Evidence("engagement_share_of_top_accounts",
                             round(amplified_engagement / total_engagement, 3),
                             period="growth window"),
                    Evidence("influencer_participation_rate",
                             round(result.influencer_participation, 3),
                             period="share of posts in window"),
                ],
                recommended_action=(
                    "A small number of accounts carry most of this topic's reach. Engaging "
                    "with their specific claims is higher leverage than broad messaging."
                ),
            )
            insights.append(insight)
        return insights

    # -- detector 8: audience segment shift ----------------------------- #
    def detect_segment_shift(self, latest: datetime) -> list[Insight]:
        window = timedelta(hours=6)
        rows = self.db.execute(self._scoped(
            select(AuthorSegment.segment_id, Post.created_at, SentimentResult.polarity,
                   SentimentResult.sentiment, PostTopic.topic_id)
            .select_from(Post)
            .join(AuthorSegment, AuthorSegment.author_id == Post.author_id)
            .join(SentimentResult, SentimentResult.post_id == Post.id)
            .join(PostTopic, (PostTopic.post_id == Post.id) & (PostTopic.is_primary.is_(True)),
                  isouter=True)
            .where(Post.created_at >= latest - window * 2)
        )).all()

        current: dict[str, list] = defaultdict(list)
        prior: dict[str, list] = defaultdict(list)
        for segment_id, created_at, polarity, sentiment, topic_id in rows:
            target = current if created_at >= latest - window else prior
            target[segment_id].append((polarity, sentiment, topic_id))

        insights: list[Insight] = []
        for segment_id, entries in current.items():
            before = prior.get(segment_id, [])
            if len(entries) < 10 or len(before) < 8:
                continue

            now_neutral = sum(1 for _p, s, _t in entries if s == "neutral") / len(entries)
            was_neutral = sum(1 for _p, s, _t in before if s == "neutral") / len(before)
            now_negative = sum(1 for _p, s, _t in entries if s == "negative") / len(entries)
            was_negative = sum(1 for _p, s, _t in before if s == "negative") / len(before)
            now_positive = sum(1 for _p, s, _t in entries if s == "positive") / len(entries)
            was_positive = sum(1 for _p, s, _t in before if s == "positive") / len(before)

            negative_move = now_negative - was_negative
            positive_move = now_positive - was_positive
            if max(abs(negative_move), abs(positive_move)) < 0.12:
                continue

            name = self._segment_names.get(segment_id, segment_id)
            topics = Counter(t for _p, _s, t in entries if t)
            top_topic = topics.most_common(1)[0][0] if topics else None

            if negative_move >= 0.12:
                title = f"Audience segment turning negative: {name}"
                headline = (
                    f"{name} moved from {was_neutral:.0%} neutral / {was_negative:.0%} negative "
                    f"to {now_neutral:.0%} neutral / {now_negative:.0%} negative over the last "
                    f"6 hours."
                )
                severity = "high" if negative_move >= 0.2 else "medium"
            else:
                title = f"Audience segment becoming more supportive: {name}"
                headline = (
                    f"{name} moved from {was_positive:.0%} to {now_positive:.0%} positive over "
                    f"the last 6 hours."
                )
                severity = "info"

            insight = Insight(
                id=f"segment-shift:{segment_id}",
                category="segment_shift",
                title=title,
                summary=headline,
                severity=severity,
                confidence=min(0.9, 0.5 + len(entries) / 120 + abs(negative_move)),
                detected_at=latest,
                topic_id=top_topic,
                window_start=latest - window,
                window_end=latest,
                drivers=[f"{self._label(top_topic)} discussion" if top_topic else "mixed topics"],
                affected_segments=[name],
                evidence=[
                    Evidence("segment_negative_share", round(now_negative, 3),
                             f"{negative_move:+.1%}", "last 6 hours vs previous 6 hours"),
                    Evidence("segment_neutral_share", round(now_neutral, 3),
                             f"{now_neutral - was_neutral:+.1%}", "last 6 hours"),
                    Evidence("segment_positive_share", round(now_positive, 3),
                             f"{positive_move:+.1%}", "last 6 hours"),
                    Evidence("segment_posts", len(entries), f"vs {len(before)} prior",
                             "last 6 hours"),
                ],
                recommended_action=(
                    f"{name} is disproportionately reactive right now; compare against other "
                    f"segments before treating this as a general audience movement."
                ),
            )
            insights.append(insight)
        return insights

    # -- detector 9: bridge nodes --------------------------------------- #
    def detect_bridge_nodes(self, metrics: dict[str, net.NodeMetrics]) -> list[Insight]:
        bridges = [m for m in metrics.values() if m.is_bridge]
        if not bridges:
            return []
        bridges.sort(key=lambda m: m.betweenness, reverse=True)
        top = bridges[:5]
        communities = sorted({m.community_id for m in metrics.values()})

        headline = (
            f"{len(bridges)} accounts act as bridges between otherwise separate communities. "
            f"The top {len(top)} sit on {sum(m.cross_community_edges for m in top)} "
            f"cross-community interactions across {len(communities)} detected clusters."
        )
        insight = Insight(
            id="bridge-nodes",
            category="bridge_discovery",
            title="Bridge accounts connect separate communities",
            summary=headline,
            severity="medium",
            confidence=min(0.88, 0.55 + len(bridges) / 40),
            detected_at=self._latest_post_time(),
            drivers=["high betweenness combined with cross-community interaction ratio"],
            related_nodes=[
                {
                    "anon_id": self._anon.get(m.author_id, "A?"),
                    "influence_score": m.influence_score,
                    "betweenness": m.betweenness,
                    "community_id": m.community_id,
                    "cross_community_edges": m.cross_community_edges,
                    "bridge_ratio": m.bridge_ratio,
                }
                for m in top
            ],
            evidence=[
                Evidence("bridge_nodes", len(bridges), period="whole graph"),
                Evidence("communities_detected", len(communities), period="whole graph"),
                Evidence("max_betweenness", round(top[0].betweenness, 5),
                         period="normalised 0-1"),
                Evidence("cross_community_edges_top_node", top[0].cross_community_edges,
                         period="whole graph"),
            ],
            recommended_action=(
                "These accounts determine whether a narrative stays inside one community. "
                "Watch them to see the moment a topic is about to cross over."
            ),
        )
        return [insight]

    # -- detector 10: sarcasm load -------------------------------------- #
    def detect_sarcasm_load(self, latest: datetime) -> list[Insight]:
        window = timedelta(hours=12)
        rows = self.db.execute(self._scoped(
            select(PostTopic.topic_id, SentimentResult.sarcasm_detected,
                   SentimentResult.literal_sentiment, SentimentResult.contextual_sentiment)
            .select_from(Post)
            .join(SentimentResult, SentimentResult.post_id == Post.id)
            .join(PostTopic, (PostTopic.post_id == Post.id) & (PostTopic.is_primary.is_(True)))
            .where(Post.created_at >= latest - window)
        )).all()
        if not rows:
            return []

        by_topic: dict[str, list] = defaultdict(list)
        for topic_id, sarcasm, literal, contextual in rows:
            by_topic[topic_id].append((sarcasm, literal, contextual))

        insights: list[Insight] = []
        for topic_id, entries in by_topic.items():
            sarcastic = [e for e in entries if e[0]]
            if len(entries) < 20 or len(sarcastic) < 4:
                continue
            rate = len(sarcastic) / len(entries)
            if rate < 0.06:
                continue
            flipped = sum(1 for _s, literal, contextual in sarcastic
                          if literal == "positive" and contextual == "negative")

            headline = (
                f"{rate:.0%} of {self._label(topic_id)} posts in the last 12 hours were read as "
                f"sarcastic. In {flipped} of them the literal wording is positive while the "
                f"contextual reading is negative."
            )
            insight = Insight(
                id=f"sarcasm-load:{topic_id}",
                category="sarcasm_load",
                title=f"Sarcasm distorting surface sentiment: {self._label(topic_id)}",
                summary=headline,
                severity="medium" if rate > 0.1 else "info",
                confidence=min(0.85, 0.5 + rate * 2),
                detected_at=latest,
                topic_id=topic_id,
                window_start=latest - window,
                window_end=latest,
                drivers=["literal and contextual readings disagree on a material share of posts"],
                evidence=[
                    Evidence("sarcasm_rate", round(rate, 3), period="last 12 hours"),
                    Evidence("sarcastic_posts", len(sarcastic),
                             f"of {len(entries)}", "last 12 hours"),
                    Evidence("polarity_flips", flipped,
                             period="literal positive -> contextual negative"),
                ],
                recommended_action=(
                    "A keyword-only sentiment reading would score these posts positive. Use the "
                    "contextual reading when reporting sentiment for this topic."
                ),
            )
            insights.append(insight)
        return insights
