'use client';

/**
 * Network page: the full interaction graph, influence ranking, communities and
 * bridge accounts.
 */

import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { GitFork, Users } from 'lucide-react';

import { InfluenceGraph, NodeInspector } from '@/components/network/InfluenceGraph';
import {
  Badge,
  Bar,
  EmptyState,
  ErrorState,
  Panel,
  PanelSkeleton,
  SentimentBadge,
  cx,
} from '@/components/ui/primitives';
import { filterKey, useFilters } from '@/features/filters/FilterContext';
import { useApi } from '@/hooks/useApi';
import { api } from '@/lib/api';
import { COLORS, communityColor } from '@/lib/colors';
import { compactNumber, platformLabel, polarity } from '@/lib/format';
import type { GraphNode, Influencer, NetworkResponse } from '@/types/api';

export function NetworkView() {
  const { filters } = useFilters();
  const searchParams = useSearchParams();
  const key = filterKey(filters);
  const requestedNode = searchParams.get('node');

  const [selected, setSelected] = useState<GraphNode | null>(null);
  const [maxNodes, setMaxNodes] = useState(140);

  const network = useApi<NetworkResponse>(`network-full:${key}:${maxNodes}`, () =>
    api.network(filters, maxNodes),
  );
  const influencers = useApi<{ items: Influencer[] }>(`influencers:${key}`, () =>
    api.influencers(filters, 10),
  );

  // Deep link from an intelligence card or segment card: /network?node=A1234
  useEffect(() => {
    if (!requestedNode || !network.data) return;
    const match = network.data.nodes.find((n) => n.anon_id === requestedNode);
    if (match) setSelected(match);
  }, [requestedNode, network.data]);

  if (network.error) {
    return (
      <Panel>
        <ErrorState error={network.error} onRetry={network.reload} />
      </Panel>
    );
  }

  const maxInfluence = Math.max(...(influencers.data?.items.map((i) => i.influence_score) ?? [1]), 1);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h1 className="text-lg font-semibold tracking-tight text-ink">Influence network</h1>
          <p className="mt-0.5 text-2xs text-ink-muted">
            Reply, mention and repost interactions for the current selection. Influence combines
            PageRank, betweenness, degree centrality and public audience size.
          </p>
        </div>
        <label className="flex items-center gap-2 text-2xs text-ink-faint">
          Nodes shown
          <select
            value={maxNodes}
            onChange={(e) => setMaxNodes(Number(e.target.value))}
            className="rounded border border-edge bg-canvas-sunken px-1.5 py-1 text-2xs text-ink"
          >
            {[60, 100, 140, 200, 300].map((n) => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
        </label>
      </div>

      <div className="grid gap-3 xl:grid-cols-[1fr_280px]">
        <Panel
          title="Interaction graph"
          subtitle={
            network.data && !network.data.empty
              ? `${network.data.displayed_nodes} of ${network.data.total_nodes} accounts · ${network.data.total_edges} interactions · ${network.data.communities.length} communities detected`
              : undefined
          }
          actions={
            network.data?.truncated ? (
              <Badge tone="neutral" title="The graph is aggregated server-side before rendering.">
                Aggregated for rendering
              </Badge>
            ) : null
          }
        >
          {network.loading && <PanelSkeleton rows={8} height="h-12" />}
          {network.data?.empty && (
            <EmptyState
              title="No interactions in this selection"
              description="The filtered posts contain no replies, mentions or reposts, so there is no graph to build."
            />
          )}
          {network.data && !network.data.empty && (
            <InfluenceGraph
              data={network.data}
              height={560}
              onSelect={setSelected}
              selectedId={selected?.id ?? null}
              highlightSegment={filters.segments[0] ?? null}
            />
          )}
        </Panel>

        <div className="space-y-3">
          <Panel title="Selected account" dense>
            <NodeInspector node={selected} />
          </Panel>

          <Panel
            title={
              <span className="flex items-center gap-1.5">
                <Users className="h-3.5 w-3.5 text-influence" aria-hidden />
                Communities
              </span>
            }
            subtitle="Greedy modularity clusters over the undirected projection"
          >
            {network.data && network.data.communities.length > 0 ? (
              <div className="space-y-1.5">
                {network.data.communities.slice(0, 8).map((community) => (
                  <div key={community.community_id} className="flex items-center gap-2">
                    <span
                      className="h-2 w-2 shrink-0 rounded-full"
                      style={{ backgroundColor: communityColor(community.community_id) }}
                      aria-hidden
                    />
                    <span className="w-8 shrink-0 font-mono text-2xs text-ink-faint">
                      #{community.community_id}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-2xs text-ink-muted">
                        {community.dominant_segment ?? 'Mixed'}
                      </p>
                      <Bar
                        value={community.accounts}
                        max={network.data!.communities[0].accounts}
                        color={communityColor(community.community_id)}
                        className="mt-0.5"
                      />
                    </div>
                    <span className="w-20 shrink-0 text-right font-mono text-[10px] tabular-nums text-ink-faint">
                      {community.accounts} acct
                      {community.bridge_nodes > 0 && (
                        <span className="text-warning">
                          {' · '}
                          {community.bridge_nodes} br
                        </span>
                      )}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState title="No communities detected" />
            )}
          </Panel>
        </div>
      </div>

      <Panel
        title={
          <span className="flex items-center gap-1.5">
            <GitFork className="h-3.5 w-3.5 text-warning" aria-hidden />
            Top 10 influence nodes
          </span>
        }
        subtitle="Ranked by composite influence. Bridge accounts connect otherwise separate communities."
        dense
      >
        {influencers.loading && (
          <div className="p-4">
            <PanelSkeleton rows={6} height="h-6" />
          </div>
        )}
        {influencers.data && influencers.data.items.length === 0 && (
          <EmptyState title="No accounts with interactions in this selection" />
        )}
        {influencers.data && influencers.data.items.length > 0 && (
          <div className="scroll-x">
            <table className="w-full min-w-[860px] border-collapse text-2xs">
              <thead>
                <tr className="border-b border-edge-subtle text-left text-ink-faint">
                  <th className="px-4 py-2 font-medium">Rank</th>
                  <th className="px-2 py-2 font-medium">Account</th>
                  <th className="px-2 py-2 font-medium">Influence score</th>
                  <th className="px-2 py-2 font-medium">Community</th>
                  <th className="px-2 py-2 text-right font-medium">Engagement</th>
                  <th className="px-2 py-2 font-medium">Topics</th>
                  <th className="px-4 py-2 font-medium">Sentiment</th>
                </tr>
              </thead>
              <tbody>
                {influencers.data.items.map((row) => {
                  const active = selected?.anon_id === row.anon_id;
                  return (
                    <tr
                      key={row.anon_id}
                      onClick={() => {
                        const match = network.data?.nodes.find((n) => n.anon_id === row.anon_id);
                        if (match) setSelected(match);
                      }}
                      className={cx(
                        'cursor-pointer border-b border-edge-subtle/60 last:border-0',
                        active ? 'bg-influence/[0.07]' : 'hover:bg-canvas-hover/40',
                      )}
                    >
                      <td className="px-4 py-2 font-mono tabular-nums text-ink-faint">
                        {row.rank}
                      </td>
                      <td className="px-2 py-2">
                        <span className="flex flex-wrap items-center gap-1.5">
                          <span className="font-mono text-ink">{row.anon_id}</span>
                          <Badge tone="neutral">{platformLabel(row.platform)}</Badge>
                          {row.is_bridge && <Badge tone="warning">bridge</Badge>}
                        </span>
                      </td>
                      <td className="px-2 py-2">
                        <div className="flex items-center gap-2">
                          <span className="w-10 shrink-0 font-mono tabular-nums text-ink">
                            {row.influence_score.toFixed(1)}
                          </span>
                          <div className="w-24">
                            <Bar
                              value={row.influence_score}
                              max={maxInfluence}
                              color={COLORS.influence}
                            />
                          </div>
                        </div>
                      </td>
                      <td className="px-2 py-2 font-mono text-ink-faint">#{row.community_id}</td>
                      <td className="px-2 py-2 text-right font-mono tabular-nums text-ink-muted">
                        {compactNumber(row.engagement)}
                        <span className="ml-1 text-ink-faint">/{row.posts}p</span>
                      </td>
                      <td className="px-2 py-2">
                        <span className="flex flex-wrap gap-1">
                          {row.topics.slice(0, 2).map((topic) => (
                            <Link key={topic} href={`/topics/${topic}`}>
                              <Badge tone="neutral">{topic}</Badge>
                            </Link>
                          ))}
                        </span>
                      </td>
                      <td className="px-4 py-2">
                        <SentimentBadge
                          sentiment={row.sentiment}
                          value={polarity(row.avg_polarity)}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        <p className="border-t border-edge-subtle px-4 py-2 text-[10px] leading-relaxed text-ink-faint">
          Accounts are shown pseudonymously. Influence reflects structural position in the
          observed interaction graph, not endorsement or intent.
        </p>
      </Panel>
    </div>
  );
}
