"""Ingestion normalisation.

These assert the actual mapping from each platform's payload shape onto the
internal schema - the contract that lets a live API be swapped in later without
touching anything downstream.
"""

from __future__ import annotations

from datetime import datetime

import pytest

from app.ingestion.adapters import (
    FacebookAdapter,
    RedditAdapter,
    TelegramAdapter,
    XAdapter,
    YouTubeAdapter,
)
from app.ingestion.base import NormalizedPost, SourceStatus
from app.ingestion.demo_adapter import DemoDataAdapter
from app.ingestion.registry import build_adapter, describe_sources


class TestXNormalisation:
    def test_maps_v2_payload_to_internal_schema(self):
        payload = {
            "id": "1799",
            "author_id": "55",
            "text": "Battery drain after v14.2 is real #novaphonex @nova_care",
            "created_at": "2026-08-24T09:15:00.000Z",
            "lang": "en",
            "public_metrics": {"like_count": 42, "reply_count": 7,
                               "retweet_count": 13, "impression_count": 9100},
            "entities": {"hashtags": [{"tag": "NovaPhoneX"}],
                         "mentions": [{"username": "nova_care"}]},
            "referenced_tweets": [{"type": "replied_to", "id": "1798"}],
            "geo": {"place_id": "p1"},
        }
        includes = {
            "users": [{"id": "55", "username": "isha_dev", "name": "Isha"}],
            "places": [{"id": "p1", "full_name": "Bengaluru, India"}],
        }

        post = XAdapter.normalize(payload, includes)

        assert post.id == "x:1799"
        assert post.platform == "x"
        assert post.author_id == "x:55"
        assert post.author_name == "isha_dev"
        assert post.reply_to_id == "x:1798"
        assert post.likes == 42 and post.comments == 7 and post.shares == 13
        assert post.views == 9100
        assert post.engagement_count == 62
        assert post.hashtags == ["novaphonex"]
        assert post.mentions == ["nova_care"]
        assert post.location == "Bengaluru, India"
        assert post.timestamp == datetime(2026, 8, 24, 9, 15)

    def test_quoted_tweet_becomes_parent_not_reply(self):
        post = XAdapter.normalize({
            "id": "2", "author_id": "9", "text": "look at this",
            "created_at": "2026-08-24T10:00:00Z",
            "referenced_tweets": [{"type": "quoted", "id": "1"}],
        })
        assert post.parent_post_id == "x:1"
        assert post.reply_to_id is None

    def test_missing_optional_fields_do_not_raise(self):
        post = XAdapter.normalize({"id": "3", "author_id": "1", "text": "hi"})
        assert post.likes == 0 and post.views == 0
        assert post.location == ""
        assert isinstance(post.timestamp, datetime)


class TestOtherPlatformNormalisation:
    def test_telegram_message(self):
        post = TelegramAdapter.normalize(
            {"id": 88, "sender_id": 501, "message": "battery draining fast",
             "date": "2026-08-24T08:00:00+00:00", "views": 1200,
             "forwards": 30, "replies_count": 9, "reply_to_msg_id": 80},
            {"id": 7, "username": "novausers"},
        )
        assert post.id == "tg:7:88"
        assert post.platform == "telegram"
        assert post.reply_to_id == "tg:7:80"
        assert post.shares == 30 and post.views == 1200

    def test_reddit_comment_uses_body_and_epoch(self):
        post = RedditAdapter.normalize({
            "id": "abc", "body": "same here after the update", "author": "u1",
            "created_utc": 1787000000, "score": 15, "link_id": "t3_xyz",
        })
        assert post.id == "rd:abc"
        assert post.text == "same here after the update"
        assert post.reply_to_id == "rd:xyz"
        assert post.likes == 15

    def test_reddit_submission_joins_title_and_body(self):
        post = RedditAdapter.normalize({
            "id": "s1", "title": "Battery issue", "selftext": "details here",
            "author": "u2", "created_utc": 1787000000, "num_comments": 4,
        })
        assert post.text == "Battery issue details here"
        assert post.comments == 4

    def test_youtube_comment_thread(self):
        post = YouTubeAdapter.normalize({
            "id": "c1",
            "snippet": {
                "totalReplyCount": 3,
                "topLevelComment": {"snippet": {
                    "authorDisplayName": "viewer1",
                    "authorChannelId": {"value": "ch1"},
                    "textOriginal": "mine too",
                    "publishedAt": "2026-08-24T12:00:00Z",
                    "likeCount": 6,
                }},
            },
        })
        assert post.platform == "youtube"
        assert post.author_id == "yt:ch1"
        assert post.likes == 6 and post.comments == 3

    def test_facebook_nested_summaries(self):
        post = FacebookAdapter.normalize({
            "id": "f1", "message": "not happy", "created_time": "2026-08-24T12:00:00+0000",
            "from": {"id": "u9", "name": "Someone"},
            "reactions": {"summary": {"total_count": 11}},
            "comments": {"summary": {"total_count": 5}},
            "shares": {"count": 2},
        })
        assert post.likes == 11 and post.comments == 5 and post.shares == 2
        assert post.engagement_count == 18


class TestAdapterContract:
    def test_hashtags_and_mentions_parsed_when_absent(self):
        post = NormalizedPost(
            id="t", platform="x", author_id="a", author_name="a",
            text="broken again #nova142 cc @nova_care", timestamp=datetime(2026, 8, 24),
        )
        assert post.hashtags == ["nova142"]
        assert post.mentions == ["nova_care"]

    def test_uncredentialled_adapter_reports_not_connected_without_network(self):
        adapter = XAdapter({})
        batch = adapter.fetch("nova", limit=10)
        assert batch.status is SourceStatus.NOT_CONNECTED
        assert batch.posts == []
        assert "x_bearer_token" in batch.message

    def test_credentialled_adapter_reports_connected(self):
        assert XAdapter({"x_bearer_token": "t"}).status() is SourceStatus.CONNECTED

    def test_registry_exposes_all_required_platforms(self):
        described = {s["platform"] for s in describe_sources()}
        for required in ("x", "telegram", "instagram", "facebook", "reddit", "youtube"):
            assert required in described

    def test_essential_platforms_are_tiered_correctly(self):
        tiers = {s["platform"]: s["tier"] for s in describe_sources()}
        assert tiers["x"] == "essential"
        assert tiers["telegram"] == "essential"
        assert tiers["instagram"] == "desirable"
        assert tiers["reddit"] == "appreciable"

    def test_unknown_source_rejected(self):
        with pytest.raises(KeyError):
            build_adapter("myspace")


class TestDemoAdapter:
    def test_produces_deterministic_corpus(self):
        first = DemoDataAdapter(seed=99, target_posts=400).fetch()
        second = DemoDataAdapter(seed=99, target_posts=400).fetch()
        assert len(first.posts) == len(second.posts)
        assert [p.id for p in first.posts[:40]] == [p.id for p in second.posts[:40]]
        assert [p.text for p in first.posts[:40]] == [p.text for p in second.posts[:40]]

    def test_different_seed_produces_different_corpus(self):
        a = DemoDataAdapter(seed=1, target_posts=400).fetch()
        b = DemoDataAdapter(seed=2, target_posts=400).fetch()
        assert [p.text for p in a.posts[:30]] != [p.text for p in b.posts[:30]]

    def test_corpus_spans_required_platforms_and_is_chronological(self):
        batch = DemoDataAdapter(seed=7, target_posts=900).fetch()
        platforms = {p.platform for p in batch.posts}
        assert {"x", "telegram"}.issubset(platforms)
        assert len(platforms) >= 4
        timestamps = [p.timestamp for p in batch.posts]
        assert timestamps == sorted(timestamps)

    def test_platform_filter_keeps_authors_consistent(self):
        batch = DemoDataAdapter(seed=7, target_posts=900, platform="telegram").fetch()
        assert batch.posts
        assert {p.platform for p in batch.posts} == {"telegram"}
        author_ids = {a.author_id for a in batch.authors}
        assert {p.author_id for p in batch.posts}.issubset(author_ids)

    def test_reply_structure_exists_for_graph_construction(self):
        batch = DemoDataAdapter(seed=7, target_posts=900).fetch()
        replies = [p for p in batch.posts if p.reply_to_id]
        assert len(replies) > 30
        ids = {p.id for p in batch.posts}
        assert all(r.reply_to_id in ids for r in replies)
