import { Suspense } from 'react';

import { AppShell } from '@/components/layout/AppShell';
import { FilterProvider } from '@/features/filters/FilterContext';

import { NetworkView } from './NetworkView';

export const metadata = { title: 'Network — PulseGraph AI' };

export default function Page() {
  return (
    <Suspense fallback={null}>
      <FilterProvider>
        <AppShell>
          <NetworkView />
        </AppShell>
      </FilterProvider>
    </Suspense>
  );
}
