'use client';

/**
 * KPI strip.
 *
 * Each tile carries a value and its change against the immediately preceding
 * window of equal length, so a number is never presented without a baseline.
 */

import { Delta, Skeleton, cx } from '@/components/ui/primitives';
import { compactNumber, percent } from '@/lib/format';
import type { KPI } from '@/types/api';

/** Negative-sentiment growth is bad news; post-volume growth is not. */
const INVERTED_KEYS = new Set(['negative_share']);

export function KpiStrip({ kpis, loading }: { kpis: KPI[] | null; loading?: boolean }) {
  if (loading || !kpis) {
    return (
      <div
        role="status"
        aria-label="Loading key metrics"
        className="grid grid-cols-2 gap-px overflow-hidden rounded-card border border-edge bg-edge sm:grid-cols-4 xl:grid-cols-7"
      >
        {Array.from({ length: 7 }).map((_, i) => (
          <div key={i} className="bg-canvas-raised p-3">
            <Skeleton className="h-2.5 w-16" />
            <Skeleton className="mt-2 h-5 w-12" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-px overflow-hidden rounded-card border border-edge bg-edge sm:grid-cols-4 xl:grid-cols-7">
      {kpis.map((kpi) => {
        const isSentiment = kpi.key === 'positive_share' || kpi.key === 'negative_share';
        return (
          <div key={kpi.key} className="bg-canvas-raised p-3">
            <p className="flex items-center gap-1.5 text-2xs text-ink-faint">
              {isSentiment && (
                <span
                  className={cx(
                    'h-1.5 w-1.5 rounded-full',
                    kpi.key === 'positive_share' ? 'bg-positive' : 'bg-negative',
                  )}
                  aria-hidden
                />
              )}
              {kpi.label}
            </p>
            <p className="mt-1.5 font-mono text-xl font-semibold leading-none tabular-nums text-ink">
              {kpi.format === 'percent' ? percent(kpi.value) : compactNumber(kpi.value)}
            </p>
            <div className="mt-1.5">
              <Delta value={kpi.change} invert={INVERTED_KEYS.has(kpi.key)} />
            </div>
          </div>
        );
      })}
    </div>
  );
}
