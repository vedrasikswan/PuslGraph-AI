"""Typed API contracts.

The frontend's TypeScript types mirror these. Response models stay
intentionally permissive on nested analytic payloads (they are already
validated at the point of computation) while pinning the envelope shape that
the UI depends on.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator

Severity = Literal["critical", "high", "medium", "low", "info"]
Granularity = Literal["hourly", "6-hourly", "daily", "weekly"]


class HealthResponse(BaseModel):
    status: Literal["ok", "degraded"]
    version: str
    demo_mode: bool
    database: str
    ai_provider: dict
    dataset_ready: bool
    posts: int
    last_run: dict | None = None


class FilterState(BaseModel):
    start: datetime | None = None
    end: datetime | None = None
    platforms: list[str] = Field(default_factory=list)
    topics: list[str] = Field(default_factory=list)
    segments: list[str] = Field(default_factory=list)
    sentiments: list[str] = Field(default_factory=list)
    emotions: list[str] = Field(default_factory=list)
    search: str = ""
    granularity: Granularity = "hourly"
    active: bool = False


class Evidence(BaseModel):
    metric: str
    value: Any
    change: str | None = None
    period: str = ""
    note: str = ""


class KPI(BaseModel):
    key: str
    label: str
    value: float
    change: float | None = None
    format: Literal["number", "percent"]


class AudiencePulse(BaseModel):
    headline: str
    statement: str
    severity: Severity
    confidence: float
    confidence_band: Literal["High", "Medium", "Low"]
    detected_at: datetime
    topic_id: str | None = None
    topic_label: str | None = None
    affected_platforms: list[str] = Field(default_factory=list)
    affected_segments: list[str] = Field(default_factory=list)
    evidence: list[Evidence] = Field(default_factory=list)
    recommended_action: str = ""
    supporting_events: list[dict] = Field(default_factory=list)
    interpretation_source: str = "local"


class OverviewResponse(BaseModel):
    empty: bool
    kpis: list[KPI]
    avg_polarity: float = 0.0
    sarcasm_rate: float = 0.0
    sentiment_distribution: list[dict] = Field(default_factory=list)
    emotion_distribution: list[dict] = Field(default_factory=list)
    platform_distribution: list[dict] = Field(default_factory=list)
    range: dict
    pulse: AudiencePulse | None = None
    filters: FilterState
    recommendations: list[dict] = Field(default_factory=list)


class TimelineResponse(BaseModel):
    granularity: Granularity
    points: list[dict]
    total: int
    filters: FilterState


class TrendItem(BaseModel):
    topic_id: str
    label: str
    description: str = ""
    trend_score: float
    classification: Literal["stable", "emerging", "growing", "accelerating", "viral"]
    velocity: dict
    sentiment: dict
    platforms: list[str]
    platform_count: int
    influencer_participation: float
    persistence: float
    momentum: dict
    components: dict
    series: list[dict] = Field(default_factory=list)


class TrendsResponse(BaseModel):
    items: list[TrendItem]
    filters: FilterState


class IntelligenceCard(BaseModel):
    id: str
    category: str
    title: str
    summary: str
    severity: Severity
    confidence: float
    confidence_band: Literal["High", "Medium", "Low"]
    detected_at: datetime
    window: dict
    topic_id: str | None = None
    topic_label: str | None = None
    drivers: list[str] = Field(default_factory=list)
    affected_segments: list[str] = Field(default_factory=list)
    affected_platforms: list[str] = Field(default_factory=list)
    related_nodes: list[dict] = Field(default_factory=list)
    evidence: list[Evidence] = Field(default_factory=list)
    recommended_action: str = ""
    interpretation_source: str = "local"


class IntelligenceResponse(BaseModel):
    items: list[IntelligenceCard]
    filters: FilterState


class AudienceResponse(BaseModel):
    segments: list[dict]
    demographics: dict
    total_authors: int
    privacy_notice: str
    filters: FilterState


class NetworkResponse(BaseModel):
    nodes: list[dict]
    edges: list[dict]
    communities: list[dict] = Field(default_factory=list)
    truncated: bool = False
    total_nodes: int = 0
    total_edges: int = 0
    displayed_nodes: int = 0
    empty: bool = False
    filters: FilterState


class PostsResponse(BaseModel):
    items: list[dict]
    page: int
    page_size: int
    total: int
    pages: int
    filters: FilterState


class SourceInfo(BaseModel):
    id: str
    platform: str
    display_name: str
    tier: str
    status: Literal["connected", "demo", "not_connected", "error"]
    requires_credentials: bool
    credential_fields: list[str]
    missing_credentials: list[str] = Field(default_factory=list)
    capabilities: list[str] = Field(default_factory=list)
    docs_url: str = ""
    live_ready: bool = False
    demo_available: bool = True
    post_count: int = 0


class SourcesResponse(BaseModel):
    sources: list[SourceInfo]
    demo_mode: bool
    last_run: dict | None = None


class IngestionRequest(BaseModel):
    sources: list[str] = Field(default_factory=lambda: ["demo"])
    seed: int | None = None
    target_posts: int | None = None

    @field_validator("target_posts")
    @classmethod
    def _bounded(cls, value: int | None) -> int | None:
        if value is not None and not (200 <= value <= 6000):
            raise ValueError("target_posts must be between 200 and 6000")
        return value


class IngestionResponse(BaseModel):
    status: str
    run: dict
    validation: dict
    message: str


class AnalyzeRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)
    language: str = "en"


class AnalyzeResponse(BaseModel):
    text: str
    sentiment: str
    sentiment_confidence: float
    confidence_band: str
    stance: str
    emotion: str
    emotion_confidence: float
    polarity: float
    literal_sentiment: str
    contextual_sentiment: str
    sarcasm_detected: bool
    sarcasm_confidence: float
    cues: dict
    model: str
    model_version: str
    status: str


class ErrorResponse(BaseModel):
    error: str
    detail: str
    hint: str = ""
