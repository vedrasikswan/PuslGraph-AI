'use client';

/**
 * Interactive sentiment time series.
 *
 * Clicking a bucket sets the global time window, which re-derives every other
 * panel on the page — this is the primary cross-filtering entry point.
 */

import { useMemo } from 'react';
import {
  Area,
  Bar,
  CartesianGrid,
  ComposedChart,
  Legend,
  Line,
  ReferenceArea,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

import { COLORS, SENTIMENT_COLORS } from '@/lib/colors';
import { compactNumber, dateTime, tickLabel } from '@/lib/format';
import type { Granularity, TimelinePoint } from '@/types/api';

const GRANULARITY_MS: Record<Granularity, number> = {
  hourly: 3_600_000,
  '6-hourly': 21_600_000,
  daily: 86_400_000,
  weekly: 604_800_000,
};

interface Props {
  points: TimelinePoint[];
  granularity: Granularity;
  onSelectWindow?: (start: string, end: string) => void;
  selected?: { start?: string; end?: string };
  showPolarity?: boolean;
  height?: number;
}

function ChartTooltip({ active, payload }: { active?: boolean; payload?: { payload: TimelinePoint }[] }) {
  if (!active || !payload?.length) return null;
  const point = payload[0].payload;
  const rows: [string, string, string][] = [
    ['Positive', String(point.positive), SENTIMENT_COLORS.positive],
    ['Neutral', String(point.neutral), SENTIMENT_COLORS.neutral],
    ['Negative', String(point.negative), SENTIMENT_COLORS.negative],
  ];
  return (
    <div className="rounded border border-edge-strong bg-canvas-raised px-2.5 py-2 shadow-xl">
      <p className="text-2xs font-medium text-ink">{dateTime(point.ts)}</p>
      <table className="mt-1.5 text-2xs">
        <tbody>
          {rows.map(([label, value, color]) => (
            <tr key={label}>
              <td className="pr-2">
                <span className="inline-flex items-center gap-1.5 text-ink-muted">
                  <span
                    className="h-1.5 w-1.5 rounded-full"
                    style={{ backgroundColor: color }}
                    aria-hidden
                  />
                  {label}
                </span>
              </td>
              <td className="text-right font-mono tabular-nums text-ink">{value}</td>
            </tr>
          ))}
          <tr className="border-t border-edge-subtle">
            <td className="pr-2 pt-1 text-ink-faint">Avg polarity</td>
            <td className="pt-1 text-right font-mono tabular-nums text-ink-muted">
              {point.avg_polarity >= 0 ? '+' : ''}
              {point.avg_polarity.toFixed(2)}
            </td>
          </tr>
          <tr>
            <td className="pr-2 text-ink-faint">Authors</td>
            <td className="text-right font-mono tabular-nums text-ink-muted">
              {point.unique_authors}
            </td>
          </tr>
          {point.sarcasm > 0 && (
            <tr>
              <td className="pr-2 text-ink-faint">Sarcastic</td>
              <td className="text-right font-mono tabular-nums text-warning">{point.sarcasm}</td>
            </tr>
          )}
        </tbody>
      </table>
      <p className="mt-1.5 border-t border-edge-subtle pt-1 text-[10px] text-ink-faint">
        Click to filter the dashboard to this interval
      </p>
    </div>
  );
}

export function SentimentTimeline({
  points,
  granularity,
  onSelectWindow,
  selected,
  showPolarity = true,
  height = 240,
}: Props) {
  const data = useMemo(
    () => points.map((p) => ({ ...p, tick: tickLabel(p.ts, granularity) })),
    [points, granularity],
  );

  function handleClick(state: { activePayload?: { payload: TimelinePoint }[] }) {
    if (!onSelectWindow || !state?.activePayload?.length) return;
    const point = state.activePayload[0].payload;
    const start = new Date(point.ts);
    const end = new Date(start.getTime() + GRANULARITY_MS[granularity]);
    onSelectWindow(
      start.toISOString().slice(0, 19),
      end.toISOString().slice(0, 19),
    );
  }

  return (
    <ResponsiveContainer width="100%" height={height}>
      <ComposedChart
        data={data}
        margin={{ top: 8, right: 8, bottom: 0, left: -18 }}
        onClick={handleClick}
        style={{ cursor: onSelectWindow ? 'pointer' : 'default' }}
      >
        <CartesianGrid strokeDasharray="2 4" vertical={false} />
        <XAxis
          dataKey="tick"
          tickLine={false}
          axisLine={{ stroke: COLORS.grid }}
          minTickGap={28}
          interval="preserveStartEnd"
        />
        <YAxis
          yAxisId="volume"
          tickLine={false}
          axisLine={false}
          width={44}
          tickFormatter={(v: number) => compactNumber(v)}
        />
        {showPolarity && (
          <YAxis
            yAxisId="polarity"
            orientation="right"
            domain={[-1, 1]}
            ticks={[-1, 0, 1]}
            tickLine={false}
            axisLine={false}
            width={28}
          />
        )}
        <Tooltip content={<ChartTooltip />} cursor={{ fill: 'rgba(129,140,248,0.07)' }} />
        <Legend
          verticalAlign="top"
          align="right"
          height={22}
          iconSize={8}
          formatter={(value: string) => (
            <span className="text-2xs text-ink-muted">{value}</span>
          )}
        />

        {selected?.start && selected?.end && (
          <ReferenceArea
            yAxisId="volume"
            x1={tickLabel(selected.start, granularity)}
            x2={tickLabel(selected.end, granularity)}
            fill={COLORS.trend}
            fillOpacity={0.1}
            stroke={COLORS.trend}
            strokeOpacity={0.4}
          />
        )}

        <Bar yAxisId="volume" dataKey="positive" name="Positive" stackId="s"
             fill={SENTIMENT_COLORS.positive} maxBarSize={26} />
        <Bar yAxisId="volume" dataKey="neutral" name="Neutral" stackId="s"
             fill={SENTIMENT_COLORS.neutral} fillOpacity={0.5} maxBarSize={26} />
        <Bar yAxisId="volume" dataKey="negative" name="Negative" stackId="s"
             fill={SENTIMENT_COLORS.negative} maxBarSize={26} />

        {showPolarity && (
          <>
            <Area
              yAxisId="polarity"
              type="monotone"
              dataKey="avg_polarity"
              name="Avg polarity"
              stroke="none"
              fill={COLORS.trend}
              fillOpacity={0.06}
            />
            <Line
              yAxisId="polarity"
              type="monotone"
              dataKey="avg_polarity"
              name="Avg polarity"
              stroke={COLORS.trend}
              strokeWidth={1.5}
              dot={false}
              activeDot={{ r: 3 }}
            />
          </>
        )}
      </ComposedChart>
    </ResponsiveContainer>
  );
}
