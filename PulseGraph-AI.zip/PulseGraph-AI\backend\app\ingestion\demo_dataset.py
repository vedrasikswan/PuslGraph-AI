"""Deterministic synthetic dataset for demo mode.

This is *not* random filler. The generator scripts a realistic social event and
lets the analytics engine rediscover it:

    A niche Telegram channel starts reporting battery drain after the NovaPhone X
    v14.2 update. Two high-reach accounts pick it up. The complaint crosses to X
    roughly three quarters of an hour later, accelerates, pulls in a second
    (older, less technical) audience segment, spawns a recall rumour, and gets
    partially debunked.

Nothing downstream is told this story. Sentiment, topics, segments, network
metrics, trends and intelligence events are all derived from the generated text
and interaction structure, which is what makes the demo an honest showcase.

Determinism: a fixed seed drives all sampling. Timestamps are expressed as
offsets from an hour-aligned anchor so repeated runs reproduce the same
structure while the dashboard still shows a "recent" window.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from app.analytics.topics import TOPIC_DEFINITIONS
from app.ingestion.base import NormalizedAuthor, NormalizedPost

# --------------------------------------------------------------------------- #
# Reference world
# --------------------------------------------------------------------------- #
TIMELINE_HOURS = 168  # 7 days of history

REGIONS = [
    ("Bengaluru, IN", "South Asia", "en"),
    ("Mumbai, IN", "South Asia", "hi"),
    ("Delhi NCR, IN", "South Asia", "hi"),
    ("Pune, IN", "South Asia", "en"),
    ("Hyderabad, IN", "South Asia", "en"),
    ("Chennai, IN", "South Asia", "en"),
    ("London, UK", "Western Europe", "en"),
    ("Manchester, UK", "Western Europe", "en"),
    ("Berlin, DE", "Western Europe", "de"),
    ("Toronto, CA", "North America", "en"),
    ("Austin, US", "North America", "en"),
    ("Seattle, US", "North America", "en"),
    ("Singapore", "Southeast Asia", "en"),
    ("Jakarta, ID", "Southeast Asia", "id"),
    ("Dubai, AE", "Middle East", "en"),
    ("São Paulo, BR", "South America", "pt"),
]

# archetype -> generation behaviour. These are *inputs* to the simulation, not
# labels the analytics layer is allowed to read: segmentation re-derives its own
# clusters from observed behaviour.
ARCHETYPES: dict[str, dict] = {
    "tech_enthusiast": {
        "bios": [
            "Android tinkerer. Custom ROMs, benchmarks, too many chargers.",
            "CS undergrad. I flash firmware for fun. Battery graphs are my hobby.",
            "Mobile dev by day, spec sheet nerd by night.",
            "Final year engineering student. I read changelogs so you don't have to.",
            "19. Phones, builds, and bad takes about refresh rates.",
            "Software developer. Rooting phones since college.",
            "22, university, and a drawer full of test devices.",
            "Kernel hobbyist. Opinions my own, benchmarks reproducible.",
        ],
        "followers": (400, 9000),
        "age_hint": "18-24",
        "verbosity": 1.0,
        "post_weight": 2.4,
    },
    "concerned_customer": {
        "bios": [
            "Just a regular user who bought this phone with hard-earned money.",
            "Parent of two, commuter, needs a phone that lasts the day.",
            "Long-time Nova customer since 2016.",
            "Small business owner. My phone is my office.",
            "Not a techie. I just want things to work.",
            "Dad, cyclist, and reluctant early adopter.",
            "Project manager. Phone is a work tool, not a hobby.",
            "Mother of three. I need a phone that survives the school run.",
            "Consultant, always travelling, always low on battery.",
        ],
        "followers": (30, 1200),
        "age_hint": "35-44",
        "verbosity": 0.9,
        "post_weight": 1.6,
    },
    "supporter": {
        "bios": [
            "Nova fan since day one. Still the best hardware out there.",
            "Team Nova. Been using them for six years, zero regrets.",
            "Community moderator. Helping people get the most out of their device.",
            "Enthusiast, not an employee. I just like good phones.",
            "Designer. Been on Nova since 2018, no regrets.",
            "Forum moderator and long-time owner.",
        ],
        "followers": (200, 6000),
        "age_hint": "25-34",
        "verbosity": 0.9,
        "post_weight": 1.5,
    },
    "amplifier": {
        "bios": [
            "Tech news, fast. Retweets are not endorsements.",
            "I share what's trending in mobile. DMs open.",
            "Curating the timeline so you don't have to scroll.",
            "Daily tech roundups. Link in bio.",
            "Analyst by day, curating mobile news the rest of the time.",
            "Sharing the best of mobile. Founder of a small newsletter.",
        ],
        "followers": (5000, 45000),
        "age_hint": "25-34",
        "verbosity": 0.6,
        "post_weight": 2.0,
    },
    "reviewer": {
        "bios": [
            "Independent device reviewer. 12 years of teardown notes.",
            "I test phones properly: same brightness, same workload, same week.",
            "Long-form reviews. No sponsored takes on launch day.",
            "Hardware analyst. Charts, not vibes.",
        ],
        "followers": (25000, 320000),
        "age_hint": "25-34",
        "verbosity": 1.3,
        "post_weight": 1.1,
    },
    "observer": {
        "bios": [
            "Mostly lurking.",
            "here for the drama",
            "Reader. Occasional poster.",
            "Student. Mostly here for the phone news.",
            "Teacher, parent, occasional poster.",
            "",
            "Just browsing. Opinions rare.",
            "Nurse. Phone matters more than you'd think on shift.",
            "Retired, and still curious about gadgets.",
            "Accountant. Here for the deals.",
        ],
        "followers": (5, 300),
        "age_hint": "25-34",
        "verbosity": 0.6,
        "post_weight": 0.6,
    },
    "support_agent": {
        "bios": [
            "Official Nova Mobility support handle. Mon-Sat, 9-9 IST.",
            "Nova Care team. Share your ticket ID and we'll pick it up.",
        ],
        "followers": (12000, 90000),
        "age_hint": "25-34",
        "verbosity": 0.8,
        "post_weight": 1.2,
    },
    "news_account": {
        "bios": [
            "Consumer technology desk. Verified reporting only.",
            "Mobile industry coverage since 2011.",
        ],
        "followers": (40000, 400000),
        "age_hint": "35-44",
        "verbosity": 1.1,
        "post_weight": 0.9,
    },
}

PLATFORM_MIX: dict[str, list[tuple[str, float]]] = {
    # archetype -> platform preference weights
    "tech_enthusiast": [("x", 0.42), ("telegram", 0.26), ("reddit", 0.24), ("youtube", 0.08)],
    "concerned_customer": [("x", 0.46), ("facebook", 0.22), ("telegram", 0.14), ("youtube", 0.18)],
    "supporter": [("x", 0.44), ("telegram", 0.2), ("instagram", 0.18), ("reddit", 0.18)],
    "amplifier": [("x", 0.66), ("telegram", 0.22), ("reddit", 0.12)],
    "reviewer": [("x", 0.5), ("youtube", 0.28), ("reddit", 0.14), ("instagram", 0.08)],
    "observer": [("x", 0.4), ("youtube", 0.24), ("facebook", 0.2), ("reddit", 0.16)],
    "support_agent": [("x", 0.7), ("facebook", 0.3)],
    "news_account": [("x", 0.6), ("telegram", 0.25), ("youtube", 0.15)],
}

FIRST_NAMES = [
    "aarav", "isha", "rohan", "meera", "kabir", "nisha", "arjun", "tara", "dev", "sana",
    "liam", "emma", "noah", "olivia", "ethan", "mia", "lucas", "chloe", "felix", "hanna",
    "mateo", "sofia", "jonas", "priya", "vikram", "anita", "raj", "neha", "sam", "alex",
    "yusuf", "leila", "wei", "mina", "tomas", "clara", "ravi", "divya", "omar", "zara",
]
LAST_TOKENS = [
    "codes", "builds", "reads", "walks", "tech", "daily", "hq", "labs", "notes", "live",
    "97", "88", "x", "dev", "in", "uk", "sg", "io", "media", "review",
]

# --------------------------------------------------------------------------- #
# Content templates
#
# Written so that tone is carried by real language rather than by a label:
# the sentiment engine sees only this text.
# --------------------------------------------------------------------------- #
T: dict[str, dict[str, list[str]]] = {
    "battery-drain": {
        "complaint": [
            "Since the {version} update my NovaPhone X drops from {high}% to {low}% in about {hours} hours of light use. This is not normal.",
            "Battery on the NovaPhone X is draining way faster after {version}. Screen on time went from {sot1} hours to barely {sot2}.",
            "Anyone else? {version} killed my battery. Phone is at {low}% by lunch and I have done nothing but messages.",
            "My NovaPhone X used to comfortably last a full day. After the update I am carrying a power bank again. Very disappointed.",
            "Overnight standby drain is {drop}% now. Before {version} it was {small}%. Something in this build is broken.",
            "The phone is noticeably warm in my pocket after the update and the battery is disappearing. Not happy at all.",
            "Charged to 100 at 8am, dead by 6pm with almost no usage. This started the day I installed {version}.",
            "Battery health still shows 98% so this is clearly the software, not the cell. Please fix it.",
            "Two days after updating and the battery is a disaster. Considering rolling back if that is even possible.",
            "Genuinely frustrating. I paid a premium for this phone and now it cannot survive a working day.",
        ],
        "technical": [
            "Logged it properly: idle drain is {drop}%/hour post-{version} versus {small}%/hour before. Same apps, same brightness, airplane mode overnight.",
            "Battery stats show the system process holding wakelocks for {hours} hours. Looks like a background service is not sleeping after {version}.",
            "Ran the same workload on {version} and the previous build. Screen on time dropped {pct}%. Reproducible across two units.",
            "The regression seems tied to the always-on display scheduler. Disabling AOD recovers roughly {pct}% of the loss for me.",
            "Collected logs from three devices. All show the same wakelock pattern after the {version} rollout. Sharing the traces in the thread.",
            "Not a calibration issue. I did a full discharge and recharge cycle twice and the drain rate is unchanged.",
        ],
        "sarcasm": [
            "Great, another update that makes my battery worse. Amazing engineering, truly.",
            "Love how my {price} phone now needs charging twice a day. Fantastic upgrade.",
            "Wonderful. The battery lasts {hours} hours now. Best update ever, no notes.",
            "Perfect timing for a battery bug, right before a long trip. Brilliant.",
            "Oh good, the update improved battery life so much that I get to see the charging animation five times a day.",
            "Thanks for the amazing new feature where my battery dies before dinner. Really premium experience.",
        ],
        "support_request": [
            "Has anyone found a workaround for the {version} battery drain? Tried clearing cache, no change.",
            "Is there a way to roll back to the previous build? Support has not replied in {hours} hours.",
            "Which setting is causing this? I have already turned off background refresh and it is still draining.",
            "Should I do a factory reset or wait for a patch? Losing a whole day of battery here.",
            "Anyone from Nova monitoring this? Ticket raised, no response yet.",
        ],
        "neutral": [
            "Seeing several reports of battery drain on the NovaPhone X after {version}. Collecting details here.",
            "Tracking this thread. My unit has not updated yet so I cannot confirm either way.",
            "Mixed reports so far: some units affected, some not. Might depend on region or build number.",
            "For reference my build is {version} and drain looks normal. Adding a data point.",
            "Worth noting this only seems to affect devices that updated in the last {hours} hours.",
        ],
        "defence": [
            "Every major update has a settling period. Give it {hours} hours for the indexing to finish before panicking.",
            "Mine is completely fine on {version}. Full day of use, no drain issues at all.",
            "This is being blown out of proportion. A handful of reports is not a widespread failure.",
            "Battery recalibration after an update is normal. Charge cycle it once and check again.",
        ],
        "resolution": [
            "Nova support confirmed they are investigating the {version} battery reports. Patch expected shortly.",
            "Disabling the new adaptive sync mode fixed most of the drain for me. Back to roughly normal.",
            "Update: after {hours} hours the drain settled down significantly on my unit.",
        ],
        "hinglish": [
            "Yaar {version} update ke baad battery bilkul khatam ho jaati hai. Poora din nahi chalta.",
            "Bhai battery drain ka issue serious hai, subah full charge aur shaam tak {low}% pe aa jaata hai.",
            "Update ke baad phone garam bhi ho raha hai aur battery bhi jaldi khatam. Bahut bura experience.",
            "Kya kisi ko fix mila? Mera phone {version} ke baad {hours} ghante bhi nahi chal raha.",
        ],
    },
    "update-142": {
        "neutral": [
            "{version} is rolling out here now. Build size is about {size} GB.",
            "Changelog for {version} mentions camera tuning and security patches. Nothing about power management.",
            "Rollout appears staged. Some regions got {version} two days before others.",
            "Installed {version} this morning. Will report back after a full day of use.",
        ],
        "praise": [
            "{version} fixed the stutter in the recents menu. That alone was worth the download.",
            "Nice, the new gesture navigation in {version} is much smoother than before.",
            "Security patch level is finally current after {version}. Good to see.",
        ],
        "complaint": [
            "{version} broke Bluetooth pairing with my car. Second update in a row with a regression.",
            "Why does every {version} style release ship without a proper beta window?",
            "Update installed itself overnight without asking. Not a fan of that.",
        ],
        "technical": [
            "Diffed the {version} package: two power management modules changed and the scheduler config was replaced.",
            "The {version} build increments the kernel but keeps the same vendor blobs, which is unusual for a point release.",
        ],
        "sarcasm": [
            "Another update that fixes three things and breaks four. Consistency at last.",
        ],
    },
    "camera-quality": {
        "praise": [
            "Low light shots on the NovaPhone X are genuinely excellent. Took this at {time} with no tripod.",
            "The portrait edge detection is the best I have used on any phone in this price range.",
            "Night mode is doing serious work here. Almost no noise at {iso} ISO.",
            "Colour science on this camera is lovely. Skin tones look natural for once.",
            "Zoom is sharper than I expected at 5x. Very happy with this camera.",
        ],
        "neutral": [
            "Camera comparison thread: NovaPhone X versus Orbit 12 in the same lighting.",
            "Shot on NovaPhone X, no editing, default settings.",
            "The camera app got a new layout in the update. Same sensor as far as I can tell.",
        ],
        "complaint": [
            "Camera app takes {sec} seconds to open since the update. Missed the shot completely.",
            "Video stabilisation is worse than it was last month. Noticeable wobble at 4K.",
        ],
    },
    "nova-support": {
        "complaint": [
            "Third day waiting on Nova support. Ticket {ticket} still shows as open with no update.",
            "Called the helpline twice, got disconnected twice. Service centre says they cannot help with software issues.",
            "Support asked me to factory reset without even looking at the logs I sent. Not acceptable.",
            "The service centre wants to keep my phone for {days} days to investigate a software bug. That is absurd.",
            "Escalated ticket {ticket} a week ago. Still no engineer assigned. Terrible experience.",
            "Warranty claim rejected because the drain is a software issue, but the software team says contact the service centre. Going in circles.",
        ],
        "resolution": [
            "Credit where due: Nova support called back within {hours} hours and logged the drain reports properly.",
            "Ticket {ticket} finally resolved. They confirmed a known issue and offered a replacement unit.",
            "Support engineer was actually helpful and collected the battery logs remotely. Good handling.",
        ],
        "neutral": [
            "If you are raising a ticket, include the build number and a battery graph screenshot. Speeds things up.",
            "Support hours are 9 to 9 local time. Weekend response is slower.",
        ],
        "official": [
            "We are aware of the battery reports following {version} and our engineering team is investigating. Please share your ticket ID so we can prioritise.",
            "Thanks for flagging this. Could you send your build number and battery usage screenshot via direct message so we can log it?",
            "A fix is being validated internally. We will share a timeline once it clears testing.",
        ],
    },
    "price-drop": {
        "praise": [
            "NovaPhone X just dropped by {price} in the festive sale. That is a genuinely good deal now.",
            "Exchange offer plus the discount brings it under {price}. Very tempting.",
            "Picked one up at the reduced price. At this number the hardware is hard to beat.",
        ],
        "neutral": [
            "Price tracker shows the NovaPhone X at {price} today, down from launch.",
            "Discount seems to be regional. Still full price in my market.",
        ],
        "complaint": [
            "Bought it three weeks ago at full price and now it is {price} cheaper. Frustrating.",
            "Price cut this soon after launch usually means stock is not moving. Says a lot.",
        ],
        "sarcasm": [
            "Nothing says confidence like a price cut {days} days after launch. Very reassuring.",
        ],
    },
    "nova-launch": {
        "praise": [
            "Finally unboxed the NovaPhone X. Build quality is superb, the weight distribution is perfect.",
            "Day one with the NovaPhone X and I am impressed. Display is stunning.",
            "Preorder arrived early. First impressions: fast, cool, excellent screen.",
            "This is the best hardware Nova has shipped. Genuinely excited to use it daily.",
            "Switched from my three year old phone and the difference is night and day. Delighted.",
        ],
        "neutral": [
            "Unboxing thread for the NovaPhone X. Specs in the replies.",
            "Delivery slipped by {days} days but it arrived. Setting it up now.",
            "First impressions post coming after a week of proper use, not day one hot takes.",
        ],
        "excited": [
            "It is here!! Been waiting for this since the announcement. Setting it up right now.",
            "Cannot believe how good this screen looks in person. Absolutely worth the wait.",
        ],
    },
    "recall-rumor": {
        "misinformation": [
            "Hearing the NovaPhone X is about to be recalled over the battery issue. Multiple sources.",
            "A friend at a service centre says they have been told to stop selling the NovaPhone X. Recall incoming.",
            "This is a safety issue now, not a software bug. Regulators are apparently looking at it.",
            "Forwarded: NovaPhone X units are being pulled from shelves in three markets over battery risk.",
            "If a phone drains this fast something is wrong with the cell itself. Recall is inevitable.",
        ],
        "debunk": [
            "There is no recall. No regulator filing, no press release, nothing on the official channels. Please stop forwarding this.",
            "Checked directly with two retailers. Stock is normal, no stop-sale notice. The recall claim is unverified.",
            "Battery drain from a firmware regression is not a safety hazard. These are different problems.",
            "The recall message circulating has no source attached. Treat it as rumour until a regulator says otherwise.",
            "Reminder that a screenshot of a message is not a source.",
        ],
        "anxious": [
            "Now I am worried about keeping this phone charging next to my bed overnight. Should I stop?",
            "Is it actually dangerous or is this just a battery software bug? Getting conflicting information.",
            "My whole family uses these phones. This recall talk is stressing me out.",
        ],
    },
    "nova-vs-orbit": {
        "neutral": [
            "NovaPhone X versus Orbit 12: display and camera to Nova, battery and support to Orbit.",
            "Side by side comparison after two weeks with both. Thread below.",
            "Both phones are good. They are optimised for different priorities.",
        ],
        "praise": [
            "Even with the battery issue the NovaPhone X display is far ahead of the Orbit 12.",
            "Orbit 12 battery is better, but the Nova camera is in a different league.",
        ],
        "against": [
            "Switching to the Orbit 12. The battery situation was the last straw for me.",
            "After this update I would not recommend the NovaPhone X. Get the Orbit 12 instead.",
            "Returning mine and moving to Orbit. Cannot deal with a phone that dies by evening.",
        ],
        "curious": [
            "Anyone here moved from Nova to Orbit recently? Is the software as clean?",
            "Genuinely undecided between these two. What matters more day to day, camera or battery?",
        ],
    },
}

SLOTS: dict[str, list[str]] = {
    "version": ["v14.2", "v14.2", "v14.2.1", "the 14.2 build"],
    "high": ["100", "96", "92", "88"],
    "low": ["18", "22", "14", "27", "31"],
    "hours": ["3", "4", "5", "6", "8", "12", "36", "48"],
    "sot1": ["6.5", "7", "5.8", "6"],
    "sot2": ["3", "2.5", "3.4", "2.8"],
    "drop": ["18", "22", "14", "26"],
    "small": ["2", "3", "1.5", "4"],
    "pct": ["31", "42", "28", "37", "45"],
    "price": ["4,000", "6,500", "8,000", "12,000"],
    "size": ["1.4", "2.1", "1.8"],
    "time": ["9pm", "11pm", "dusk", "2am"],
    "iso": ["3200", "6400", "1600"],
    "sec": ["3", "4", "2.5"],
    "ticket": ["NX-48213", "NX-51907", "NX-46650", "NX-52288"],
    "days": ["10", "14", "21", "7"],
}


@dataclass(slots=True)
class Phase:
    """One scripted stage of the incident arc."""

    name: str
    start_h: float           # hours before the anchor (larger = earlier)
    end_h: float
    platforms: list[tuple[str, float]]
    tones: list[tuple[str, float]]
    archetypes: list[tuple[str, float]]
    volume: int
    topic: str = "battery-drain"
    engagement_boost: float = 1.0


# The incident arc. Telegram leads, X follows ~45-50 minutes later, volume and
# negativity build, an older audience joins, a rumour spawns and gets debunked.
INCIDENT_PHASES: list[Phase] = [
    Phase(
        "origin", 9.0, 8.6,
        platforms=[("telegram", 1.0)],
        tones=[("technical", 0.55), ("neutral", 0.25), ("complaint", 0.2)],
        archetypes=[("tech_enthusiast", 0.85), ("concerned_customer", 0.15)],
        volume=9, engagement_boost=0.5,
    ),
    Phase(
        "early_corroboration", 8.6, 8.1,
        platforms=[("telegram", 0.85), ("reddit", 0.15)],
        tones=[("technical", 0.5), ("neutral", 0.32), ("complaint", 0.18)],
        archetypes=[("tech_enthusiast", 0.7), ("observer", 0.15), ("concerned_customer", 0.15)],
        volume=16, engagement_boost=0.7,
    ),
    Phase(
        "influencer_pickup", 8.1, 7.85,
        platforms=[("telegram", 0.5), ("x", 0.5)],
        tones=[("technical", 0.72), ("neutral", 0.28)],
        archetypes=[("reviewer", 0.75), ("amplifier", 0.25)],
        volume=6, engagement_boost=3.2,
    ),
    Phase(
        "cross_platform_jump", 7.8, 7.0,
        platforms=[("x", 0.82), ("telegram", 0.18)],
        tones=[("technical", 0.34), ("complaint", 0.3), ("neutral", 0.22),
               ("support_request", 0.14)],
        archetypes=[("tech_enthusiast", 0.55), ("amplifier", 0.2), ("concerned_customer", 0.25)],
        volume=34, engagement_boost=1.6,
    ),
    Phase(
        "acceleration", 7.0, 5.2,
        platforms=[("x", 0.72), ("reddit", 0.16), ("telegram", 0.12)],
        tones=[("complaint", 0.4), ("technical", 0.2), ("support_request", 0.16),
               ("sarcasm", 0.14), ("hinglish", 0.1)],
        archetypes=[("tech_enthusiast", 0.4), ("concerned_customer", 0.34),
                    ("observer", 0.14), ("amplifier", 0.12)],
        volume=118, engagement_boost=1.9,
    ),
    Phase(
        "second_segment", 5.2, 3.4,
        platforms=[("x", 0.55), ("facebook", 0.16), ("youtube", 0.17), ("reddit", 0.12)],
        tones=[("complaint", 0.54), ("support_request", 0.18), ("sarcasm", 0.16),
               ("hinglish", 0.12)],
        archetypes=[("concerned_customer", 0.62), ("observer", 0.22), ("tech_enthusiast", 0.16)],
        volume=142, engagement_boost=1.5,
    ),
    Phase(
        "peak", 3.4, 1.4,
        platforms=[("x", 0.6), ("youtube", 0.14), ("reddit", 0.13), ("telegram", 0.08),
                   ("facebook", 0.05)],
        tones=[("complaint", 0.52), ("sarcasm", 0.22), ("support_request", 0.14),
               ("defence", 0.06), ("neutral", 0.06)],
        archetypes=[("concerned_customer", 0.42), ("tech_enthusiast", 0.28),
                    ("observer", 0.16), ("amplifier", 0.09), ("reviewer", 0.05)],
        volume=168, engagement_boost=1.7,
    ),
    Phase(
        "official_response", 3.0, 2.2,
        platforms=[("x", 0.85), ("facebook", 0.15)],
        tones=[("official", 1.0)],
        archetypes=[("support_agent", 1.0)],
        volume=7, topic="nova-support", engagement_boost=2.4,
    ),
    Phase(
        "plateau", 1.4, 0.4,
        platforms=[("x", 0.55), ("reddit", 0.17), ("youtube", 0.14), ("telegram", 0.09),
                   ("facebook", 0.05)],
        tones=[("complaint", 0.3), ("neutral", 0.2), ("resolution", 0.16),
               ("defence", 0.12), ("support_request", 0.12), ("sarcasm", 0.1)],
        archetypes=[("concerned_customer", 0.36), ("tech_enthusiast", 0.28),
                    ("observer", 0.2), ("supporter", 0.16)],
        volume=96, engagement_boost=1.2,
    ),
    Phase(
        "recent", 0.4, 0.05,
        platforms=[("x", 0.6), ("reddit", 0.16), ("telegram", 0.12), ("youtube", 0.12)],
        tones=[("complaint", 0.28), ("resolution", 0.24), ("neutral", 0.24),
               ("defence", 0.14), ("technical", 0.1)],
        archetypes=[("tech_enthusiast", 0.34), ("concerned_customer", 0.3),
                    ("supporter", 0.2), ("observer", 0.16)],
        volume=42, engagement_boost=1.1,
    ),
    # Rumour sub-arc, spawned out of the peak
    Phase(
        "rumour_seed", 3.2, 2.4,
        platforms=[("telegram", 0.6), ("x", 0.3), ("facebook", 0.1)],
        tones=[("misinformation", 0.7), ("anxious", 0.3)],
        archetypes=[("observer", 0.5), ("concerned_customer", 0.35), ("amplifier", 0.15)],
        volume=26, topic="recall-rumor", engagement_boost=2.1,
    ),
    Phase(
        "rumour_spread", 2.4, 1.2,
        platforms=[("x", 0.55), ("telegram", 0.25), ("facebook", 0.2)],
        tones=[("misinformation", 0.5), ("anxious", 0.28), ("debunk", 0.22)],
        archetypes=[("concerned_customer", 0.45), ("observer", 0.3), ("amplifier", 0.25)],
        volume=38, topic="recall-rumor", engagement_boost=1.8,
    ),
    Phase(
        "rumour_debunk", 1.2, 0.1,
        platforms=[("x", 0.5), ("reddit", 0.28), ("telegram", 0.22)],
        tones=[("debunk", 0.66), ("misinformation", 0.2), ("anxious", 0.14)],
        archetypes=[("reviewer", 0.3), ("tech_enthusiast", 0.35), ("news_account", 0.2),
                    ("observer", 0.15)],
        volume=31, topic="recall-rumor", engagement_boost=1.6,
    ),
    # Support frustration builds through the incident
    Phase(
        "support_pressure", 6.0, 0.5,
        platforms=[("x", 0.62), ("facebook", 0.2), ("reddit", 0.18)],
        tones=[("complaint", 0.66), ("resolution", 0.2), ("neutral", 0.14)],
        archetypes=[("concerned_customer", 0.66), ("tech_enthusiast", 0.2), ("observer", 0.14)],
        volume=64, topic="nova-support", engagement_boost=1.1,
    ),
    # Competitor churn talk emerges late
    Phase(
        "churn_talk", 5.0, 0.3,
        platforms=[("x", 0.55), ("reddit", 0.28), ("youtube", 0.17)],
        tones=[("against", 0.46), ("curious", 0.24), ("neutral", 0.18), ("praise", 0.12)],
        archetypes=[("concerned_customer", 0.4), ("tech_enthusiast", 0.3),
                    ("observer", 0.16), ("reviewer", 0.14)],
        volume=58, topic="nova-vs-orbit", engagement_boost=1.2,
    ),
    # A camera-praise burst that fades well before the present, so the trend
    # engine has a genuine decline to detect rather than only growth.
    Phase(
        "camera_burst", 34.0, 13.0,
        platforms=[("x", 0.4), ("instagram", 0.28), ("youtube", 0.18), ("reddit", 0.14)],
        tones=[("praise", 0.68), ("neutral", 0.24), ("complaint", 0.08)],
        archetypes=[("supporter", 0.32), ("reviewer", 0.26), ("tech_enthusiast", 0.24),
                    ("observer", 0.18)],
        volume=78, topic="camera-quality", engagement_boost=1.3,
    ),
]

# Background chatter: baseline topics that give the incident something to stand
# out against. `curve` shapes volume across the 7 day window.
BACKGROUND: list[dict] = [
    {
        "topic": "nova-launch", "volume": 210, "curve": "decay",
        "platforms": [("x", 0.44), ("instagram", 0.2), ("youtube", 0.14),
                      ("reddit", 0.12), ("telegram", 0.1)],
        "tones": [("praise", 0.5), ("excited", 0.24), ("neutral", 0.26)],
        "archetypes": [("supporter", 0.34), ("tech_enthusiast", 0.26), ("observer", 0.2),
                       ("reviewer", 0.1), ("amplifier", 0.1)],
    },
    {
        "topic": "camera-quality", "volume": 168, "curve": "flat",
        "platforms": [("x", 0.4), ("instagram", 0.26), ("reddit", 0.18), ("youtube", 0.16)],
        "tones": [("praise", 0.62), ("neutral", 0.26), ("complaint", 0.12)],
        "archetypes": [("supporter", 0.3), ("reviewer", 0.24), ("tech_enthusiast", 0.26),
                       ("observer", 0.2)],
    },
    {
        "topic": "update-142", "volume": 152, "curve": "ramp",
        "platforms": [("x", 0.42), ("telegram", 0.22), ("reddit", 0.24), ("youtube", 0.12)],
        "tones": [("neutral", 0.42), ("praise", 0.22), ("complaint", 0.24),
                  ("technical", 0.08), ("sarcasm", 0.04)],
        "archetypes": [("tech_enthusiast", 0.44), ("observer", 0.22), ("supporter", 0.18),
                       ("reviewer", 0.16)],
    },
    {
        "topic": "price-drop", "volume": 96, "curve": "late",
        "platforms": [("x", 0.48), ("telegram", 0.22), ("facebook", 0.16), ("reddit", 0.14)],
        "tones": [("praise", 0.44), ("neutral", 0.28), ("complaint", 0.2), ("sarcasm", 0.08)],
        "archetypes": [("amplifier", 0.3), ("observer", 0.3), ("concerned_customer", 0.22),
                       ("supporter", 0.18)],
    },
    {
        "topic": "nova-vs-orbit", "volume": 84, "curve": "flat",
        "platforms": [("x", 0.46), ("reddit", 0.3), ("youtube", 0.24)],
        "tones": [("neutral", 0.4), ("praise", 0.24), ("curious", 0.2), ("against", 0.16)],
        "archetypes": [("tech_enthusiast", 0.34), ("reviewer", 0.24), ("observer", 0.24),
                       ("supporter", 0.18)],
    },
    {
        "topic": "nova-support", "volume": 72, "curve": "flat",
        "platforms": [("x", 0.5), ("facebook", 0.26), ("reddit", 0.24)],
        "tones": [("complaint", 0.5), ("neutral", 0.28), ("resolution", 0.22)],
        "archetypes": [("concerned_customer", 0.56), ("observer", 0.24), ("tech_enthusiast", 0.2)],
    },
    {
        "topic": "battery-drain", "volume": 34, "curve": "pre_only",
        "platforms": [("x", 0.4), ("reddit", 0.3), ("telegram", 0.16), ("youtube", 0.14)],
        "tones": [("neutral", 0.46), ("complaint", 0.3), ("defence", 0.24)],
        "archetypes": [("tech_enthusiast", 0.4), ("observer", 0.3), ("supporter", 0.3)],
    },
]


# --------------------------------------------------------------------------- #
# Generator
# --------------------------------------------------------------------------- #
class DemoDataGenerator:
    """Builds the deterministic corpus of authors, posts and reply structure."""

    def __init__(self, seed: int = 20260825, target_posts: int = 1600) -> None:
        self.seed = seed
        self.target_posts = target_posts
        self.rng = random.Random(seed)
        self.anchor = self._anchor()
        self.authors: dict[str, NormalizedAuthor] = {}
        self._archetype_of: dict[str, str] = {}
        self._by_archetype: dict[str, list[str]] = {}
        self._posts: list[NormalizedPost] = []
        self._counter = 0
        # posts available as reply targets, keyed by (platform, topic)
        self._thread_index: dict[tuple[str, str], list[NormalizedPost]] = {}

    # -- helpers -----------------------------------------------------------
    @staticmethod
    def _anchor() -> datetime:
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        return now.replace(minute=0, second=0, microsecond=0)

    def _pick(self, weighted: list[tuple[str, float]]) -> str:
        options = [o for o, _ in weighted]
        weights = [w for _, w in weighted]
        return self.rng.choices(options, weights=weights, k=1)[0]

    def _fill(self, template: str) -> str:
        out = template
        for key, values in SLOTS.items():
            token = "{" + key + "}"
            while token in out:
                out = out.replace(token, self.rng.choice(values), 1)
        return out

    def _next_id(self, platform: str) -> str:
        self._counter += 1
        prefix = {"x": "x", "telegram": "tg", "reddit": "rd",
                  "youtube": "yt", "instagram": "ig", "facebook": "fb"}[platform]
        return f"{prefix}:{self.seed}{self._counter:05d}"

    # -- authors -----------------------------------------------------------
    def build_authors(self, count: int = 190) -> None:
        distribution = [
            ("tech_enthusiast", 0.22),
            ("concerned_customer", 0.26),
            ("supporter", 0.14),
            ("observer", 0.2),
            ("amplifier", 0.07),
            ("reviewer", 0.06),
            ("news_account", 0.03),
            ("support_agent", 0.02),
        ]
        used_handles: set[str] = set()
        for i in range(count):
            archetype = self._pick(distribution)
            spec = ARCHETYPES[archetype]
            platform = self._pick(PLATFORM_MIX[archetype])

            handle = f"{self.rng.choice(FIRST_NAMES)}_{self.rng.choice(LAST_TOKENS)}"
            while handle in used_handles:
                handle = f"{self.rng.choice(FIRST_NAMES)}{self.rng.randint(10, 99)}"
            used_handles.add(handle)

            location, _region, lang = self.rng.choice(REGIONS)
            lo, hi = spec["followers"]
            followers = int(self.rng.triangular(lo, hi, lo + (hi - lo) * 0.25))
            author_id = f"{platform}:{handle}"
            age_days = self.rng.randint(90, 3600)

            self.authors[author_id] = NormalizedAuthor(
                author_id=author_id,
                platform=platform,
                display_name=handle.replace("_", " ").title(),
                handle=handle,
                bio=self.rng.choice(spec["bios"]),
                followers_count=followers,
                following_count=int(followers * self.rng.uniform(0.05, 1.4)) + self.rng.randint(20, 400),
                verified=followers > 20000 and self.rng.random() < 0.6,
                account_created_at=self.anchor - timedelta(days=age_days),
                location=location if self.rng.random() < 0.62 else "",
                language=lang if self.rng.random() < 0.5 else "en",
            )
            self._archetype_of[author_id] = archetype
            self._by_archetype.setdefault(archetype, []).append(author_id)
            _ = i

    def _author_for(self, archetype: str, platform: str) -> str:
        """Pick an author of `archetype`, preferring one native to `platform`."""
        pool = self._by_archetype.get(archetype) or []
        if not pool:
            pool = [a for a in self.authors]
        native = [a for a in pool if self.authors[a].platform == platform]
        if native and self.rng.random() < 0.75:
            return self.rng.choice(native)
        return self.rng.choice(pool)

    # -- posts -------------------------------------------------------------
    def _engagement(
        self, author_id: str, platform: str, boost: float, tone: str, hours_old: float
    ) -> tuple[int, int, int, int]:
        followers = max(self.authors[author_id].followers_count, 10)
        base = (followers ** 0.62) * self.rng.uniform(0.05, 0.28) * boost
        if tone in {"complaint", "sarcasm", "misinformation", "against"}:
            base *= 1.35
        if tone in {"official", "debunk"}:
            base *= 1.2
        platform_factor = {
            "x": 1.0, "telegram": 0.55, "reddit": 0.8,
            "youtube": 0.6, "instagram": 0.9, "facebook": 0.7,
        }[platform]
        base *= platform_factor
        # recency decay: older posts had time to accumulate, newest are still rising
        maturity = min(1.0, 0.35 + hours_old / 12.0)
        base *= maturity

        likes = max(0, int(base))
        comments = max(0, int(base * self.rng.uniform(0.08, 0.34)))
        shares = max(0, int(base * self.rng.uniform(0.04, 0.22)))
        views = int(base * self.rng.uniform(9, 34)) if platform in {"x", "youtube", "telegram"} else 0
        return likes, comments, shares, views

    def _compose(self, topic: str, tone: str) -> tuple[str, str]:
        pools = T.get(topic, {})
        if tone not in pools or not pools[tone]:
            tone = next(iter(pools)) if pools else "neutral"
        text = self._fill(self.rng.choice(pools[tone]))
        language = "hi-en" if tone == "hinglish" else "en"
        return text, language

    def _decorate(self, text: str, topic: str, platform: str, archetype: str) -> str:
        """Add platform-idiomatic hashtags / mentions the way real users would."""
        topic_def = next((t for t in TOPIC_DEFINITIONS if t["id"] == topic), None)
        tags = topic_def["hashtags"] if topic_def else []
        if platform in {"x", "instagram"} and tags and self.rng.random() < 0.55:
            chosen = self.rng.sample(tags, k=min(len(tags), self.rng.randint(1, 2)))
            text = f"{text} " + " ".join(f"#{t}" for t in chosen)
        if archetype == "amplifier" and self.rng.random() < 0.5:
            influencers = self._by_archetype.get("reviewer", []) + self._by_archetype.get(
                "news_account", []
            )
            if influencers:
                target = self.rng.choice(influencers)
                text = f"@{self.authors[target].handle} {text}"
        if platform == "x" and self.rng.random() < 0.18:
            agents = self._by_archetype.get("support_agent", [])
            if agents:
                text = f"{text} @{self.authors[self.rng.choice(agents)].handle}"
        return text

    def _emit(
        self,
        topic: str,
        tone: str,
        platform: str,
        archetype: str,
        timestamp: datetime,
        boost: float,
        allow_reply: bool = True,
    ) -> NormalizedPost:
        author_id = self._author_for(archetype, platform)
        text, language = self._compose(topic, tone)
        text = self._decorate(text, topic, platform, archetype)
        if self.authors[author_id].language == "hi" and tone != "hinglish" and self.rng.random() < 0.12:
            language = "hi-en"

        hours_old = (self.anchor - timestamp).total_seconds() / 3600.0
        likes, comments, shares, views = self._engagement(
            author_id, platform, boost, tone, hours_old
        )

        reply_to = None
        parent = None
        candidates = self._thread_index.get((platform, topic), [])
        if allow_reply and candidates and self.rng.random() < 0.42:
            recent = [p for p in candidates[-60:] if 0 < (timestamp - p.timestamp).total_seconds() < 21600]
            if recent:
                target = self.rng.choice(recent)
                reply_to = target.id
                parent = target.parent_post_id or target.id

        post = NormalizedPost(
            id=self._next_id(platform),
            platform=platform,
            author_id=author_id,
            author_name=self.authors[author_id].handle,
            text=text,
            timestamp=timestamp,
            language=language,
            reply_to_id=reply_to,
            parent_post_id=parent,
            likes=likes,
            comments=comments,
            shares=shares,
            views=views,
            location=self.authors[author_id].location if self.rng.random() < 0.4 else "",
            source_id=platform,
        )
        self._posts.append(post)
        self._thread_index.setdefault((platform, topic), []).append(post)
        return post

    # -- phases ------------------------------------------------------------
    def _run_phase(self, phase: Phase, scale: float) -> None:
        volume = max(1, int(round(phase.volume * scale)))
        span = phase.start_h - phase.end_h
        for i in range(volume):
            # front-load slightly within the phase so bursts look organic
            frac = (i + self.rng.random()) / volume
            frac = frac ** self.rng.uniform(0.85, 1.15)
            hours_ago = phase.start_h - span * frac
            ts = self.anchor - timedelta(hours=hours_ago)
            ts += timedelta(seconds=self.rng.randint(0, 59))
            self._emit(
                topic=phase.topic,
                tone=self._pick(phase.tones),
                platform=self._pick(phase.platforms),
                archetype=self._pick(phase.archetypes),
                timestamp=ts,
                boost=phase.engagement_boost,
            )

    def _curve_hours(self, curve: str) -> float:
        """Sample an hours-ago offset following the named volume shape."""
        r = self.rng.random()
        if curve == "decay":          # heavy early in the window, fading
            return TIMELINE_HOURS * (1 - r ** 2.1)
        if curve == "ramp":           # builds toward the present
            return TIMELINE_HOURS * (1 - r ** 0.55)
        if curve == "late":           # only in the last ~2 days
            return 48 * (1 - r ** 0.8)
        if curve == "pre_only":       # baseline before the incident starts
            return 10 + (TIMELINE_HOURS - 10) * r
        return TIMELINE_HOURS * r     # flat

    def _run_background(self, spec: dict, scale: float) -> None:
        volume = max(1, int(round(spec["volume"] * scale)))
        for _ in range(volume):
            hours_ago = max(0.05, self._curve_hours(spec["curve"]))
            ts = self.anchor - timedelta(hours=hours_ago)
            ts += timedelta(seconds=self.rng.randint(0, 3599))
            # diurnal rhythm: suppress the small hours by resampling once
            if ts.hour in (2, 3, 4, 5) and self.rng.random() < 0.6:
                ts += timedelta(hours=self.rng.randint(6, 12))
                if ts > self.anchor:
                    ts -= timedelta(hours=14)
            self._emit(
                topic=spec["topic"],
                tone=self._pick(spec["tones"]),
                platform=self._pick(spec["platforms"]),
                archetype=self._pick(spec["archetypes"]),
                timestamp=ts,
                boost=1.0,
            )

    # -- entry point -------------------------------------------------------
    def generate(self) -> tuple[list[NormalizedAuthor], list[NormalizedPost]]:
        self.build_authors()

        scripted = sum(p.volume for p in INCIDENT_PHASES)
        background = sum(b["volume"] for b in BACKGROUND)
        scale = self.target_posts / float(scripted + background)

        for spec in BACKGROUND:
            self._run_background(spec, scale)
        for phase in INCIDENT_PHASES:
            self._run_phase(phase, scale)

        self._posts.sort(key=lambda p: p.timestamp)

        # Author post counts are a real property of the corpus, so recount here.
        counts: dict[str, int] = {}
        for post in self._posts:
            counts[post.author_id] = counts.get(post.author_id, 0) + 1
        active = [a for a in self.authors.values() if counts.get(a.author_id)]
        return active, self._posts


def generate_demo_corpus(
    seed: int = 20260825, target_posts: int = 1600
) -> tuple[list[NormalizedAuthor], list[NormalizedPost]]:
    return DemoDataGenerator(seed=seed, target_posts=target_posts).generate()
