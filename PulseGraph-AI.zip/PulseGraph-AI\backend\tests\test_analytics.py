"""Analytics engine: trends, network, segmentation, demographics, topics.

Pure-function tests use hand-built inputs so the expected answer is knowable.
Pipeline-backed tests assert properties of genuinely computed output.
"""

from __future__ import annotations

from datetime import datetime, timedelta

import pytest

from app.analytics import network as net
from app.analytics import segments as seg
from app.analytics import topics as topic_mod
from app.analytics import trends as trend_mod
from app.analytics.demographics import aggregate, confidence_band, infer_profile
from app.analytics.trends import TopicObservation

BASE = datetime(2026, 8, 24, 12, 0)


def observations(spec: list[tuple[float, str, str, int, float]]) -> list[TopicObservation]:
    """spec: (hours_offset, author, platform, engagement, polarity)"""
    return [
        TopicObservation(timestamp=BASE + timedelta(hours=h), author_id=a,
                         platform=p, engagement=e, polarity=pol)
        for h, a, p, e, pol in spec
    ]


class TestTrendMath:
    def test_growth_normalisation_anchors(self):
        flat = trend_mod._normalise_growth(0)
        assert flat == pytest.approx(trend_mod.FLAT_GROWTH_SCORE)
        assert trend_mod._normalise_growth(-100) == 0.0
        assert trend_mod._normalise_growth(-50) < flat
        assert trend_mod._normalise_growth(100) > flat
        assert trend_mod._normalise_growth(1000) == 1.0

    def test_growth_is_monotonic(self):
        values = [trend_mod._normalise_growth(p) for p in (-80, -20, 0, 25, 100, 400, 900)]
        assert values == sorted(values)

    def test_classification_boundaries(self):
        assert trend_mod.classify(0) == "stable"
        assert trend_mod.classify(20.9) == "stable"
        assert trend_mod.classify(21) == "emerging"
        assert trend_mod.classify(41) == "growing"
        assert trend_mod.classify(61) == "accelerating"
        assert trend_mod.classify(81) == "viral"
        assert trend_mod.classify(100) == "viral"

    def test_linear_slope(self):
        assert trend_mod.linear_slope([1, 2, 3, 4]) == pytest.approx(1.0)
        assert trend_mod.linear_slope([4, 3, 2, 1]) == pytest.approx(-1.0)
        assert trend_mod.linear_slope([5, 5, 5, 5]) == pytest.approx(0.0)

    def test_exponential_smoothing_tracks_level(self):
        smoothed = trend_mod.exponential_smoothing([0, 10, 10, 10, 10, 10], alpha=0.5)
        assert smoothed[0] == 0.0
        assert smoothed[-1] > smoothed[1]
        assert smoothed[-1] < 10.0

    def test_zero_baseline_growth_is_capped(self):
        """A 0 -> n jump must not produce infinite growth."""
        assert trend_mod._growth(50, 0) == pytest.approx(1200.0)
        assert trend_mod._growth(0, 0) == 0.0
        assert trend_mod._growth(150, 50) == pytest.approx(200.0)


class TestTrendVelocity:
    def test_rising_topic_scores_above_flat_topic(self):
        rising = observations(
            [(0.5 + i * 0.1, f"a{i % 3}", "x", 40, -0.4) for i in range(5)]
            + [(12.5 + i * 0.05, f"b{i % 30}", "x", 120, -0.6) for i in range(80)]
        )
        flat = observations([(i * 0.6, f"c{i % 20}", "x", 40, 0.1) for i in range(40)])

        rising_result = trend_mod.analyse_topic("rising", rising, BASE, BASE + timedelta(hours=24), set())
        flat_result = trend_mod.analyse_topic("flat", flat, BASE, BASE + timedelta(hours=24), set())

        assert rising_result.growth_rate > 400
        assert rising_result.trend_score > flat_result.trend_score
        assert rising_result.classification in {"growing", "accelerating", "viral"}
        assert flat_result.classification in {"stable", "emerging"}

    def test_high_volume_spike_reaches_the_top_band(self):
        """Percentage growth alone is not enough; volume must back it."""
        spike = observations(
            [(0.5 + i * 0.2, f"a{i % 4}", "x", 40, -0.3) for i in range(8)]
            + [
                (12.2 + i * 0.014, f"b{i % 120}",
                 ["x", "telegram", "reddit", "youtube", "facebook"][i % 5], 180, -0.6)
                for i in range(520)
            ]
        )
        result = trend_mod.analyse_topic(
            "spike", spike, BASE, BASE + timedelta(hours=24), influencer_ids={"b1", "b2"})
        assert result.mentions > 400
        assert result.components["values"]["small_sample_discount"] == 1.0
        assert result.classification in {"accelerating", "viral"}

    def test_same_growth_ranks_below_when_volume_is_lower(self):
        """Two topics with identical growth rank by the evidence behind them."""
        def build(count: int) -> list[TopicObservation]:
            base = max(1, count // 10)
            return observations(
                [(1.0 + i * 0.3, f"p{i}", "x", 60, -0.3) for i in range(base)]
                + [(12.3 + i * 0.02, f"q{i % 40}", "x", 60, -0.3) for i in range(count)]
            )

        big = trend_mod.analyse_topic("big", build(400), BASE, BASE + timedelta(hours=24), set())
        small = trend_mod.analyse_topic("small", build(30), BASE, BASE + timedelta(hours=24), set())

        # Both saturate the growth curve, so the growth component is identical
        # and only the evidence behind them separates the scores.
        assert big.components["values"]["volume_growth"] == pytest.approx(
            small.components["values"]["volume_growth"], abs=0.01)
        assert big.trend_score > small.trend_score

    def test_declining_topic_is_classified_low(self):
        declining = observations(
            [(i * 0.15, f"a{i % 25}", "x", 60, 0.2) for i in range(70)]
            + [(12.5 + i * 0.9, f"b{i}", "x", 20, 0.1) for i in range(5)]
        )
        result = trend_mod.analyse_topic(
            "declining", declining, BASE, BASE + timedelta(hours=24), set())
        assert result.growth_rate < -50
        assert result.classification in {"stable", "emerging"}

    def test_small_sample_cannot_reach_viral(self):
        tiny = observations([(13.0, "a", "x", 9000, -0.9), (13.5, "b", "telegram", 9000, -0.9)])
        result = trend_mod.analyse_topic("tiny", tiny, BASE, BASE + timedelta(hours=24), set())
        assert result.mentions == 2
        assert result.trend_score < 61
        assert result.components["values"]["small_sample_discount"] < 1.0

    def test_cross_platform_spread_raises_score(self):
        single = observations([(12.5 + i * 0.1, f"a{i}", "x", 50, -0.3) for i in range(30)])
        multi = observations([
            (12.5 + i * 0.1, f"a{i}", ["x", "telegram", "reddit", "youtube"][i % 4], 50, -0.3)
            for i in range(30)
        ])
        a = trend_mod.analyse_topic("s", single, BASE, BASE + timedelta(hours=24), set())
        b = trend_mod.analyse_topic("m", multi, BASE, BASE + timedelta(hours=24), set())
        assert b.platform_count == 4 and a.platform_count == 1
        assert b.trend_score > a.trend_score

    def test_influencer_participation_is_measured(self):
        obs = observations([(12.5 + i * 0.1, f"a{i % 10}", "x", 50, -0.3) for i in range(30)])
        result = trend_mod.analyse_topic(
            "t", obs, BASE, BASE + timedelta(hours=24), influencer_ids={"a0", "a1"})
        assert 0 < result.influencer_participation < 1

    def test_velocity_summary_reports_direction(self):
        obs = observations(
            [(1.0, "a", "x", 10, 0.0)]
            + [(12.5 + i * 0.1, f"b{i}", "x", 30, -0.2) for i in range(20)]
        )
        result = trend_mod.analyse_topic("t", obs, BASE, BASE + timedelta(hours=24), set())
        summary = trend_mod.velocity_summary(result)
        assert summary["direction"] == "up"
        assert summary["current_mentions"] == 20
        assert summary["previous_mentions"] == 1
        assert summary["growth_percentage"] > 0


class TestMomentumForecast:
    def test_growth_is_labelled_growing(self):
        label, confidence, forecast, _accel = trend_mod.forecast_momentum(
            [1, 2, 4, 7, 11, 16, 22, 30])
        assert label == "likely to continue growing"
        assert confidence > 0.5
        assert forecast > 30 * 0.5

    def test_decline_is_labelled_declining(self):
        label, _c, _f, _a = trend_mod.forecast_momentum([40, 34, 27, 20, 14, 9, 5, 2])
        assert label == "likely to decline"

    def test_plateau_is_labelled_stabilising(self):
        label, _c, _f, _a = trend_mod.forecast_momentum([20, 21, 20, 19, 20, 21, 20, 20])
        assert label == "likely to stabilise"

    def test_short_series_refuses_to_guess(self):
        label, confidence, _f, _a = trend_mod.forecast_momentum([3, 5])
        assert label == "insufficient_data"
        assert confidence <= 0.4

    def test_acceleration_sign_matches_curvature(self):
        _l, _c, _f, accelerating = trend_mod.forecast_momentum(
            [1, 1, 2, 2, 3, 6, 12, 20, 32, 50, 74, 100])
        _l2, _c2, _f2, decelerating = trend_mod.forecast_momentum(
            [1, 20, 45, 70, 90, 100, 104, 106, 107, 107, 108, 108])
        assert accelerating > 0
        assert decelerating < accelerating


class TestNetworkMetrics:
    @staticmethod
    def star_edges() -> list[net.Edge]:
        return [net.Edge(f"leaf{i}", "hub", "reply") for i in range(8)]

    def test_hub_outranks_leaves(self):
        metrics = net.compute_metrics(self.star_edges())
        hub = metrics["hub"]
        leaf = metrics["leaf0"]
        assert hub.pagerank > leaf.pagerank
        assert hub.influence_score > leaf.influence_score
        assert hub.in_degree == 8 and hub.out_degree == 0

    def test_bridge_between_two_clusters_is_detected(self):
        edges: list[net.Edge] = []
        for i in range(6):
            for j in range(6):
                if i != j:
                    edges.append(net.Edge(f"L{i}", f"L{j}", "reply"))
                    edges.append(net.Edge(f"R{i}", f"R{j}", "reply"))
        # A single account links the two otherwise disjoint cliques.
        for i in range(4):
            edges.append(net.Edge("BRIDGE", f"L{i}", "mention"))
            edges.append(net.Edge("BRIDGE", f"R{i}", "mention"))

        metrics = net.compute_metrics(edges)
        assert metrics["BRIDGE"].betweenness > metrics["L0"].betweenness
        assert metrics["BRIDGE"].cross_community_edges > 0
        assert len({m.community_id for m in metrics.values()}) >= 2

    def test_self_interaction_is_ignored(self):
        metrics = net.compute_metrics([net.Edge("a", "a", "reply"), net.Edge("a", "b", "reply")])
        assert metrics["a"].out_degree == 1

    def test_repeated_edges_accumulate_weight(self):
        graph = net.build_graph([net.Edge("a", "b", "reply"), net.Edge("a", "b", "mention")])
        assert graph["a"]["b"]["weight"] == 2.0
        assert graph["a"]["b"]["kinds"] == {"reply", "mention"}

    def test_empty_graph_returns_empty_not_error(self):
        assert net.compute_metrics([]) == {}

    def test_follower_count_influences_but_does_not_dominate(self):
        edges = self.star_edges()
        without = net.compute_metrics(edges)
        with_followers = net.compute_metrics(edges, {"leaf0": 5_000_000})
        # A huge audience lifts a peripheral account, but structure still wins.
        assert with_followers["leaf0"].influence_score > without["leaf0"].influence_score
        assert with_followers["hub"].influence_score > with_followers["leaf0"].influence_score

    def test_display_aggregation_caps_nodes_and_keeps_edges_valid(self):
        edges = [net.Edge(f"n{i}", f"n{(i + 1) % 60}", "reply") for i in range(60)]
        metrics = net.compute_metrics(edges)
        aggregated = net.aggregate_for_display(metrics, edges, max_nodes=10)
        kept = {n.author_id for n in aggregated["nodes"]}
        assert len(kept) <= 12
        assert aggregated["truncated"] is True
        assert aggregated["total_nodes"] == 60
        for edge in aggregated["edges"]:
            assert edge["source"] in kept and edge["target"] in kept


class TestSegmentation:
    def test_prototypes_recover_their_own_centroids(self):
        """Each prototype must be the nearest match to its own definition."""
        for prototype in seg.PROTOTYPES:
            reach, activity, negativity, amplification, technicality = prototype.centroid
            features = seg.AuthorFeatures(
                author_id="probe", reach=reach, activity=activity, negativity=negativity,
                amplification=amplification, technicality=technicality,
            )
            assigned, fit, _rationale = seg.assign_segment(features)
            assert assigned == prototype.id
            assert fit > 0.5

    def test_low_reach_negative_user_lands_in_concerned_customers(self):
        features = seg.AuthorFeatures("u", reach=0.15, activity=0.4, negativity=0.88,
                                      amplification=0.2, technicality=0.15)
        assigned, _fit, rationale = seg.assign_segment(features)
        assert assigned == "concerned-customers"
        assert any("negative" in r for r in rationale)

    def test_high_reach_amplifier_is_separated_from_reviewer(self):
        amplifier = seg.AuthorFeatures("a", reach=0.85, activity=0.6, negativity=0.4,
                                       amplification=0.9, technicality=0.3)
        reviewer = seg.AuthorFeatures("r", reach=0.95, activity=0.28, negativity=0.5,
                                      amplification=0.4, technicality=0.92)
        assert seg.assign_segment(amplifier)[0] == "information-amplifiers"
        assert seg.assign_segment(reviewer)[0] == "technical-reviewers"

    def test_technical_density_separates_registers(self):
        technical = seg.technical_density([
            "Idle drain is 18%/hour post-update versus 2%/hour before, same workload and brightness.",
            "Battery stats show the system process holding wakelocks; collected logs from three units.",
        ])
        casual = seg.technical_density([
            "my phone dies so fast now",
            "this is really annoying honestly",
        ])
        assert technical > casual
        assert 0.0 <= technical <= 1.0 and casual >= 0.0

    def test_empty_text_yields_zero_density(self):
        assert seg.technical_density([]) == 0.0


class TestDemographics:
    def test_student_bio_infers_young_bracket_with_evidence(self):
        from collections import Counter

        profile = infer_profile(
            author_id="u1", bio="CS undergrad. I flash firmware for fun.",
            followers=800, account_created_at=datetime(2025, 6, 1),
            location_raw="Bengaluru, IN", languages=Counter({"en": 9}),
            post_count=14, avg_engagement=120, reply_ratio=0.3, share_ratio=0.1,
            topic_affinity=["battery-drain"], now=datetime(2026, 8, 24),
        )
        assert profile.age_bracket == "18-24"
        assert profile.region == "South Asia"
        assert profile.professional_interest == "Technology / power user"
        assert profile.evidence
        assert all("basis" in e for e in profile.evidence)

    def test_inference_never_claims_certainty(self):
        from collections import Counter

        profile = infer_profile(
            author_id="u2", bio="Parent, commuter, needs a phone that lasts the day.",
            followers=200, account_created_at=datetime(2016, 1, 1), location_raw="London, UK",
            languages=Counter({"en": 4}), post_count=4, avg_engagement=20,
            reply_ratio=0.2, share_ratio=0.0, topic_affinity=[],
            now=datetime(2026, 8, 24),
        )
        assert profile.age_bracket == "35-44"
        assert profile.age_confidence <= 0.78, "age inference must never reach High confidence"

    def test_absent_signal_yields_unknown_not_a_guess(self):
        from collections import Counter

        profile = infer_profile(
            author_id="u3", bio="", followers=10, account_created_at=None, location_raw="",
            languages=Counter({"en": 1}), post_count=1, avg_engagement=2,
            reply_ratio=0.0, share_ratio=0.0, topic_affinity=[],
        )
        assert profile.age_bracket == "unknown"
        assert profile.age_confidence < 0.6
        assert profile.region == "Unknown"

    def test_confidence_bands(self):
        assert confidence_band(0.91) == "High"
        assert confidence_band(0.80) == "High"
        assert confidence_band(0.79) == "Medium"
        assert confidence_band(0.60) == "Medium"
        assert confidence_band(0.59) == "Low"

    def test_aggregate_percentages_sum_to_100(self):
        from collections import Counter

        profiles = [
            infer_profile(f"u{i}", "CS undergrad", 100, None, "Pune, IN",
                          Counter({"en": 1}), 3, 10, 0.1, 0.0, [])
            for i in range(4)
        ] + [
            infer_profile(f"v{i}", "Parent of two", 100, None, "London, UK",
                          Counter({"en": 1}), 3, 10, 0.1, 0.0, [])
            for i in range(6)
        ]
        rows = aggregate(profiles, "age_bracket")
        assert sum(r["percentage"] for r in rows) == pytest.approx(100.0, abs=0.2)
        assert all("confidence_band" in r for r in rows)


class TestTopicModelling:
    def test_distinctive_phrase_beats_shared_word(self):
        assert topic_mod.TERM_WEIGHTS["screen on time"] > topic_mod.TERM_WEIGHTS["update"]

    def test_battery_complaint_classifies_to_battery_topic(self):
        ranked = topic_mod.classify(
            "Since the v14.2 update my phone drops from 100% to 18% in four hours. "
            "Battery drain is unbearable."
        )
        assert ranked[0][0] == "battery-drain"

    def test_camera_praise_classifies_to_camera_topic(self):
        ranked = topic_mod.classify(
            "Night mode is doing serious work here, almost no noise at 6400 ISO. "
            "Best low light camera I have used."
        )
        assert ranked[0][0] == "camera-quality"

    def test_short_reply_inherits_parent_topic(self):
        without = topic_mod.classify("same here")
        with_parent = topic_mod.classify("same here", parent_topic="battery-drain")
        assert without == []
        assert with_parent and with_parent[0][0] == "battery-drain"

    def test_unrelated_text_is_left_unclassified(self):
        assert topic_mod.classify("the weather today is quite pleasant") == []

    def test_hashtag_contributes_signal(self):
        ranked = topic_mod.classify("this is getting worse", hashtags=["novarecall"])
        assert ranked and ranked[0][0] == "recall-rumor"

    def test_tfidf_surfaces_salient_terms(self):
        docs = [
            "battery drain after update is terrible",
            "battery drain is getting worse every day",
            "battery drain reported by many users",
            "camera is good",
        ]
        keywords = dict(topic_mod.extract_keywords(docs, top_n=5))
        assert "battery" in keywords or "drain" in keywords
