import type { Metadata, Viewport } from 'next';
import { Suspense } from 'react';

import './globals.css';

export const metadata: Metadata = {
  title: 'PulseGraph AI — Social Intelligence. Explained.',
  description:
    'AI-driven social media analytics: sentiment, demographics, trends and link analysis, with evidence-backed explanations.',
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#0b0f16',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Suspense fallback={null}>{children}</Suspense>
      </body>
    </html>
  );
}
