'use client';

/**
 * Cross-platform sentiment divergence.
 *
 * The same narrative rarely behaves identically across communities. A diverging
 * bar chart around zero makes the split legible at a glance, and the spread
 * between the most positive and most negative platform is stated numerically.
 */

import { Bar, BarChart, Cell, LabelList, ReferenceLine, ResponsiveContainer, XAxis, YAxis } from 'recharts';

import { COLORS, polarityColor } from '@/lib/colors';
import { compactNumber, platformLabel, polarity } from '@/lib/format';
import { Badge, EmptyState, Panel, PanelSkeleton, cx } from '@/components/ui/primitives';
import type { PlatformBreakdown } from '@/types/api';

export function PlatformDivergence({
  platforms,
  divergence,
  interpretation,
  loading,
  title = 'Cross-platform sentiment divergence',
}: {
  platforms: PlatformBreakdown[] | null;
  divergence?: number;
  interpretation?: string;
  loading?: boolean;
  title?: string;
}) {
  const data = (platforms ?? [])
    .filter((p) => p.posts >= 3)
    .map((p) => ({ ...p, name: platformLabel(p.platform) }))
    .sort((a, b) => a.avg_polarity - b.avg_polarity);

  const significant = (divergence ?? 0) >= 0.25;

  return (
    <Panel
      title={title}
      subtitle="Average polarity per platform for the current selection"
      actions={
        divergence !== undefined ? (
          <Badge tone={significant ? 'warning' : 'neutral'}>
            Spread {divergence.toFixed(2)}
          </Badge>
        ) : null
      }
    >
      {loading && <PanelSkeleton rows={4} height="h-6" />}

      {!loading && data.length === 0 && (
        <EmptyState
          title="Not enough per-platform data"
          description="At least three posts on a platform are needed before its sentiment is reported."
        />
      )}

      {!loading && data.length > 0 && (
        <>
          <ResponsiveContainer width="100%" height={Math.max(140, data.length * 34)}>
            <BarChart data={data} layout="vertical" margin={{ top: 4, right: 44, bottom: 4, left: 4 }}>
              <XAxis type="number" domain={[-1, 1]} ticks={[-1, -0.5, 0, 0.5, 1]}
                     tickLine={false} axisLine={{ stroke: COLORS.grid }} />
              <YAxis type="category" dataKey="name" width={68} tickLine={false} axisLine={false} />
              <ReferenceLine x={0} stroke={COLORS.axis} strokeWidth={1} />
              <Bar dataKey="avg_polarity" maxBarSize={18} radius={2}>
                {data.map((entry) => (
                  <Cell key={entry.platform} fill={polarityColor(entry.avg_polarity)} />
                ))}
                <LabelList
                  dataKey="avg_polarity"
                  position="right"
                  formatter={(value: number) => polarity(value)}
                  style={{ fill: COLORS.muted, fontSize: 10, fontFamily: 'ui-monospace, monospace' }}
                />
              </Bar>
            </BarChart>
          </ResponsiveContainer>

          <table className="mt-3 w-full border-collapse text-2xs">
            <thead>
              <tr className="border-b border-edge-subtle text-left text-ink-faint">
                <th className="py-1 pr-2 font-medium">Platform</th>
                <th className="py-1 pr-2 text-right font-medium">Posts</th>
                <th className="py-1 pr-2 text-right font-medium">Authors</th>
                <th className="py-1 pr-2 text-right font-medium">Negative</th>
                <th className="py-1 text-right font-medium">Engagement</th>
              </tr>
            </thead>
            <tbody>
              {data.map((row) => (
                <tr key={row.platform} className="border-b border-edge-subtle/60 last:border-0">
                  <td className="py-1.5 pr-2">
                    <span className="inline-flex items-center gap-1.5 text-ink-muted">
                      <span
                        className="h-1.5 w-1.5 rounded-full"
                        style={{ backgroundColor: polarityColor(row.avg_polarity) }}
                        aria-hidden
                      />
                      {row.name}
                    </span>
                  </td>
                  <td className="py-1.5 pr-2 text-right font-mono tabular-nums text-ink-muted">
                    {row.posts}
                  </td>
                  <td className="py-1.5 pr-2 text-right font-mono tabular-nums text-ink-muted">
                    {row.unique_authors}
                  </td>
                  <td
                    className={cx(
                      'py-1.5 pr-2 text-right font-mono tabular-nums',
                      row.negative_share > 0.5 ? 'text-negative' : 'text-ink-muted',
                    )}
                  >
                    {(row.negative_share * 100).toFixed(0)}%
                  </td>
                  <td className="py-1.5 text-right font-mono tabular-nums text-ink-muted">
                    {compactNumber(row.engagement)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {interpretation && (
            <p
              className={cx(
                'mt-3 rounded border px-2.5 py-2 text-2xs leading-relaxed',
                significant
                  ? 'border-warning/25 bg-warning/[0.06] text-ink-muted'
                  : 'border-edge-subtle bg-canvas-sunken text-ink-faint',
              )}
            >
              {interpretation}
            </p>
          )}
        </>
      )}
    </Panel>
  );
}
